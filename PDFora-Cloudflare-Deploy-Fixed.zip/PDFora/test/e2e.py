"""Real-browser end-to-end test. Needs test/e2e-server.js running (fake Google + fake Stripe). Run: python3 test/e2e.py"""
import re, sys, json, urllib.request
from playwright.sync_api import sync_playwright, expect
B = 'http://localhost:3921'; M = 'http://localhost:3922'
ok_n = fail_n = 0
def ok(c, m):
    global ok_n, fail_n
    if c: ok_n += 1; print('  ok   ' + m)
    else: fail_n += 1; print('  FAIL ' + m)
import time
def until(pg, expr, timeout=15000):
    # polls with evaluate() (CDP) because wait_for_function needs eval, which the site's strict CSP correctly forbids
    end = time.time() + timeout / 1000
    while time.time() < end:
        if pg.evaluate('() => !!(' + expr + ')'): return
        time.sleep(0.1)
    raise TimeoutError(expr)
def hit(u): return urllib.request.urlopen(u).read().decode()
errors = []
with sync_playwright() as p:
    br = p.chromium.launch(); ctx = br.new_context(accept_downloads=True, viewport={'width': 1280, 'height': 900}); page = ctx.new_page()
    page.on('console', lambda m: errors.append(m.text) if m.type == 'error' else None)
    page.on('pageerror', lambda e: errors.append('PAGEERROR ' + str(e)))
    print('Logged out')
    page.goto(B + '/'); page.wait_for_selector('#tools a.tool')
    ok(page.locator('#tools a.tool').count() == 25, 'home shows all 25 tools without login')
    page.locator('#tools a.tool', has_text='Merge PDF').first.click(); page.wait_for_url('**/merge-pdf')
    ok(page.locator('#modal').evaluate('e=>getComputedStyle(e).display') == 'none', 'tool page does not open the tool for a visitor')
    until(page, "document.getElementById('openToolBtn').textContent.includes('Google')")
    ok('Continue with Google' in page.inner_text('#openToolBtn'), 'tool page asks to continue with Google')
    page.goto(B + '/merge-pdf#merge-pdf'); page.wait_for_timeout(600)
    ok(page.locator('#modal').evaluate('e=>getComputedStyle(e).display') == 'none', 'typing #tool in the URL does not bypass login')
    ok(page.locator('#pfOverlay').count() == 1, 'login dialog shown instead')
    page.goto(B + '/#compress-pdf'); page.wait_for_url('**/compress-pdf'); ok(True, 'old #slug links redirect to the tool page URL')
    r = ctx.request.post(B + '/api/usage/reserve', data='{}', headers={'X-PDFora': '1', 'Content-Type': 'application/json'}); ok(r.status == 401, 'API refuses unauthenticated usage')

    print('Google login')
    page.goto(B + '/merge-pdf'); until(page, "document.getElementById('openToolBtn').textContent.includes('Google')")
    page.click('#openToolBtn'); page.wait_for_url('**/merge-pdf'); page.wait_for_selector('#modal', state='visible')
    ok(page.inner_text('#modalTitle') == 'Merge PDF', 'after login the tool opens automatically')
    page.wait_for_selector('#quotaPill'); ok('3 of 3 free operations left today' in page.inner_text('#quotaPill'), 'header shows remaining free operations (3 of 3)')

    print('Merge, failure, limit')
    def run_merge(files):
        page.set_input_files('#tool input[type=file]', files)
        until(page, "document.querySelectorAll('#fileGrid .merge-file').length>=1")
    page.set_input_files('#tool input[type=file]', ['/tmp/e2e/doc1.pdf', '/tmp/e2e/doc2.pdf'])
    until(page, "document.querySelectorAll('#fileGrid .merge-file').length==2")
    ok(page.locator('#pfClearAll').is_visible(), 'Clear all files button is shown once files are added')
    with page.expect_download() as d:
        page.click('#goBtn'); page.wait_for_selector('.dl-main'); page.click('.dl-main')
    path = d.value.path(); data = open(path, 'rb').read()
    import subprocess
    pages = re.search(r'Pages:\s+(\d+)', subprocess.run(['pdfinfo', path], capture_output=True, text=True).stdout)
    ok(data.startswith(b'%PDF') and pages and int(pages.group(1)) == 5, 'merged PDF downloaded and is a valid PDF with 5 pages')
    until(page, "document.getElementById('quotaPill').textContent.includes('2 of 3')"); ok(True, 'successful run used 1 of 3')
    page.click('#pfClearAll'); ok(page.locator('#fileGrid .merge-file').count() == 0, 'Clear all files removes every file')
    ok('PDFora has no server copy' in page.inner_text('.status'), 'Clear all message is honest: no server copy exists')
    page.set_input_files('#tool input[type=file]', ['/tmp/e2e/broken.pdf', '/tmp/e2e/doc1.pdf']); page.wait_for_timeout(500)
    page.click('#goBtn'); page.wait_for_selector('.status.error', timeout=15000)
    until(page, "document.getElementById('pfQuota').textContent.includes('Nothing was deducted')")
    ok('2 of 3' in page.inner_text('#quotaPill'), 'failed operation did NOT consume the allowance')
    for i in range(2):
        page.click('#pfClearAll'); page.set_input_files('#tool input[type=file]', ['/tmp/e2e/doc1.pdf', '/tmp/e2e/doc2.pdf'])
        until(page, "document.querySelectorAll('#fileGrid .merge-file').length==2"); page.click('#goBtn'); page.wait_for_selector('.dl-main'); page.wait_for_timeout(300)
    until(page, "document.getElementById('quotaPill').textContent.includes('0 of 3')"); ok(True, 'three successful operations used the whole free allowance')
    page.click('#pfClearAll'); page.set_input_files('#tool input[type=file]', ['/tmp/e2e/doc1.pdf', '/tmp/e2e/doc2.pdf']); page.wait_for_timeout(300)
    page.click('#goBtn'); page.wait_for_selector('#pfOverlay')
    ok('Daily free limit reached' in page.inner_text('#pfOverlay') and page.locator('#pfOverlay a[href="/pricing"]').count() == 1, 'fourth operation blocked with upgrade prompt')
    ok(page.locator('.dl-main').count() == 0, 'no result is produced when blocked')
    page.screenshot(path='/tmp/e2e/shot-limit.png')
    page.evaluate('localStorage.clear(); sessionStorage.clear()'); page.reload(); page.wait_for_selector('#quotaPill')
    ok('0 of 3' in page.inner_text('#quotaPill'), 'clearing browser storage and reloading does not reset the limit')

    print('Pricing, payment, subscription')
    page.goto(B + '/pricing'); page.wait_for_selector('.pricing')
    ok('$0' in page.inner_text('.pricing') and '$9.99' in page.inner_text('.pricing') and '$71.99' in page.inner_text('.pricing'), 'pricing page shows $0, $9.99/month and $71.99/year')
    page.click('[data-plan=monthly]'); page.wait_for_url(M + '/checkout'); ok(page.locator('#mock-checkout').count() == 1, 'Monthly button creates a checkout session and redirects')
    page.goto(B + '/subscription?checkout=success')   # browser says "success" but nothing is paid yet
    page.wait_for_timeout(1200); ok(page.locator('.msg.ok').count() == 0 and 'Free plan' not in '' , 'success URL alone does not unlock Pro')
    hit(M + '/__pay')
    page.wait_for_selector('.msg.ok', timeout=15000); ok('Pro is now active' in page.inner_text('#subMsg'), 'Pro unlocks only after the verified webhook')
    page.goto(B + '/subscription'); page.wait_for_selector('#subBox .card'); ok('PDFora Pro is active' in page.inner_text('#subBox') and '$9.99' in page.inner_text('#subBox'), 'subscription page shows active Pro Monthly')
    page.goto(B + '/merge-pdf'); page.wait_for_selector('#modal', state='visible'); page.wait_for_selector('#quotaPill')
    ok('Pro' in page.inner_text('#quotaPill') and 'of 50' in page.inner_text('#quotaPill'), 'Pro shows higher daily allowance')
    page.set_input_files('#tool input[type=file]', ['/tmp/e2e/doc1.pdf', '/tmp/e2e/doc2.pdf']); until(page, "document.querySelectorAll('#fileGrid .merge-file').length==2")
    page.click('#goBtn'); page.wait_for_selector('.dl-main'); ok(True, 'Pro user can process past the free limit')
    page.goto(B + '/subscription'); page.wait_for_selector('#subBox .card'); page.once('dialog', lambda d: d.accept()); page.click('text=Cancel subscription')
    page.wait_for_selector('text=Keep my subscription'); ok('Access until' in page.inner_text('#subBox'), 'cancel keeps Pro until the paid-through date')
    hit(M + '/__expire'); page.reload(); page.wait_for_selector('#subBox .card')
    ok('Free plan' in page.inner_text('#subBox') and 'ended on' in page.inner_text('#subBox'), 'after expiry the account returns to Free with a clear message')

    print('All 25 tool pages')
    slugs = re.findall(r'<loc>[^<]*/([a-z0-9-]+)</loc>', hit(B + '/sitemap.xml')); tools = [s for s in slugs if s not in ('tools', 'pricing', 'about', 'contact', 'privacy-policy', 'terms-of-service')]
    ok(len(tools) == 25, 'sitemap lists 25 tool URLs'); titles = set(); descs = set(); bad = []
    for s in tools:
        page.goto(B + '/' + s); page.wait_for_selector('#modal', state='visible', timeout=8000)
        t = page.title(); dsc = page.locator('meta[name=description]').get_attribute('content'); titles.add(t); descs.add(dsc)
        h1 = page.locator('h1').count(); can = page.locator('link[rel=canonical]').get_attribute('href')
        if h1 != 1 or not can.endswith('/' + s) or page.locator('#modalTitle').inner_text().strip() == '' or page.locator('h2').count() < 3 or page.locator('h3').count() < 3: bad.append(s)
    ok(not bad, 'every tool page: one H1, H2/H3 structure, own canonical, tool opens after login' + (' - problems: ' + ','.join(bad) if bad else ''))
    ok(len(titles) == 25 and len(descs) == 25, '25 unique SEO titles and 25 unique meta descriptions')

    page.goto(B + '/png-to-jpg'); page.wait_for_selector('#modal', state='visible'); sl = page.locator('#tool input[type=range]').first
    sl.evaluate("e => { e.value = 61; e.dispatchEvent(new Event('input', {bubbles: true})); }"); ok('61' in sl.evaluate('e => e.nextElementSibling.textContent'), 'image-tool quality slider label still updates under the strict CSP')
    print('Layout')
    for name, url in [('home', '/'), ('tool', '/merge-pdf'), ('pricing', '/pricing')]:
        mp = br.new_context(viewport={'width': 390, 'height': 844}, is_mobile=True).new_page(); mp.goto(B + url); mp.wait_for_timeout(500)
        sw = mp.evaluate('document.documentElement.scrollWidth'); ok(sw <= 392, 'mobile: no sideways scrolling on ' + name + ' (' + str(sw) + 'px)'); mp.screenshot(path='/tmp/e2e/shot-mobile-' + name + '.png')
    page.goto(B + '/'); page.screenshot(path='/tmp/e2e/shot-home.png')
    print('404 and console')
    r = ctx.request.get(B + '/does-not-exist'); ok(r.status == 404 and 'page not found' in r.text().lower(), 'custom 404 page with 404 status')
    csp = [e for e in errors if 'Content Security Policy' in e or 'PAGEERROR' in e]
    ok(not csp, 'no CSP violations or script errors in the browser console' + (' ' + str(csp[:3]) if csp else ''))
    br.close()
print('\n%d passed, %d failed' % (ok_n, fail_n)); sys.exit(1 if fail_n else 0)
