"""Runs several of the unchanged engines in a real browser under the production CSP, as a Pro user. Needs test/e2e-server.js."""
import time, urllib.request, subprocess, re, sys
from playwright.sync_api import sync_playwright
B='http://localhost:3921'; M='http://localhost:3922'
res=[]; errs=[]
with sync_playwright() as p:
    br=p.chromium.launch(); ctx=br.new_context(accept_downloads=True); page=ctx.new_page()
    page.on('console', lambda m: errs.append(m.text) if m.type=='error' else None); page.on('pageerror', lambda e: errs.append('PAGEERROR '+str(e)))
    page.goto(B+'/pricing'); time.sleep(1); page.click('#freeBtn'); page.wait_for_url('**/login**'); page.click('.gbtn'); page.wait_for_url('**/tools')
    page.goto(B+'/pricing'); page.wait_for_selector('[data-plan=monthly]'); page.click('[data-plan=monthly]'); page.wait_for_url(M+'/checkout'); urllib.request.urlopen(M+'/__pay').read()
    def run(slug, files, setup=None, name=None):
        page.goto(B+'/'+slug); page.wait_for_selector('#modal', state='visible'); page.set_input_files('#tool input[type=file]', files); time.sleep(0.8)
        if setup: setup()
        out=None
        try:
            with page.expect_download(timeout=45000) as d:
                page.click('#goBtn'); page.wait_for_selector('.dl-main', timeout=45000); page.click('.dl-main')
            out=d.value.path(); fname=d.value.suggested_filename
            ok=True; detail=fname+' '+str(len(open(out,'rb').read()))+' bytes'
        except Exception as e:
            ok=False; detail=(page.inner_text('.status') or str(e))[:150]
        res.append((name or slug, ok, detail)); return out
    run('pdf-to-jpg', ['/tmp/e2e/doc2.pdf'], name='PDF to JPG (pdf.js worker)')
    run('compress-pdf', ['/tmp/e2e/doc2.pdf'], lambda: page.select_option('#level','strong'), name='Compress PDF strong (pdf.js + canvas)')
    prot=run('protect-pdf', ['/tmp/e2e/doc1.pdf'], lambda: [page.locator('#tool input[type=password]').nth(i).fill('Secret123') for i in range(2)], name='Protect PDF (AES-256 WebCrypto)')
    if prot:
        import shutil; shutil.copy(prot,'/tmp/e2e/protected.pdf')
        run('unlock-pdf', ['/tmp/e2e/protected.pdf'], lambda: page.fill('#tool input[type=password]', 'Secret123'), name='Unlock PDF')
    run('split-pdf', ['/tmp/e2e/doc2.pdf'], lambda: page.locator('#tool input[type=text]').first.fill('1-2'), name='Split PDF')
    run('rotate-pdf', ['/tmp/e2e/doc1.pdf'], name='Rotate PDF')
    run('image-to-pdf', ['/tmp/e2e/pic.png'], name='Image to PDF')
    run('png-to-jpg', ['/tmp/e2e/pic.png'], name='PNG to JPG')
    br.close()
bad=0
for n,ok,d in res:
    print(('  ok   ' if ok else '  FAIL ')+n+' -> '+d); bad+= (not ok)
csp=[e for e in errs if 'Content Security' in e or 'PAGEERROR' in e]
print('  '+('ok   ' if not csp else 'FAIL ')+'no CSP/script errors during tool runs', csp[:2] if csp else '')
sys.exit(1 if bad or csp else 0)
