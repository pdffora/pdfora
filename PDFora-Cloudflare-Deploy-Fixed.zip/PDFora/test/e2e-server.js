'use strict';
/* Starts the Cloudflare emulation (real Worker code) on :3921 with FAKE Google (auto-approves) and FAKE Stripe on :3922. For test/e2e*.py only. */
const http = require('http'), crypto = require('crypto');
const { start } = require('./cf-harness');
const APP = 3921, MOCK = 3922;
let nonce = '', refId = '', plan = 'price_m', sub = null;
const sign = (raw) => { const t = Math.floor(Date.now() / 1000); return 't=' + t + ',v1=' + crypto.createHmac('sha256', 'whsec_e2e').update(t + '.' + raw).digest('hex'); };
async function event(type, obj) { const raw = JSON.stringify({ id: 'evt_' + crypto.randomBytes(6).toString('hex'), type, created: Math.floor(Date.now() / 1000), data: { object: obj } }); return fetch('http://localhost:' + APP + '/api/stripe/webhook', { method: 'POST', body: raw, headers: { 'Stripe-Signature': sign(raw) } }); }
const mk = (status, cpe) => ({ id: 'sub_1', customer: 'cus_1', status, metadata: { user_id: refId }, current_period_end: cpe, cancel_at_period_end: false, items: { data: [{ price: { id: plan } }] } });
http.createServer((req, res) => {
  const u = new URL(req.url, 'http://x'); const ch = []; req.on('data', (c) => ch.push(c)); req.on('end', async () => {
    const body = Buffer.concat(ch).toString(), json = (o) => { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(o)); };
    if (u.pathname === '/google/auth') { nonce = u.searchParams.get('nonce'); res.writeHead(302, { Location: u.searchParams.get('redirect_uri') + '?code=ok&state=' + u.searchParams.get('state') }); return res.end(); }
    if (u.pathname === '/google/token') { const pl = { iss: 'https://accounts.google.com', aud: 'cid', exp: Math.floor(Date.now() / 1000) + 600, sub: 'e2e-user', email: 'e2e@example.com', email_verified: true, name: 'E2E Tester', nonce }; return json({ id_token: 'a.' + Buffer.from(JSON.stringify(pl)).toString('base64url') + '.b' }); }
    if (u.pathname === '/v1/checkout/sessions') { const f = new URLSearchParams(body); refId = f.get('client_reference_id'); plan = f.get('line_items[0][price]'); return json({ url: 'http://localhost:' + MOCK + '/checkout' }); }
    if (u.pathname === '/checkout') { res.writeHead(200, { 'Content-Type': 'text/html' }); return res.end('<h1 id="mock-checkout">Mock Stripe Checkout</h1>'); }
    if (u.pathname.startsWith('/v1/subscriptions/') && req.method === 'GET') return json(sub || mk('active', 0));
    if (u.pathname.startsWith('/v1/subscriptions/')) { sub.cancel_at_period_end = /cancel_at_period_end=true/.test(body); return json(sub); }
    if (u.pathname === '/v1/billing_portal/sessions') return json({ url: 'http://localhost:' + MOCK + '/checkout' });
    if (u.pathname === '/__pay') { sub = mk('active', Math.floor(Date.now() / 1000) + 30 * 86400); const r = await event('customer.subscription.created', sub); res.writeHead(200); return res.end(String(r.status)); }
    if (u.pathname === '/__expire') { sub = mk('canceled', Math.floor(Date.now() / 1000) - 10); const r = await event('customer.subscription.deleted', sub); res.writeHead(200); return res.end(String(r.status)); }
    res.writeHead(404); res.end();
  });
}).listen(MOCK, () => start({ port: APP, env: { GOOGLE_CLIENT_ID: 'cid', GOOGLE_CLIENT_SECRET: 'csec', GOOGLE_AUTH_URL: 'http://localhost:' + MOCK + '/google/auth', GOOGLE_TOKEN_URL: 'http://localhost:' + MOCK + '/google/token', STRIPE_SECRET_KEY: 'sk_test', STRIPE_WEBHOOK_SECRET: 'whsec_e2e', STRIPE_PRICE_MONTHLY: 'price_m', STRIPE_PRICE_YEARLY: 'price_y', STRIPE_API_BASE: 'http://localhost:' + MOCK, PRO_DAILY_LIMIT: '50' } }).then(() => console.log('READY')));
