const fs = require('fs'); const { PDFDocument } = require('../public/libs/pdf-lib.min.js');
(async () => { fs.mkdirSync('/tmp/e2e', { recursive: true });
  for (const n of [1, 2]) { const d = await PDFDocument.create(); for (let i = 0; i < n + 1; i++) d.addPage([300, 300]).drawText('Doc ' + n + ' page ' + (i + 1), { x: 30, y: 150 }); fs.writeFileSync('/tmp/e2e/doc' + n + '.pdf', await d.save()); }
  fs.writeFileSync('/tmp/e2e/broken.pdf', Buffer.from('%PDF-1.4\nthis is not really a pdf at all\n%%EOF'));
})();
