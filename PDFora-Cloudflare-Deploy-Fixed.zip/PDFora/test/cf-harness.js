'use strict';
/* TEST-ONLY. Emulates the parts of Cloudflare that PDFora relies on, around the REAL Worker code (src/worker.mjs):
   - D1 database (backed by node:sqlite), - static assets with the settings from wrangler.jsonc (drop-trailing-slash, 404-page, run_worker_first),
   - the public/_headers file.  It cannot prove workerd-specific behaviour: run `npx wrangler dev` for that (see CLOUDFLARE.md). */
const http = require('http'), fs = require('fs'), path = require('path');
const { DatabaseSync } = require('node:sqlite');
const ROOT = path.join(__dirname, '..'), PUBLIC = path.join(ROOT, 'public');

function stripJsonc(src) {
  let out = '', inStr = false;
  for (let i = 0; i < src.length; i++) {
    const ch = src[i], nx = src[i + 1];
    if (inStr) { out += ch; if (ch === '\\') { out += nx; i++; } else if (ch === '"') inStr = false; continue; }
    if (ch === '"') { inStr = true; out += ch; } else if (ch === '/' && nx === '/') { while (i < src.length && src[i] !== '\n') i++; out += '\n'; }
    else if (ch === '/' && nx === '*') { i += 2; while (i < src.length && !(src[i] === '*' && src[i + 1] === '/')) i++; i++; } else out += ch;
  }
  return JSON.parse(out.replace(/,(\s*[}\]])/g, '$1'));
}
const WRANGLER = stripJsonc(fs.readFileSync(path.join(ROOT, 'wrangler.jsonc'), 'utf8'));

function makeD1() {
  const db = new DatabaseSync(':memory:'); db.exec('PRAGMA foreign_keys=ON');
  class S {
    constructor(sql, args) { this.sql = sql; this.args = args || []; }
    bind(...a) { return new S(this.sql, a); }
    async first(col) { const r = db.prepare(this.sql).get(...this.args); return r ? (col ? r[col] : { ...r }) : null; }
    async all() { return { success: true, meta: {}, results: db.prepare(this.sql).all(...this.args).map((r) => ({ ...r })) }; }
    async run() { const r = db.prepare(this.sql).run(...this.args); return { success: true, results: [], meta: { changes: r.changes, last_row_id: Number(r.lastInsertRowid) } }; }
  }
  return { prepare: (sql) => new S(sql), raw: db,
    async batch(list) { db.exec('BEGIN'); try { const out = []; for (const s of list) out.push(await s.run()); db.exec('COMMIT'); return out; } catch (e) { db.exec('ROLLBACK'); throw e; } } };
}

const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json', '.xml': 'application/xml', '.txt': 'text/plain; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon' };
function parseHeadersFile() {
  const rules = []; let cur = null;
  for (const line of fs.readFileSync(path.join(PUBLIC, '_headers'), 'utf8').split('\n')) {
    if (!line.trim() || line.trim().startsWith('#')) continue;
    if (!/^\s/.test(line)) { cur = { pattern: line.trim(), headers: [] }; rules.push(cur); } else { const i = line.indexOf(':'); cur.headers.push([line.slice(0, i).trim(), line.slice(i + 1).trim()]); }
  }
  return rules;
}
const HEADER_RULES = parseHeadersFile();
const matches = (pat, p) => (pat.endsWith('*') ? p.startsWith(pat.slice(0, -1)) : p === pat);

function assetsFetch(req) {
  const url = new URL(req.url); let p = url.pathname;
  const file = (rel) => { const f = path.join(PUBLIC, rel); return f.startsWith(PUBLIC + path.sep) && fs.existsSync(f) && fs.statSync(f).isFile() ? f : null; };
  const send = (status, f, extra) => {
    const h = new Headers({ 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream', 'Cache-Control': 'public, max-age=0, must-revalidate' });
    HEADER_RULES.forEach((r) => { if (matches(r.pattern, url.pathname)) r.headers.forEach(([k, v]) => h.set(k, v)); });
    return new Response(req.method === 'HEAD' ? null : fs.readFileSync(f), { status, headers: h });
  };
  const redir = (to) => new Response(null, { status: 308, headers: { Location: to + url.search } });
  if (p.split('/').some((s) => s.startsWith('_') && s !== '')) return send(404, file('404.html'));   // _headers etc. are never served
  // html_handling: "drop-trailing-slash"
  if (p === '/index.html') return redir('/');
  if (p.endsWith('.html') && file(p.slice(1))) return redir(p.slice(0, -5));
  if (p.length > 1 && p.endsWith('/') && (file(p.slice(1, -1) + '.html') || file(p.slice(1) + 'index.html'))) return redir(p.replace(/\/+$/, ''));
  const f = p === '/' ? file('index.html') : (file(p.slice(1)) || file(p.slice(1) + '.html') || file(p.slice(1) + '/index.html'));
  if (f) return send(200, f);
  return send(404, file('404.html'));   // not_found_handling: "404-page"
}
const workerFirst = (p) => WRANGLER.assets.run_worker_first.some((pat) => matches(pat, p));

async function start(opts) {
  const { default: worker } = await import('../src/worker.mjs');
  const d1 = makeD1(); const env = Object.assign({ DB: d1, ASSETS: { fetch: assetsFetch } }, WRANGLER.vars, opts.env || {});
  Object.keys(env).forEach((k) => { if (env[k] === '' ) delete env[k]; }); env.DB = d1; env.ASSETS = { fetch: assetsFetch };
  Object.assign(env, opts.env || {});
  const server = http.createServer(async (nreq, nres) => {
    try {
      const chunks = []; for await (const c of nreq) chunks.push(c);
      const headers = new Headers(); for (const [k, v] of Object.entries(nreq.headers)) headers.set(k, Array.isArray(v) ? v.join(', ') : v);
      headers.set('CF-Connecting-IP', nreq.socket.remoteAddress || '1.2.3.4');
      const url = 'http://' + nreq.headers.host + nreq.url, has = !['GET', 'HEAD'].includes(nreq.method);
      const req = new Request(url, { method: nreq.method, headers, body: has ? Buffer.concat(chunks) : undefined });
      const p = new URL(url).pathname;
      const res = workerFirst(p) ? await worker.fetch(req, env, {}) : await assetsFetch(req);   // run_worker_first
      const out = {}; res.headers.forEach((v, k) => { if (k !== 'set-cookie') out[k] = v; });
      const sc = res.headers.getSetCookie(); if (sc.length) out['set-cookie'] = sc;
      nres.writeHead(res.status, out); nres.end(Buffer.from(await res.arrayBuffer()));
    } catch (e) { console.error(e); nres.writeHead(500); nres.end('harness error'); }
  });
  await new Promise((r) => server.listen(opts.port, r));
  return { server, d1, env, worker, wrangler: WRANGLER };
}
module.exports = { start, makeD1, WRANGLER, stripJsonc };
