'use strict';
/* Worker + routing tests (real src/worker.mjs, Cloudflare emulation, FAKE Google/Stripe).  Run: node test/worker.test.js */
const http = require('http'), crypto = require('crypto');
const { start } = require('./cf-harness');
const APP = 3911, MOCK = 3912;
let pass = 0, failN = 0;
const ok = (c, m) => { if (c) { pass++; console.log('  ok   ' + m); } else { failN++; console.log('  FAIL ' + m); } };
let nonce = '', gUser = { sub: 'g-123', email: 'Ann@Example.com', name: 'Ann Tester' }, lastStripeBody = '', stripeSub = null;
const mock = http.createServer((req, res) => {
  const chunks = []; req.on('data', (c) => chunks.push(c)); req.on('end', () => {
    const body = Buffer.concat(chunks).toString(), u = req.url, json = (o) => { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(o)); };
    if (u === '/google/token') {
      const f = new URLSearchParams(body); if (f.get('client_secret') !== 'test-secret' || !f.get('code_verifier')) { res.writeHead(400); return res.end('{}'); }
      return json({ id_token: 'x.' + Buffer.from(JSON.stringify({ iss: 'https://accounts.google.com', aud: 'test-client', exp: Math.floor(Date.now() / 1000) + 600, sub: gUser.sub, email: gUser.email, email_verified: true, name: gUser.name, nonce })).toString('base64url') + '.y' });
    }
    if (u === '/v1/checkout/sessions') { lastStripeBody = body; return json({ url: 'https://checkout.stripe.test/c/abc' }); }
    if (u.startsWith('/v1/subscriptions/') && req.method === 'POST') { lastStripeBody = body; stripeSub.cancel_at_period_end = /cancel_at_period_end=true/.test(body); return json(stripeSub); }
    if (u.startsWith('/v1/subscriptions/')) return json(stripeSub);
    res.writeHead(404); res.end('{}');
  });
});
let jar = '';
async function call(method, p, opts) {
  opts = opts || {}; const h = Object.assign({}, opts.headers || {}); if (jar && !opts.nojar) h.Cookie = jar;
  if (opts.json) { h['Content-Type'] = 'application/json'; h['X-PDFora'] = '1'; }
  const r = await fetch('http://localhost:' + APP + p, { method, headers: h, body: opts.json ? JSON.stringify(opts.json) : opts.body, redirect: 'manual' });
  const sc = r.headers.getSetCookie();
  if (sc.length && !opts.nojar) { const m = new Map(jar.split('; ').filter(Boolean).map((x) => x.split(/=(.*)/s).slice(0, 2))); sc.forEach((c) => { const [kv] = c.split(';'); const [k, v] = kv.split(/=(.*)/s); if (/Max-Age=0/.test(c)) m.delete(k); else m.set(k, v); }); jar = [...m].map(([k, v]) => k + '=' + v).join('; '); }
  const t = await r.text(); let data = t; try { data = JSON.parse(t); } catch (e) { /* html */ }
  return { status: r.status, data, headers: r.headers };
}
const sign = (payload, secret, ts) => { ts = ts || Math.floor(Date.now() / 1000); return 't=' + ts + ',v1=' + crypto.createHmac('sha256', secret || 'whsec_test').update(ts + '.' + payload).digest('hex'); };
let evn = 0;
const sendEvent = (type, obj, created) => { const raw = JSON.stringify({ id: 'evt_' + (++evn), type, created: created || Math.floor(Date.now() / 1000), data: { object: obj } }); return call('POST', '/api/stripe/webhook', { body: raw, headers: { 'Stripe-Signature': sign(raw), 'Content-Type': 'application/json' }, nojar: true }); };
async function login(user) {
  gUser = user; jar = ''; let r = await call('GET', '/auth/google?next=/merge-pdf'); const q = new URL(r.headers.get('location')).searchParams; nonce = q.get('nonce');
  return call('GET', '/auth/google/callback?code=c&state=' + q.get('state'));
}

(async () => {
  await new Promise((r) => mock.listen(MOCK, r));
  const cf = await start({ port: APP, env: { GOOGLE_CLIENT_ID: 'test-client', GOOGLE_CLIENT_SECRET: 'test-secret', GOOGLE_AUTH_URL: 'http://localhost:' + MOCK + '/google/auth', GOOGLE_TOKEN_URL: 'http://localhost:' + MOCK + '/google/token', STRIPE_SECRET_KEY: 'sk_test_x', STRIPE_WEBHOOK_SECRET: 'whsec_test', STRIPE_PRICE_MONTHLY: 'price_month', STRIPE_PRICE_YEARLY: 'price_year', STRIPE_API_BASE: 'http://localhost:' + MOCK, PRO_DAILY_LIMIT: '5' } });
  const sql = (q, ...a) => cf.d1.raw.prepare(q).get(...a);
  try {
    console.log('Cloudflare configuration');
    const W = cf.wrangler;
    ok(W.main === 'src/worker.mjs' && W.assets.directory === './public' && W.assets.binding === 'ASSETS', 'wrangler.jsonc: Worker entry + static assets directory + ASSETS binding');
    ok(W.assets.html_handling === 'drop-trailing-slash' && W.assets.not_found_handling === '404-page', 'wrangler.jsonc: clean URLs and a real 404 page');
    ok(JSON.stringify(W.assets.run_worker_first) === JSON.stringify(['/api/*', '/auth/*', '/healthz']), 'only /api, /auth and /healthz invoke the Worker (static files are free and unmetered)');
    ok(W.d1_databases[0].binding === 'DB' && /^\d{1,2} \d{1,2} \* \* \*$/.test(W.triggers.crons[0]), 'D1 binding "DB" and a daily cron are declared');

    console.log('Routing: every page, refresh and direct links');
    const sm = (await call('GET', '/sitemap.xml')).data; const paths = [...sm.matchAll(/<loc>([^<]+)<\/loc>/g)].map((m) => new URL(m[1]).pathname);
    const toolPaths = paths.filter((p) => !['/', '/tools', '/pricing', '/about', '/contact', '/privacy-policy', '/terms-of-service'].includes(p));
    ok(toolPaths.length === 25, 'sitemap lists the 25 tool URLs');
    let bad = []; for (const p of paths) { const r = await call('GET', p, { nojar: true }); if (r.status !== 200 || !/<title>/.test(r.data)) bad.push(p + ':' + r.status); }
    ok(!bad.length, 'all ' + paths.length + ' sitemap URLs return 200 when opened directly (as on refresh)' + (bad.length ? ' ' + bad : ''));
    for (const p of ['/login', '/account', '/subscription', '/404']) { const r = await call('GET', p, { nojar: true }); if (p !== '/404') ok(r.status === 200, p + ' page opens directly'); }
    let r = await call('GET', '/merge-pdf.html', { nojar: true }); ok(r.status === 308 && r.headers.get('location') === '/merge-pdf', '/merge-pdf.html redirects to the clean URL');
    r = await call('GET', '/merge-pdf/', { nojar: true }); ok(r.status === 308 && r.headers.get('location') === '/merge-pdf', 'trailing slash redirects to the clean URL');
    r = await call('GET', '/index.html', { nojar: true }); ok(r.status === 308 && r.headers.get('location') === '/', '/index.html redirects to /');
    r = await call('GET', '/definitely-missing', { nojar: true }); ok(r.status === 404 && /page not found/i.test(r.data), 'unknown URL: custom 404 page with a real 404 status');
    r = await call('GET', '/libs/pdf-lib.min.js', { nojar: true }); ok(r.status === 200 && /max-age=2592000/.test(r.headers.get('cache-control')), 'tool libraries are served with long cache headers');
    ok(!!r.headers.get('content-security-policy') && r.headers.get('x-content-type-options') === 'nosniff', 'security headers (_headers) apply to static files');
    for (const p of ['/_headers', '/wrangler.jsonc', '/src/worker.mjs', '/..%2fwrangler.jsonc']) { r = await call('GET', p, { nojar: true }); ok(r.status === 404, p + ' is not publicly reachable'); }

    console.log('Google login');
    r = await call('GET', '/api/me', { nojar: true }); ok(r.data.user === null, 'logged-out /api/me has no user');
    r = await call('POST', '/api/usage/reserve', { json: { tool: 'merge-pdf' }, nojar: true }); ok(r.status === 401, 'usage API needs login (401)');
    r = await call('GET', '/auth/google?next=/merge-pdf'); const loc = new URL(r.headers.get('location')); const st = loc.searchParams.get('state'); nonce = loc.searchParams.get('nonce');
    ok(loc.origin === 'http://localhost:' + MOCK && loc.searchParams.get('code_challenge_method') === 'S256' && loc.searchParams.get('redirect_uri') === 'http://localhost:' + APP + '/auth/google/callback', 'redirects to Google with PKCE and this site\'s own callback URL');
    r = await call('GET', '/auth/google/callback?code=c&state=' + st, { nojar: true }); ok(/error=state/.test(r.headers.get('location')), 'callback without the browser-bound cookie is rejected');
    r = await call('GET', '/auth/google/callback?code=c&state=' + st); ok(r.headers.get('location') === '/merge-pdf' && /sid=/.test(jar), 'login completes, session cookie set, returns to the tool page');
    r = await call('GET', '/auth/google/callback?code=c&state=' + st); ok(/error=state/.test(r.headers.get('location')), 'state is single-use');
    r = await call('GET', '/auth/google?next=//evil.com'); const q2 = new URL(r.headers.get('location')).searchParams; nonce = q2.get('nonce');
    r = await call('GET', '/auth/google/callback?code=c&state=' + q2.get('state')); ok(r.headers.get('location') === '/', 'open-redirect "next" is neutralised');
    r = await call('GET', '/api/me'); ok(r.data.user.email === 'ann@example.com' && r.data.plan === 'free' && r.data.usage.remaining === 3, 'session works; Free plan shows 3 remaining');
    const jarAnn = jar; const ann = sql('SELECT id FROM users WHERE email=?', 'ann@example.com').id;

    console.log('Free-plan limit (enforced in the Worker + D1)');
    r = await call('POST', '/api/usage/reserve', { headers: { 'Content-Type': 'application/json' }, body: '{}' }); ok(r.status === 403, 'missing CSRF header rejected');
    r = await call('POST', '/api/usage/reserve', { json: { tool: 'x' }, headers: { Origin: 'http://evil.example' } }); ok(r.status === 403, 'cross-origin request rejected');
    const ops = []; for (let i = 0; i < 3; i++) { r = await call('POST', '/api/usage/reserve', { json: { tool: 'merge-pdf' } }); ok(r.status === 200, 'reserve #' + (i + 1)); ops.push(r.data.opId); }
    r = await call('POST', '/api/usage/reserve', { json: { tool: 'merge-pdf' } }); ok(r.status === 402 && r.data.error === 'limit_reached', '4th operation blocked with 402');
    r = await call('POST', '/api/usage/release', { json: { opId: ops[2] } }); ok(r.status === 200 && r.data.usage.remaining === 1, 'failed operation released -> does not consume allowance');
    r = await call('POST', '/api/usage/commit', { json: { opId: ops[0] } }); ok(r.data.usage.used === 2, 'commit keeps it counted');
    r = await call('POST', '/api/usage/release', { json: { opId: ops[0] } }); ok(r.data.already === true && r.data.usage.used === 2, 'a committed operation cannot be refunded');
    r = await call('POST', '/api/usage/commit', { json: { opId: 'nope' } }); ok(r.status === 404, 'unknown operation id rejected');
    r = await call('POST', '/api/usage/reserve', { json: { tool: 'x' } }); ok(r.status === 200, 'released slot reusable');
    r = await call('POST', '/api/usage/reserve', { json: { tool: 'x' } }); ok(r.status === 402, 'blocked again at 3');
    await login({ sub: 'g-999', email: 'bob@example.com', name: 'Bob' }); const jarBob = jar;
    r = await call('GET', '/api/me'); ok(r.data.user.email === 'bob@example.com' && r.data.usage.remaining === 3, 'second account has its own separate 3/day');
    const results = await Promise.all(Array.from({ length: 10 }, () => call('POST', '/api/usage/reserve', { json: { tool: 'race' } })));
    ok(results.filter((x) => x.status === 200).length === 3 && results.filter((x) => x.status === 402).length === 7, '10 simultaneous requests: exactly 3 succeed (no race past the limit)');
    jar = jarAnn; r = await call('GET', '/api/me'); ok(r.data.usage.remaining === 0, 'first account still at 0 (counts are per account)');

    console.log('Billing');
    stripeSub = null;
    r = await call('POST', '/api/billing/checkout', { json: { plan: 'bogus' } }); ok(r.status === 400, 'unknown plan rejected');
    r = await call('POST', '/api/billing/checkout', { json: { plan: 'yearly' } }); ok(r.status === 200 && /checkout\.stripe\.test/.test(r.data.url), 'checkout session created');
    ok(/price_year/.test(decodeURIComponent(lastStripeBody)) && new RegExp('client_reference_id=' + ann).test(lastStripeBody) && /mode=subscription/.test(lastStripeBody) && lastStripeBody.includes(encodeURIComponent('http://localhost:' + APP + '/subscription?checkout=success')), 'checkout uses yearly price + user id + this site\'s return URLs');
    const period = Math.floor(Date.now() / 1000) + 30 * 86400;
    const subObj = (over) => Object.assign({ id: 'sub_1', customer: 'cus_1', status: 'active', metadata: { user_id: String(ann) }, current_period_end: period, cancel_at_period_end: false, items: { data: [{ price: { id: 'price_year' } }] } }, over || {});
    let raw = JSON.stringify({ id: 'evt_bad', type: 'customer.subscription.created', created: 1, data: { object: subObj() } });
    r = await call('POST', '/api/stripe/webhook', { body: raw, headers: { 'Stripe-Signature': sign(raw, 'wrong') }, nojar: true }); ok(r.status === 400, 'forged webhook signature rejected');
    r = await call('POST', '/api/stripe/webhook', { body: raw, headers: { 'Stripe-Signature': sign(raw, null, Math.floor(Date.now() / 1000) - 3600) }, nojar: true }); ok(r.status === 400, 'stale webhook timestamp rejected');
    r = await call('GET', '/api/me'); ok(r.data.plan === 'free', 'still Free after forged events (no browser-side unlock)');
    r = await sendEvent('customer.subscription.created', subObj()); ok(r.status === 200, 'valid webhook accepted');
    r = await call('GET', '/api/me'); ok(r.data.plan === 'pro' && r.data.interval === 'yearly' && r.data.usage.limit === 5, 'Pro unlocked from the verified webhook; higher limit applies');
    r = await call('POST', '/api/usage/reserve', { json: { tool: 'x' } }); ok(r.status === 200, 'Pro user can continue past the free limit');
    stripeSub = subObj();
    r = await call('POST', '/api/billing/cancel', { json: {} }); ok(r.status === 200, 'cancel at period end');
    r = await call('GET', '/api/me'); ok(r.data.plan === 'pro' && r.data.subscription.cancelAtPeriodEnd === true, 'cancelled but still Pro until the paid-through date');
    r = await call('POST', '/api/account/delete', { json: {} }); ok(r.status === 200, 'account deletion allowed once cancelled');
    ok(!sql('SELECT 1 x FROM users WHERE id=?', ann) && !sql('SELECT 1 x FROM subscriptions WHERE user_id=?', ann) && !sql('SELECT 1 x FROM usage_ops WHERE user_id=?', ann), 'deleting the account removes its usage and subscription rows too');
    jar = jarAnn; r = await call('GET', '/api/me'); ok(r.data.user === null, 'deleted account has no session');

    console.log('Expiry / failure');
    jar = jarBob; const bob = sql('SELECT id FROM users WHERE email=?', 'bob@example.com').id, t = Math.floor(Date.now() / 1000);
    const setSub = (status, cpe) => cf.d1.raw.prepare('INSERT INTO subscriptions(user_id,status,current_period_end,plan,event_ts,updated_at) VALUES(?,?,?,?,0,?) ON CONFLICT(user_id) DO UPDATE SET status=excluded.status,current_period_end=excluded.current_period_end,plan=excluded.plan').run(bob, status, cpe, 'monthly', t);
    const plan = async () => (await call('GET', '/api/me')).data.plan;
    setSub('active', t + 100); ok(await plan() === 'pro', 'active + future period -> Pro');
    setSub('active', t - 100); ok(await plan() === 'free', 'paid-through date passed -> Free');
    setSub('past_due', t + 1000); ok(await plan() === 'free', 'past_due -> not Pro');
    setSub('canceled', t + 1000); ok(await plan() === 'free', 'canceled -> not Pro');
    cf.d1.raw.prepare('UPDATE subscriptions SET stripe_subscription_id=? WHERE user_id=?').run('sub_bob', bob);
    await sendEvent('invoice.payment_failed', { subscription: 'sub_bob' }); ok(sql('SELECT payment_failed p FROM subscriptions WHERE user_id=?', bob).p === 1, 'payment_failed webhook recorded');
    r = await sendEvent('customer.subscription.updated', { id: 'sub_x', customer: 'cus_unknown', status: 'active', metadata: {}, items: { data: [] } }); ok(r.status === 200, 'event for an unknown customer is acknowledged without error');

    console.log('Contact form, housekeeping, safety');
    jar = ''; r = await call('POST', '/api/contact', { json: { name: 'A', email: 'a@b.co', message: 'Hello, this is a test.' } }); ok(r.status === 200, 'contact form stores a message');
    r = await call('POST', '/api/contact', { json: { name: 'A', email: 'bad', message: 'x' } }); ok(r.status === 400, 'invalid contact rejected');
    for (let i = 0; i < 5; i++) r = await call('POST', '/api/contact', { json: { name: 'A', email: 'a@b.co', message: 'Spam spam spam spam' } }); ok(r.status === 429, 'contact form is rate limited (shared across Worker instances via D1)');
    cf.d1.raw.prepare("INSERT INTO sessions(token_hash,user_id,created_at,last_seen,expires_at) VALUES('old',?,1,1,2)").run(bob);
    await cf.worker.scheduled({}, cf.env); ok(!sql("SELECT 1 x FROM sessions WHERE token_hash='old'"), 'scheduled cron removes expired sessions');
    r = await call('POST', '/api/billing/checkout', { json: { plan: 'monthly' }, nojar: true }); ok(r.status === 401, 'billing needs login');
    r = await call('GET', '/api/nothing', { nojar: true }); ok(r.status === 404, 'unknown API route returns 404 JSON');
    r = await call('GET', '/healthz', { nojar: true }); ok(r.status === 200 && r.data.ok === true, 'health check');
  } catch (e) { failN++; console.log('  ERROR', e); }
  console.log('\n' + pass + ' passed, ' + failN + ' failed');
  cf.server.close(); mock.close(); setTimeout(() => process.exit(failN ? 1 : 0), 100);
})();
