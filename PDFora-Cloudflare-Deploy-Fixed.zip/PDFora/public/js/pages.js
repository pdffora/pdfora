/* Page logic for pricing, login, account, subscription and contact. Uses PFSite from site.js. */
(function (g) {
  'use strict';
  const PF = g.PFSite, el = PF.el, page = document.body.getAttribute('data-page'), $ = (id) => document.getElementById(id);
  const qs = new URLSearchParams(location.search);
  const msg = (kind, text) => el('div', { class: 'msg ' + kind, role: kind === 'err' ? 'alert' : 'status', text });
  const GOOGLE_SVG = '<svg viewBox="0 0 48 48" aria-hidden="true"><path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.2 9.1 3.6l6.8-6.8C35.8 2.4 30.3 0 24 0 14.6 0 6.5 5.4 2.6 13.2l7.9 6.1C12.4 13.6 17.7 9.5 24 9.5z"/><path fill="#4285F4" d="M46.5 24.5c0-1.6-.1-3.1-.4-4.5H24v9h12.7c-.6 3-2.3 5.5-4.8 7.2l7.6 5.9c4.4-4.1 7-10.1 7-17.6z"/><path fill="#FBBC05" d="M10.5 28.7A14.5 14.5 0 0 1 9.5 24c0-1.6.3-3.2.8-4.7l-7.9-6.1A24 24 0 0 0 0 24c0 3.9.9 7.5 2.6 10.8l7.9-6.1z"/><path fill="#34A853" d="M24 48c6.5 0 11.9-2.1 15.9-5.8l-7.6-5.9c-2.1 1.4-4.9 2.3-8.3 2.3-6.3 0-11.6-4.1-13.5-9.8l-7.9 6.1C6.5 42.6 14.6 48 24 48z"/></svg>';
  const safeNext = () => { const n = qs.get('next'); return n && /^\/[A-Za-z0-9\-_/.?=&%#]*$/.test(n) && !n.startsWith('//') ? n : '/'; };

  async function goCheckout(plan, out) {
    if (!PF.me.user) { location.href = PF.loginUrl('/pricing'); return; }
    if (!PF.config.payments) { out.replaceChildren(msg('warn', 'Payments are not switched on for this site yet, so you cannot subscribe right now. Please check back soon.')); return; }
    out.replaceChildren(msg('info', 'Opening secure checkout\u2026'));
    const r = await PF.post('/api/billing/checkout', { plan });
    if (r.ok && r.data.url) { location.href = r.data.url; return; }
    out.replaceChildren(msg(r.status === 409 ? 'info' : 'err', r.status === 409 ? 'You already have an active Pro subscription. Manage it on the Subscription page.' : 'We could not start checkout. Nothing was charged. Please try again in a moment.'));
  }
  function pricing() {
    const out = $('pricingMsg');
    ['proLimitA', 'proLimitB'].forEach((id) => { const c = $(id); if (c) c.textContent = PF.config.proLimit + ' per day'; });
    if (qs.get('checkout') === 'cancelled') out.append(msg('info', 'Checkout was cancelled and you have not been charged.'));
    document.querySelectorAll('[data-plan]').forEach((b) => b.addEventListener('click', () => goCheckout(b.getAttribute('data-plan'), out)));
    const free = $('freeBtn'); if (free) free.addEventListener('click', () => { location.href = PF.me.user ? '/tools' : PF.loginUrl('/tools'); });
    if (PF.me.user && PF.me.plan === 'pro') {
      document.querySelectorAll('[data-plan]').forEach((b) => { b.textContent = 'Manage subscription'; b.removeAttribute('data-plan'); b.addEventListener('click', () => { location.href = '/subscription'; }); });
      out.append(msg('ok', 'You are on PDFora Pro. Thank you!'));
    }
    if (!PF.config.payments) out.append(msg('warn', 'Subscriptions are not open yet on this site. The Free plan is available now.'));
  }
  function login() {
    const box = $('loginBox'), errs = { denied: 'Google sign-in was cancelled. You can try again whenever you like.', state: 'That sign-in attempt expired or could not be verified. Please try again.', google: 'Google could not confirm your sign-in. Please try again.', not_configured: 'Google sign-in is not set up on this server yet.' };
    if (PF.me.user) { location.replace(safeNext() === '/' ? '/account' : safeNext()); return; }
    if (qs.get('error')) box.append(msg('err', errs[qs.get('error')] || 'Sign-in failed. Please try again.'));
    if (!PF.config.google) { box.append(msg('warn', 'Google sign-in is not available on this server yet. The site owner needs to add Google OAuth credentials.')); return; }
    const a = el('a', { class: 'gbtn', href: '/auth/google?next=' + encodeURIComponent(safeNext()) }); a.innerHTML = GOOGLE_SVG; a.append('Continue with Google');
    box.append(el('div', { class: 'center' }, a));
  }
  function account() {
    if (!PF.me.user) { location.replace(PF.loginUrl('/account')); return; }
    const me = PF.me, u = me.usage, box = $('accountBox');
    const pct = Math.round((u.used / u.limit) * 100);
    box.append(el('div', { class: 'card' }, el('h2', { text: 'Your account' }), el('dl', { class: 'kv' }, el('dt', { text: 'Name' }), el('dd', { text: me.user.name || '\u2014' }), el('dt', { text: 'Email' }), el('dd', { text: me.user.email }), el('dt', { text: 'Sign-in' }), el('dd', { text: 'Google' }))));
    box.append(el('div', { class: 'card' }, el('h2', { text: me.plan === 'pro' ? 'PDFora Pro' : 'Free plan' }),
      el('p', { text: u.remaining + ' of ' + u.limit + ' operations left today. Resets at 00:00 UTC (in ' + PF.untilReset(u.resetsAt) + ').' }),
      el('div', { class: 'meter', role: 'progressbar', 'aria-valuemin': '0', 'aria-valuemax': '100', 'aria-valuenow': String(pct) }, el('i', { style: 'width:' + pct + '%' })),
      el('div', { class: 'row-actions' }, el('a', { class: 'btn', href: '/tools', text: 'Use a tool' }), el('a', { class: 'btn ghost', href: me.plan === 'pro' ? '/subscription' : '/pricing', text: me.plan === 'pro' ? 'Manage subscription' : 'Upgrade to Pro' }))));
    const out = el('div'); const del = el('button', { class: 'btn danger', type: 'button', text: 'Delete my account', onclick: async () => {
      if (!confirm('Delete your PDFora account and usage history? This cannot be undone.')) return;
      const r = await PF.post('/api/account/delete'); if (r.ok) { location.href = '/?deleted=1'; return; }
      out.replaceChildren(msg('err', r.data.error === 'cancel_subscription_first' ? 'Please cancel your Pro subscription first (Subscription page). You can delete the account right after.' : 'Could not delete the account. Please try again.'));
    } });
    box.append(el('div', { class: 'card' }, el('h2', { text: 'Session & data' }), el('p', { text: 'Log out on this device, or permanently delete your account. PDFora never stores your documents \u2014 they stay in your browser.' }), out, el('div', { class: 'row-actions' }, el('button', { class: 'btn ghost', type: 'button', text: 'Log out', onclick: PF.logout }), del)));
  }
  async function subscription() {
    if (!PF.me.user) { location.replace(PF.loginUrl('/subscription')); return; }
    const box = $('subBox'), top = $('subMsg');
    if (qs.get('checkout') === 'success' && PF.me.plan !== 'pro') {
      top.replaceChildren(msg('info', 'Thanks! We are confirming your payment with our payment provider\u2026 this normally takes a few seconds.'));
      for (let i = 0; i < 20 && PF.me.plan !== 'pro'; i++) { await new Promise((r) => setTimeout(r, 2000)); await PF.load(); }
      top.replaceChildren(PF.me.plan === 'pro' ? msg('ok', 'Payment confirmed \u2014 PDFora Pro is now active on your account.') : msg('warn', 'We have not received the payment confirmation yet. If you completed checkout, Pro will switch on automatically as soon as it arrives \u2014 refresh this page in a minute. You will not be charged twice.'));
    } else if (qs.get('checkout') === 'success') top.replaceChildren(msg('ok', 'Payment confirmed \u2014 PDFora Pro is now active on your account.'));
    draw();
    function draw() {
      box.replaceChildren(); const me = PF.me, s = me.subscription, out = el('div');
      const portal = el('button', { class: 'btn ghost', type: 'button', text: 'Payment method & invoices', onclick: async () => { const r = await PF.post('/api/billing/portal'); if (r.ok && r.data.url) location.href = r.data.url; else out.replaceChildren(msg('err', 'Could not open the billing portal. Please try again.')); } });
      if (me.plan === 'pro') {
        const label = s.plan === 'yearly' ? 'Pro Yearly ($71.99 / year)' : 'Pro Monthly ($9.99 / month)';
        const kv = el('dl', { class: 'kv' }, el('dt', { text: 'Plan' }), el('dd', { text: label }), el('dt', { text: s.cancelAtPeriodEnd ? 'Access until' : 'Renews on' }), el('dd', { text: PF.date(s.currentPeriodEnd) }), el('dt', { text: 'Daily allowance' }), el('dd', { text: me.usage.limit + ' operations' }));
        const actions = el('div', { class: 'row-actions' });
        if (s.cancelAtPeriodEnd) {
          actions.append(el('button', { class: 'btn', type: 'button', text: 'Keep my subscription', onclick: async () => { const r = await PF.post('/api/billing/resume'); if (r.ok) { await PF.load(); draw(); } else out.replaceChildren(msg('err', 'Could not update the subscription. Please try again.')); } }));
        } else {
          actions.append(el('button', { class: 'btn danger', type: 'button', text: 'Cancel subscription', onclick: async () => { if (!confirm('Cancel PDFora Pro? You keep Pro until ' + PF.date(s.currentPeriodEnd) + ', then your account returns to the Free plan.')) return; const r = await PF.post('/api/billing/cancel'); if (r.ok) { await PF.load(); draw(); } else out.replaceChildren(msg('err', 'Could not cancel the subscription. Please try again.')); } }));
        }
        actions.append(portal);
        box.append(el('div', { class: 'card' }, el('h2', { text: 'PDFora Pro is active' }), kv, s.cancelAtPeriodEnd ? msg('warn', 'Your subscription is cancelled and will not renew. You keep Pro until ' + PF.date(s.currentPeriodEnd) + ', then your account returns to the Free plan.') : null, s.paymentFailed ? msg('err', 'Your last payment did not go through. Please update your payment method to keep Pro.') : null, out, actions));
      } else {
        const notes = [];
        if (s && s.paymentFailed) notes.push(msg('err', 'Your last payment failed, so Pro is not active. Update your payment method to restore it.'));
        else if (s && s.currentPeriodEnd) notes.push(msg('warn', 'Your Pro subscription ended on ' + PF.date(s.currentPeriodEnd) + '. Your account is on the Free plan (' + me.usage.limit + ' operations per day).'));
        const actions = el('div', { class: 'row-actions' }, el('a', { class: 'btn', href: '/pricing', text: 'See Pro plans' })); if (s) actions.append(portal);
        box.append(el('div', { class: 'card' }, el('h2', { text: 'Free plan' }), el('p', { text: 'You get ' + me.usage.limit + ' successful operations per day. Upgrade for a higher daily limit, no ads and priority processing where supported.' }), ...notes, out, actions));
      }
    }
  }
  function contact() {
    const f = $('contactForm'), out = $('contactMsg');
    f.addEventListener('submit', async (e) => {
      e.preventDefault(); const btn = f.querySelector('button'); btn.disabled = true;
      const r = await PF.post('/api/contact', { name: f.name.value, email: f.email.value, message: f.message.value });
      btn.disabled = false;
      if (r.ok) { f.reset(); out.replaceChildren(msg('ok', 'Thank you \u2014 your message has been sent. We will reply by email.')); }
      else out.replaceChildren(msg('err', r.status === 429 ? 'Too many messages in a short time. Please try again later.' : 'Please enter a valid email address and a message of at least 10 characters.'));
    });
  }
  document.addEventListener('DOMContentLoaded', async () => {
    await PF.ready; if (qs.get('deleted')) return;
    ({ pricing, login, account, subscription, contact })[page] && ({ pricing, login, account, subscription, contact })[page]();
  });
})(window);
