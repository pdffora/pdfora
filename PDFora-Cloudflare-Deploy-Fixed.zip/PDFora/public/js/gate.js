/* PDFora gate: puts login + the server-side daily allowance in front of the existing tools WITHOUT editing them.
   Each tool's run() is wrapped: reserve an operation on the server -> run the original tool -> commit on success / release on failure. */
(function (g) {
  'use strict';
  const P = g.PDFora, PF = g.PFSite; if (!P || !P.tools || !PF) return;
  const el = PF.el, bySlug = (s) => P.tools.find((t) => t.slug === s);
  const pageTool = document.body.getAttribute('data-tool') || '';
  let inflight = null, allow = null;

  /* ---------- dialogs ---------- */
  function overlay(title, text, actions) {
    close();
    const o = el('div', { class: 'pf-overlay', id: 'pfOverlay', role: 'dialog', 'aria-modal': 'true', 'aria-labelledby': 'pfOT' },
      el('div', { class: 'pf-dialog' }, el('h2', { id: 'pfOT', text: title }), el('p', { text }), el('div', { class: 'row-actions' }, ...actions)));
    document.body.append(o); const f = o.querySelector('a,button'); if (f) f.focus();
    function close() { const x = document.getElementById('pfOverlay'); if (x) x.remove(); }
    return o;
  }
  const closeOverlay = () => { const x = document.getElementById('pfOverlay'); if (x) x.remove(); };
  const closeBtn = () => el('button', { class: 'btn ghost', type: 'button', text: 'Close', onclick: closeOverlay });
  function googleLink(next) { return el('a', { class: 'gbtn', href: '/auth/google?next=' + encodeURIComponent(next || location.pathname), text: 'Continue with Google' }); }
  function showLogin() {
    const ok = PF.config.google;
    overlay('Log in to use this tool', ok ? 'Browsing is open to everyone, but using a tool needs a free PDFora account. Continue with Google \u2014 the free plan includes 3 successful operations per day.' : 'Sign-in is not available on this server yet (the site owner has not connected Google sign-in).', ok ? [googleLink(location.pathname), closeBtn()] : [closeBtn()]);
  }
  function showLimit(usage, plan) {
    const pro = plan === 'pro';
    const text = pro ? 'You have used all ' + usage.limit + ' operations included in your Pro plan today. Your allowance resets at 00:00 UTC (in ' + PF.untilReset(usage.resetsAt) + ').'
      : 'You have used all ' + usage.limit + ' free operations for today. Upgrade to PDFora Pro for a higher daily limit and no ads, or come back in ' + PF.untilReset(usage.resetsAt) + ' when your allowance resets (00:00 UTC).';
    overlay(pro ? 'Daily Pro limit reached' : 'Daily free limit reached', text, pro ? [closeBtn()] : [el('a', { class: 'btn', href: '/pricing', text: 'See Pro plans' }), closeBtn()]);
  }

  /* ---------- allowance wrapper around every existing tool (tool files stay untouched) ---------- */
  async function reserve(slug) {
    let r; try { r = await PF.post('/api/usage/reserve', { tool: slug }); } catch (e) { throw new Error('Could not reach PDFora to check your daily allowance. Check your connection and try again.'); }
    if (r.status === 401) { PF.me = { user: null }; showLogin(); throw new Error('Please log in with Google to use this tool.'); }
    if (r.status === 402) { PF.setUsage(r.data.usage); showLimit(r.data.usage, r.data.plan); throw new Error('Daily limit reached. ' + (r.data.plan === 'pro' ? 'Your allowance resets at 00:00 UTC.' : 'Upgrade to Pro or try again tomorrow.')); }
    if (!r.ok) throw new Error('Could not check your daily allowance right now. Please try again in a moment.');
    PF.setUsage(r.data.usage); return r.data.opId;
  }
  async function settle(kind, opId) {
    for (let i = 0; i < 3; i++) { try { const r = await PF.post('/api/usage/' + kind, { opId }); if (r.ok || r.status === 404 || r.status === 429) return r; } catch (e) { /* retry */ } await new Promise((res) => setTimeout(res, 400 * (i + 1))); }
    return null;
  }
  P.tools.forEach((t) => {
    const original = t.run; if (typeof original !== 'function') return;
    t.run = async function (files, ctx) {
      const opId = await reserve(t.slug); inflight = opId;
      let outs;
      try { outs = await original.call(this, files, ctx); }
      catch (e) { inflight = null; const r = await settle('release', opId); if (r && r.ok) PF.setUsage(r.data.usage); quota('Nothing was deducted from your daily allowance.'); throw e; }
      inflight = null;
      if (!outs || !outs.length) { const r = await settle('release', opId); if (r && r.ok) PF.setUsage(r.data.usage); quota('Nothing was deducted from your daily allowance.'); return outs; }
      const r = await settle('commit', opId); if (r && r.ok) PF.setUsage(r.data.usage);
      quota('Done \u2713 ', 'good'); return outs;
    };
  });
  g.addEventListener('pagehide', () => { if (inflight) { try { fetch('/api/usage/release', { method: 'POST', keepalive: true, credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-PDFora': '1' }, body: JSON.stringify({ opId: inflight }) }); } catch (e) { /* best effort */ } } });

  /* ---------- quota line inside the tool window ---------- */
  function quota(prefix, kind) {
    const q = document.getElementById('pfQuota'); if (!q) return;
    const me = PF.me; if (!me || !me.user) { q.hidden = true; return; }
    q.hidden = false; q.className = 'quota' + (kind ? ' ' + kind : (me.usage.remaining === 0 ? ' low' : ''));
    q.textContent = (prefix ? prefix + ' ' : '') + PF.quotaText(me);
  }
  g.addEventListener('pf:me', () => { const q = document.getElementById('pfQuota'); if (q && !q.hidden) { const keep = q.textContent.startsWith('Nothing') || q.textContent.startsWith('Done'); if (!keep) quota(''); } updateGateNote(); });

  /* ---------- Clear all files (browser-side; PDFora never uploads files, so there is no server copy to delete) ---------- */
  const toolRoot = document.getElementById('tool');
  function syncClear() {
    if (!toolRoot) return; const count = toolRoot.querySelector('.file-count'); if (!count) return;
    let b = document.getElementById('pfClearAll');
    if (!b) {
      b = el('button', { type: 'button', class: 'secondary sm pf-clear', id: 'pfClearAll', text: 'Clear all files', onclick: () => {
        if (P.app.busy()) return; const n = P.app.entries.length; P.app.entries.slice().forEach((e) => P.app.remove(e.id));
        P.app.say(n + (n === 1 ? ' file was' : ' files were') + ' removed from this page. Your files are only ever held in your browser \u2014 PDFora has no server copy.', 'warn'); updateClear();
      } });
      count.after(b); quota('');
    }
    updateClear();
  }
  function updateClear() { const b = document.getElementById('pfClearAll'); if (b) b.hidden = !(P.app.entries && P.app.entries.length); }
  if (toolRoot) new MutationObserver(() => { syncClear(); }).observe(toolRoot, { childList: true, subtree: true });

  /* ---------- opening tools: login first, one URL per tool ---------- */
  const authed = () => !!(PF.me && PF.me.user);
  function openHere(slug) { allow = slug; g.location.hash = '#' + slug; }
  function handleNav(e) {
    const slug = decodeURIComponent((location.hash || '').replace(/^#/, '')); if (!slug || !bySlug(slug)) return;
    if (allow === slug) { allow = null; return; }
    e.stopImmediatePropagation();
    if (slug !== pageTool) { location.assign('/' + slug); return; }       // each tool lives at its own address
    history.replaceState(null, '', location.pathname + location.search);
    if (authed()) openHere(slug); else showLogin();
  }
  g.addEventListener('hashchange', handleNav, true); g.addEventListener('popstate', handleNav, true);
  const grid = document.getElementById('tools');
  if (grid) grid.addEventListener('click', (e) => {
    const a = e.target.closest('a.tool'); if (!a || e.button || e.ctrlKey || e.metaKey || e.shiftKey) return;
    e.preventDefault(); e.stopImmediatePropagation(); location.assign('/' + a.dataset.slug);
  }, true);
  document.addEventListener('DOMContentLoaded', () => { document.querySelectorAll('a.tool[data-slug]').forEach((a) => a.setAttribute('href', '/' + a.dataset.slug)); });

  /* ---------- the tool page itself ---------- */
  function updateGateNote() {
    const note = document.getElementById('gateNote'); if (!note) return;
    if (!PF.loaded) return;
    note.textContent = authed() ? PF.quotaText(PF.me) + '.' : (PF.config.google ? 'Free with a Google account \u00b7 ' + PF.config.freeLimit + ' successful operations per day.' : 'Sign-in is not set up on this server yet.');
  }
  async function bootToolPage() {
    await PF.ready; const btn = document.getElementById('openToolBtn'); const slug = pageTool;
    updateGateNote();
    if (btn) btn.addEventListener('click', () => { if (authed()) openHere(slug); else location.href = PF.config.google ? '/auth/google?next=' + encodeURIComponent('/' + slug) : '/login?next=' + encodeURIComponent('/' + slug); });
    if (btn) btn.textContent = authed() ? 'Open ' + (bySlug(slug) ? bySlug(slug).name : 'tool') : 'Continue with Google to use ' + (bySlug(slug) ? bySlug(slug).name : 'this tool');
    if (authed()) openHere(slug);                                      // after login the tool opens straight away
  }
  document.addEventListener('DOMContentLoaded', () => {
    if (pageTool) bootToolPage();
    else if (g.__pfHash && bySlug(g.__pfHash)) location.replace('/' + g.__pfHash); // old #slug links lead to the new page URLs
  });
})(window);
