/* PDFora tool definitions: image tools */
(function (g) {
  'use strict';
  const P = (g.PDFora = g.PDFora || {});
  const T = (P.T = P.T || {});
  const row = P.row, plural = P.plural, perFile = P.perFile;
  const IMG = ['png', 'jpg', 'webp', 'gif', 'bmp', 'avif'];
  const ACC = { png: '.png,image/png', jpg: '.jpg,.jpeg,.jfif,image/jpeg', webp: '.webp,image/webp', any: 'image/*,.jpg,.jpeg,.png,.webp,.gif,.bmp,.avif' };
  const imgTool = (o) => Object.assign({ kinds: IMG, acceptText: 'images (JPG, PNG, WebP, GIF, BMP or AVIF)', accept: ACC.any, multi: true, min: 1 }, o);
  const range = (id, label, min, max, val, hint) => row(label, '<div class="range"><input id="' + id + '" type="range" min="' + min + '" max="' + max + '" value="' + val + '" oninput="this.nextElementSibling.textContent=this.value+\'%\'"><output>' + val + '%</output></div>', hint);
  const bgOpt = () => row('Background for transparent areas', '<input id="bg" type="color" value="#ffffff">', 'JPG has no transparency, so transparent areas are filled with this color.');
  const MIME = { jpg: 'image/jpeg', png: 'image/png', webp: 'image/webp' };
  const EXT = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp' };
  const pct = (a, b) => (b < a ? '\u2212' : '+') + Math.abs(Math.round(100 - 100 * b / a)) + '%';

  async function encode(canvas, type, q, f) {
    const blob = await P.canvasBlob(canvas, type, q);
    if (!blob) throw new Error('Your browser could not create the image for "' + f.name + '".');
    if (type === 'image/webp' && blob.type !== 'image/webp') throw new Error('Your browser cannot create WebP images. Please use a current version of Chrome, Edge or Firefox.');
    return blob;
  }

  /* generic converter */
  function converter(o) {
    return imgTool(Object.assign({
      zipName: 'PDFora-images', btn: (n) => o.label + ' ' + n + (n === 1 ? ' Image' : ' Images'),
      async run(files, ctx) {
        const type = o.type; const q = o.quality === false ? undefined : ctx.num('q', 92) / 100; const fill = type === 'image/jpeg' ? (ctx.val('bg') || '#ffffff') : undefined;
        return perFile(files, ctx, async (f) => {
          const im = await P.loadImage(f); const c = P.drawToCanvas(im, im.w, im.h, { fill }); im.close();
          const blob = await encode(c, type, q, f);
          return { name: P.baseName(f.name) + '.' + EXT[type], blob, info: c.width + ' \u00d7 ' + c.height + ' px \u00b7 ' + P.fmtSize(f.size) + ' \u2192 ' + P.fmtSize(blob.size) };
        });
      }
    }, o.def));
  }

  /* ---------------- 18. PNG to JPG ---------------- */
  T.png2jpg = converter({ type: 'image/jpeg', label: 'Convert', def: { slug: 'png-to-jpg', name: 'PNG to JPG', icon: '\u25a7', desc: 'Convert PNG images to JPG.', kw: 'convert image picture', kinds: ['png'], acceptText: 'PNG images', accept: ACC.png, options: () => range('q', 'JPG quality', 40, 100, 92) + bgOpt(), hint: 'PNG images, max 100MB each' } });
  /* ---------------- 19. JPG to PNG ---------------- */
  T.jpg2png = converter({ type: 'image/png', label: 'Convert', quality: false, def: { slug: 'jpg-to-png', name: 'JPG to PNG', icon: '\u25a7', desc: 'Convert JPG images to PNG.', kw: 'convert image picture jpeg', kinds: ['jpg'], acceptText: 'JPG images', accept: ACC.jpg, hint: 'JPG images, max 100MB each' } });
  /* ---------------- 23. Image to WebP ---------------- */
  T.img2webp = converter({ type: 'image/webp', label: 'Convert', def: { slug: 'image-to-webp', name: 'Image to WebP', icon: '\u25c9', desc: 'Convert JPG, PNG and other images to modern, smaller WebP.', kw: 'convert webp jpg png smaller', options: () => range('q', 'WebP quality', 30, 100, 85), hint: 'JPG, PNG, GIF, BMP, AVIF images, max 100MB each' } });
  T.img2webp.kinds = ['png', 'jpg', 'gif', 'bmp', 'avif', 'webp'];
  /* ---------------- 24. WebP to JPG ---------------- */
  T.webp2jpg = converter({ type: 'image/jpeg', label: 'Convert', def: { slug: 'webp-to-jpg', name: 'WebP to JPG', icon: '\u25c9', desc: 'Convert WebP images to JPG.', kw: 'convert webp image', kinds: ['webp'], acceptText: 'WebP images', accept: ACC.webp, options: () => range('q', 'JPG quality', 40, 100, 92) + bgOpt(), hint: 'WebP images, max 100MB each' } });

  /* ---------------- 20. Image Compressor ---------------- */
  T.imgcompress = imgTool({
    slug: 'image-compressor', name: 'Image Compressor', icon: '\u21e9', desc: 'Make images smaller by adjusting quality and size.', kw: 'compress reduce shrink optimize jpg png webp',
    kinds: ['png', 'jpg', 'webp'], acceptText: 'JPG, PNG or WebP images', accept: ACC.png + ',' + ACC.jpg + ',' + ACC.webp, zipName: 'PDFora-compressed', btn: (n) => 'Compress ' + n + (n === 1 ? ' Image' : ' Images'),
    options: () => range('q', 'Quality', 10, 100, 70, 'Lower quality = smaller file. 60-80% is usually a good balance.') +
      row('Output format', '<select id="fmt"><option value="keep">Keep the original format</option><option value="jpg">JPG (smallest for photos)</option><option value="webp">WebP (small, modern)</option></select>') +
      row('Maximum size', '<select id="maxd"><option value="0">Keep original dimensions</option><option value="4096">4096 px</option><option value="2560">2560 px</option><option value="1920">1920 px (Full HD)</option><option value="1280">1280 px</option></select>', 'Longest side of the image.'),
    async run(files, ctx) {
      const q = ctx.num('q', 70) / 100, fmt = ctx.val('fmt'), maxd = +ctx.val('maxd');
      return perFile(files, ctx, async (f, i) => {
        const kind = ctx.entries[i].kind; const type = fmt === 'keep' ? MIME[kind] : MIME[fmt];
        const im = await P.loadImage(f); let w = im.w, h = im.h; const sc = maxd && Math.max(w, h) > maxd ? maxd / Math.max(w, h) : 1; w = Math.round(w * sc); h = Math.round(h * sc);
        const c = P.drawToCanvas(im, w, h, { fill: type === 'image/jpeg' ? '#fff' : undefined }); im.close();
        const blob = await encode(c, type, q, f);
        if (blob.size >= f.size && fmt === 'keep' && sc === 1) { ctx.warn('"' + f.name + '" is already well compressed; the original is provided unchanged.'); return { name: P.baseName(f.name) + '-compressed.' + EXT[type], blob: f.slice(0, f.size, f.type), info: P.fmtSize(f.size) + ' (already optimized)' }; }
        if (kind === 'png' && fmt === 'keep') ctx.warn('PNG is a lossless format, so quality does not apply to PNG files. Choose JPG or WebP output for much smaller files.');
        return { name: P.baseName(f.name) + '-compressed.' + EXT[type], blob, info: P.fmtSize(f.size) + ' \u2192 ' + P.fmtSize(blob.size) + ' (' + pct(f.size, blob.size) + ')' };
      });
    }
  });

  /* ---------------- 21. Image Resizer ---------------- */
  T.imgresize = imgTool({
    slug: 'image-resizer', name: 'Image Resizer', icon: '\u2194', desc: 'Resize images to exact dimensions or by percentage.', kw: 'resize scale dimensions width height pixels',
    zipName: 'PDFora-resized', btn: (n) => 'Resize ' + n + (n === 1 ? ' Image' : ' Images'),
    options: () => row('Resize by', '<select id="mode"><option value="px">Dimensions (pixels)</option><option value="pct">Percentage</option></select>') +
      '<div id="pxBox"><div class="opt-grid">' + row('Width (px)', '<input id="rw" type="number" min="1" max="16000" placeholder="e.g. 800">') + row('Height (px)', '<input id="rh" type="number" min="1" max="16000" placeholder="e.g. 600">') + '</div><label class="chk"><input type="checkbox" id="lock" checked> Keep aspect ratio (image is fitted inside the size)</label></div>' +
      '<div id="pctBox" style="display:none">' + row('Scale (%)', '<input id="rp" type="number" min="1" max="500" value="50">') + '</div>',
    mount(app) { const m = app.q('#mode'); m.addEventListener('change', () => { app.q('#pxBox').style.display = m.value === 'px' ? '' : 'none'; app.q('#pctBox').style.display = m.value === 'pct' ? '' : 'none'; }); },
    validate(app) { if (app.val('mode') === 'px' && !app.num('rw', 0) && !app.num('rh', 0)) throw new Error('Enter a width and/or a height in pixels.'); if (app.val('mode') === 'pct' && !(app.num('rp', 0) > 0)) throw new Error('Enter a scale percentage.'); },
    async run(files, ctx) {
      const mode = ctx.val('mode'), W = ctx.num('rw', 0), H = ctx.num('rh', 0), lock = ctx.checked('lock'), p = ctx.num('rp', 50);
      return perFile(files, ctx, async (f, i) => {
        const kind = ctx.entries[i].kind; const type = MIME[kind] || 'image/png';
        const im = await P.loadImage(f); let nw, nh;
        if (mode === 'pct') { nw = Math.round(im.w * p / 100); nh = Math.round(im.h * p / 100); }
        else if (lock) { const s = W && H ? Math.min(W / im.w, H / im.h) : W ? W / im.w : H / im.h; nw = Math.round(im.w * s); nh = Math.round(im.h * s); }
        else { nw = W || im.w; nh = H || im.h; }
        nw = Math.max(1, nw); nh = Math.max(1, nh); if (nw > 16000 || nh > 16000) throw new Error('The requested size (' + nw + ' \u00d7 ' + nh + ') is too large.');
        const c = P.drawToCanvas(im, nw, nh, { fill: type === 'image/jpeg' ? '#fff' : undefined }); const ow = im.w, oh = im.h; im.close();
        const blob = await encode(c, type, 0.92, f);
        return { name: P.baseName(f.name) + '-' + nw + 'x' + nh + '.' + EXT[type], blob, info: ow + ' \u00d7 ' + oh + ' \u2192 ' + nw + ' \u00d7 ' + nh + ' px' };
      });
    }
  });

  /* ---------------- 8/25. JPG to PDF, Image to PDF ---------------- */
  function jpegOrientation(b) {
    if (b[0] !== 0xff || b[1] !== 0xd8) return 1; let p = 2;
    while (p + 4 < b.length && b[p] === 0xff) {
      const m = b[p + 1], len = (b[p + 2] << 8) | b[p + 3];
      if (m === 0xe1 && b[p + 4] === 0x45 && b[p + 5] === 0x78 && b[p + 6] === 0x69 && b[p + 7] === 0x66) {
        const t = p + 10, le = b[t] === 0x49; const r16 = (o) => le ? b[t + o] | (b[t + o + 1] << 8) : (b[t + o] << 8) | b[t + o + 1];
        const r32 = (o) => le ? (b[t + o] | (b[t + o + 1] << 8) | (b[t + o + 2] << 16) | (b[t + o + 3] << 24)) >>> 0 : ((b[t + o] << 24) | (b[t + o + 1] << 16) | (b[t + o + 2] << 8) | b[t + o + 3]) >>> 0;
        const ifd = r32(4), n = r16(ifd); for (let i = 0; i < n; i++) { const e = ifd + 2 + i * 12; if (r16(e) === 0x0112) return r16(e + 8); } return 1;
      }
      if (m === 0xda) break; p += 2 + len;
    }
    return 1;
  }
  async function imagesToPdf(files, ctx, entries) {
    const L = P.need(); const doc = await L.PDFDocument.create();
    const size = ctx.val('psize') || 'fit', orient = ctx.val('orient') || 'auto', marginSel = ctx.val('margin') || 'none';
    const margin = { none: 0, small: 18, big: 36 }[marginSel] || 0;
    const sizes = { a4: [595.28, 841.89], letter: [612, 792] };
    for (let i = 0; i < files.length; i++) {
      const f = files[i]; ctx.progress(i / files.length, 'Image ' + (i + 1) + ' of ' + files.length);
      try {
        const kind = entries[i].kind; let emb; const bytes = await P.readBytes(f);
        if (kind === 'jpg' && jpegOrientation(bytes) === 1) { try { emb = await doc.embedJpg(bytes); } catch (e) { emb = null; } }
        else if (kind === 'png') { try { emb = await doc.embedPng(bytes); } catch (e) { emb = null; } }
        if (!emb) { // other formats (or rotated JPEGs): decode in the browser, then embed
          const im = await P.loadImage(f); const hasAlpha = kind !== 'jpg' && kind !== 'bmp';
          const c = P.drawToCanvas(im, im.w, im.h, { fill: hasAlpha ? undefined : '#fff' }); im.close();
          const blob = await P.canvasBlob(c, hasAlpha ? 'image/png' : 'image/jpeg', 0.92); const b2 = new Uint8Array(await blob.arrayBuffer());
          emb = hasAlpha ? await doc.embedPng(b2) : await doc.embedJpg(b2);
        }
        let iw = emb.width, ih = emb.height, pw, ph, dw, dh, dx, dy;
        if (size === 'fit') {
          let k = 0.75; const long = Math.max(iw, ih) * k; if (long > 1190) k *= 1190 / long;
          pw = iw * k + margin * 2; ph = ih * k + margin * 2; dw = iw * k; dh = ih * k; dx = margin; dy = margin;
        } else {
          let [a, b] = sizes[size]; const land = orient === 'landscape' || (orient === 'auto' && iw > ih);
          if (land) [a, b] = [b, a]; pw = a; ph = b;
          const aw = pw - margin * 2, ah = ph - margin * 2; const s = Math.min(aw / iw, ah / ih); dw = iw * s; dh = ih * s; dx = (pw - dw) / 2; dy = (ph - dh) / 2;
        }
        doc.addPage([pw, ph]).drawImage(emb, { x: dx, y: dy, width: dw, height: dh });
      } catch (e) { ctx.fail(f.name, e.message || 'could not be added'); }
      await P.tick();
    }
    if (!doc.getPageCount()) return [];
    const name = files.length === 1 ? P.baseName(files[0].name) + '.pdf' : 'PDFora-images.pdf';
    const res = await P.savePdf(doc, name); res.info = plural(doc.getPageCount(), 'page'); return [res];
  }
  const pdfOpts = () => row('Page size', '<select id="psize"><option value="fit">Same size as the image</option><option value="a4">A4</option><option value="letter">US Letter</option></select>') +
    '<div class="opt-grid">' + row('Orientation', '<select id="orient"><option value="auto">Automatic</option><option value="portrait">Portrait</option><option value="landscape">Landscape</option></select>', 'For A4 / Letter') + row('Margin', '<select id="margin"><option value="none">None</option><option value="small">Small</option><option value="big">Big</option></select>') + '</div>';
  T.jpg2pdf = imgTool({
    slug: 'jpg-to-pdf', name: 'JPG to PDF', icon: '\u25a7', desc: 'Convert one or more JPG images into a single PDF.', kw: 'jpeg photo image picture convert pdf',
    kinds: ['jpg', 'png'], acceptText: 'JPG or PNG images', accept: ACC.jpg + ',' + ACC.png, ordered: true, btn: (n) => 'Convert ' + n + (n === 1 ? ' Image' : ' Images') + ' to PDF', options: pdfOpts,
    hint: 'JPG/PNG images, max 100MB each. Use the arrows to set the page order.', run: (files, ctx) => imagesToPdf(files, ctx, ctx.entries)
  });
  T.img2pdf = imgTool({
    slug: 'image-to-pdf', name: 'Image to PDF', icon: '\u25a7', desc: 'Convert images of any common type (JPG, PNG, WebP, GIF, BMP) into a single PDF.', kw: 'photo picture convert pdf webp png jpg gif',
    ordered: true, btn: (n) => 'Convert ' + n + (n === 1 ? ' Image' : ' Images') + ' to PDF', options: pdfOpts,
    hint: 'Images, max 100MB each. Use the arrows to set the page order.', run: (files, ctx) => imagesToPdf(files, ctx, ctx.entries)
  });
})(window);
