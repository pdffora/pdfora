/* Runs first on pages that host tools. A "#tool-slug" in the address is remembered and removed so no tool opens
   before PDFora knows whether the visitor is logged in; gate.js then decides what to do with it. */
(function () { var h = location.hash; if (h && h.length > 1) { window.__pfHash = decodeURIComponent(h.slice(1)); history.replaceState(null, '', location.pathname + location.search); } })();
