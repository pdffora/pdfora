/* PDFora tool registry: order matches the original 25-tool list. */
(function (g) {
  'use strict';
  const P = g.PDFora, T = P.T;
  P.tools = ['merge', 'split', 'compress', 'pdf2word', 'word2pdf', 'pdf2excel', 'excel2pdf', 'pdf2jpg', 'jpg2pdf', 'rotate', 'protect', 'unlock', 'sign', 'pagenum', 'watermark', 'organize', 'repair', 'png2jpg', 'jpg2png', 'imgcompress', 'imgresize', 'imgcrop', 'img2webp', 'webp2jpg', 'img2pdf'].map((k) => {
    if (!T[k]) throw new Error('Missing tool: ' + k); return T[k];
  });
})(window);
