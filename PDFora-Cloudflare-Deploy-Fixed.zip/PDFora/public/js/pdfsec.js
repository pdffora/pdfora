/* PDFora PDF security + repair engine.
   - Reads PDF files (xref tables, xref streams, object streams, damaged files)
   - Decrypts PDFs: RC4 40/128-bit, AES-128, AES-256 (R2-R6)
   - Encrypts PDFs with AES-256 (R6)
   - Rebuilds damaged files
   Uses only WebCrypto + DecompressionStream, no external libraries. */
(function (g) {
  'use strict';
  const P = (g.PDFora = g.PDFora || {});
  const subtle = (g.crypto || {}).subtle;
  const enc = new TextEncoder();

  /* ======================= primitives ======================= */
  const concat = (...arrs) => {
    let n = 0; for (const a of arrs) n += a.length;
    const o = new Uint8Array(n); let p = 0; for (const a of arrs) { o.set(a, p); p += a.length; } return o;
  };
  const eq = (a, b, n) => { for (let i = 0; i < n; i++) if (a[i] !== b[i]) return false; return true; };

  function md5(msg) {
    const S = [7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21];
    const K = new Uint32Array(64); for (let i = 0; i < 64; i++) K[i] = Math.floor(Math.abs(Math.sin(i + 1)) * 4294967296) >>> 0;
    const len = msg.length, padLen = ((len + 8) >> 6 << 6) + 64;
    const m = new Uint8Array(padLen); m.set(msg); m[len] = 0x80;
    const dv = new DataView(m.buffer);
    dv.setUint32(padLen - 8, (len * 8) >>> 0, true); dv.setUint32(padLen - 4, Math.floor(len / 536870912), true);
    let a0 = 0x67452301, b0 = 0xefcdab89, c0 = 0x98badcfe, d0 = 0x10325476;
    const M = new Uint32Array(16);
    for (let o = 0; o < padLen; o += 64) {
      for (let i = 0; i < 16; i++) M[i] = dv.getUint32(o + i * 4, true);
      let A = a0, B = b0, C = c0, D = d0;
      for (let i = 0; i < 64; i++) {
        let F, k;
        if (i < 16) { F = (B & C) | (~B & D); k = i; } else if (i < 32) { F = (D & B) | (~D & C); k = (5 * i + 1) & 15; }
        else if (i < 48) { F = B ^ C ^ D; k = (3 * i + 5) & 15; } else { F = C ^ (B | ~D); k = (7 * i) & 15; }
        F = (F + A + K[i] + M[k]) >>> 0; A = D; D = C; C = B;
        B = (B + ((F << S[i]) | (F >>> (32 - S[i])))) >>> 0;
      }
      a0 = (a0 + A) >>> 0; b0 = (b0 + B) >>> 0; c0 = (c0 + C) >>> 0; d0 = (d0 + D) >>> 0;
    }
    const out = new Uint8Array(16), od = new DataView(out.buffer);
    od.setUint32(0, a0, true); od.setUint32(4, b0, true); od.setUint32(8, c0, true); od.setUint32(12, d0, true);
    return out;
  }
  function rc4(key, data) {
    const s = new Uint8Array(256); for (let i = 0; i < 256; i++) s[i] = i;
    for (let i = 0, j = 0; i < 256; i++) { j = (j + s[i] + key[i % key.length]) & 255; const t = s[i]; s[i] = s[j]; s[j] = t; }
    const out = new Uint8Array(data.length);
    for (let k = 0, i = 0, j = 0; k < data.length; k++) {
      i = (i + 1) & 255; j = (j + s[i]) & 255; const t = s[i]; s[i] = s[j]; s[j] = t; out[k] = data[k] ^ s[(s[i] + s[j]) & 255];
    }
    return out;
  }
  const sha = async (bits, data) => new Uint8Array(await subtle.digest('SHA-' + bits, data));
  const aesKey = (key) => subtle.importKey('raw', key, { name: 'AES-CBC' }, false, ['encrypt', 'decrypt']);
  async function aesEncNoPad(key, iv, data) { // data length multiple of 16
    const k = key instanceof Uint8Array ? await aesKey(key) : key;
    const out = new Uint8Array(await subtle.encrypt({ name: 'AES-CBC', iv }, k, data));
    return out.subarray(0, data.length);
  }
  async function aesDecNoPad(key, iv, data) {
    const k = key instanceof Uint8Array ? await aesKey(key) : key;
    if (!data.length) return new Uint8Array(0);
    const last = data.subarray(data.length - 16);
    const padBlock = new Uint8Array(await subtle.encrypt({ name: 'AES-CBC', iv: last }, k, new Uint8Array(0)));
    return new Uint8Array(await subtle.decrypt({ name: 'AES-CBC', iv }, k, concat(data, padBlock)));
  }
  async function aesDecPdf(k, data) { // IV prefixed + PKCS7
    if (data.length < 32) return new Uint8Array(0);
    const iv = data.subarray(0, 16);
    const body = data.subarray(16, 16 + ((data.length - 16) >> 4 << 4));
    const out = await aesDecNoPad(k, iv, body);
    const pad = out[out.length - 1];
    if (pad >= 1 && pad <= 16 && out.length >= pad) return out.subarray(0, out.length - pad);
    return out;
  }
  async function aesEncPdf(k, data) {
    const iv = crypto.getRandomValues(new Uint8Array(16));
    const out = new Uint8Array(await subtle.encrypt({ name: 'AES-CBC', iv }, k, data));
    return concat(iv, out);
  }

  /* PDF 2.0 hash (algorithm 2.B) used by revision 6 */
  async function hashR6(pw, salt, udata) {
    let K = await sha(256, concat(pw, salt, udata));
    let i = 0, E;
    while (i < 64 || E[E.length - 1] > i - 32) {
      const unit = concat(pw, K, udata);
      const K1 = new Uint8Array(unit.length * 64);
      for (let j = 0; j < 64; j++) K1.set(unit, j * unit.length);
      E = await aesEncNoPad(K.subarray(0, 16), K.subarray(16, 32), K1);
      let sum = 0; for (let j = 0; j < 16; j++) sum += E[j];
      K = await sha([256, 384, 512][sum % 3], E);
      i++;
    }
    return K.subarray(0, 32);
  }

  /* ======================= PDF object model ======================= */
  class Name { constructor(n) { this.n = n; } }
  class Str { constructor(s) { this.s = s; } }
  class Ref { constructor(n, g) { this.n = n; this.g = g; } }
  class Dict extends Map { }
  class Stream { constructor(dict, raw) { this.dict = dict; this.raw = raw; } }
  class Kw { constructor(k) { this.k = k; } }

  const isWs = (c) => c === 0 || c === 9 || c === 10 || c === 12 || c === 13 || c === 32;
  const isDelim = (c) => c === 40 || c === 41 || c === 60 || c === 62 || c === 91 || c === 93 || c === 123 || c === 125 || c === 47 || c === 37;
  const dec = new TextDecoder('latin1');

  function indexOfBytes(b, pat, from, to) {
    const n = pat.length; to = Math.min(to == null ? b.length : to, b.length) - n;
    outer: for (let i = from; i <= to; i++) { for (let j = 0; j < n; j++) if (b[i + j] !== pat[j]) continue outer; return i; }
    return -1;
  }
  function lastIndexOfBytes(b, pat, from) {
    for (let i = Math.min(from, b.length - pat.length); i >= 0; i--) { let ok = true; for (let j = 0; j < pat.length; j++) if (b[i + j] !== pat[j]) { ok = false; break; } if (ok) return i; }
    return -1;
  }
  const A = (s) => Uint8Array.from(s, (c) => c.charCodeAt(0));

  class Lexer {
    constructor(b, p) { this.b = b; this.p = p || 0; }
    ws() {
      const b = this.b;
      for (; ;) {
        const c = b[this.p];
        if (c === 37) { while (this.p < b.length && b[this.p] !== 10 && b[this.p] !== 13) this.p++; }
        else if (isWs(c)) this.p++; else break;
      }
    }
    token() { const b = this.b, s = this.p; while (this.p < b.length && !isWs(b[this.p]) && !isDelim(b[this.p])) this.p++; return dec.decode(b.subarray(s, this.p)); }
    parse(depth = 0) {
      if (depth > 200) throw new Error('nesting');
      this.ws(); const b = this.b, c = b[this.p];
      if (c === undefined) throw new Error('EOF');
      if (c === 47) {
        this.p++; const t = this.token();
        return new Name(t.replace(/#([0-9a-fA-F]{2})/g, (_, h) => String.fromCharCode(parseInt(h, 16))));
      }
      if (c === 40) return this.litString();
      if (c === 60) {
        if (b[this.p + 1] === 60) {
          this.p += 2; const d = new Dict();
          for (; ;) {
            this.ws();
            if (b[this.p] === 62 && b[this.p + 1] === 62) { this.p += 2; break; }
            if (this.p >= b.length) throw new Error('EOF in dict');
            const k = this.parse(depth + 1);
            if (!(k instanceof Name)) { if (k instanceof Kw && /^(endobj|stream)$/.test(k.k)) { this.p -= k.k.length; break; } throw new Error('bad dict key'); }
            this.ws();
            if (b[this.p] === 62 && b[this.p + 1] === 62) { d.set(k.n, null); this.p += 2; break; }
            d.set(k.n, this.parse(depth + 1));
          }
          return d;
        }
        this.p++; let hex = '';
        while (this.p < b.length && b[this.p] !== 62) { const ch = String.fromCharCode(b[this.p++]); if (/[0-9a-fA-F]/.test(ch)) hex += ch; }
        this.p++; if (hex.length % 2) hex += '0';
        const o = new Uint8Array(hex.length / 2); for (let i = 0; i < o.length; i++) o[i] = parseInt(hex.substr(i * 2, 2), 16);
        return new Str(o);
      }
      if (c === 91) {
        this.p++; const arr = [];
        for (; ;) { this.ws(); if (b[this.p] === 93) { this.p++; break; } if (this.p >= b.length) throw new Error('EOF in array'); arr.push(this.parse(depth + 1)); }
        return arr;
      }
      if (c === 93 || c === 62 || c === 41 || c === 123 || c === 125) { this.p++; return new Kw(String.fromCharCode(c)); }
      const t = this.token();
      if (!t) { this.p++; return new Kw('?'); }
      if (/^[+-]?(\d+\.?\d*|\.\d+)$/.test(t)) {
        const v = parseFloat(t);
        if (/^\d+$/.test(t)) {
          const save = this.p; this.ws();
          const t2 = this.token();
          if (/^\d+$/.test(t2)) { this.ws(); if (b[this.p] === 82 && (this.p + 1 >= b.length || isWs(b[this.p + 1]) || isDelim(b[this.p + 1]))) { this.p++; return new Ref(v, +t2); } }
          this.p = save;
        }
        return v;
      }
      if (t === 'true') return true; if (t === 'false') return false; if (t === 'null') return null;
      return new Kw(t);
    }
    litString() {
      const b = this.b; this.p++; let depth = 1; const out = [];
      while (this.p < b.length) {
        let c = b[this.p++];
        if (c === 92) {
          c = b[this.p++];
          if (c === 110) out.push(10); else if (c === 114) out.push(13); else if (c === 116) out.push(9); else if (c === 98) out.push(8); else if (c === 102) out.push(12);
          else if (c >= 48 && c <= 55) { let v = c - 48, k = 1; while (k < 3 && b[this.p] >= 48 && b[this.p] <= 55) { v = v * 8 + b[this.p++] - 48; k++; } out.push(v & 255); }
          else if (c === 13) { if (b[this.p] === 10) this.p++; } else if (c === 10) { /* continuation */ } else out.push(c);
        } else if (c === 40) { depth++; out.push(c); } else if (c === 41) { if (--depth === 0) break; out.push(c); } else out.push(c);
      }
      return new Str(Uint8Array.from(out));
    }
  }

  async function inflate(data) {
    const ds = new DecompressionStream('deflate');
    const w = ds.writable.getWriter();
    w.write(data).catch(() => { }); w.close().catch(() => { });
    const rd = ds.readable.getReader(); const chunks = []; let n = 0;
    try { for (; ;) { const { done, value } = await rd.read(); if (done) break; chunks.push(value); n += value.length; } } catch (e) { if (!n) throw e; }
    return concat(...chunks);
  }
  function unpredict(data, parms) {
    const pred = parms && parms.get('Predictor') || 1;
    if (pred < 10) return data;
    const colors = parms.get('Colors') || 1, bpc = parms.get('BitsPerComponent') || 8, cols = parms.get('Columns') || 1;
    const bpp = Math.max(1, (colors * bpc + 7) >> 3), rowLen = (cols * colors * bpc + 7) >> 3;
    const rows = Math.floor(data.length / (rowLen + 1)); const out = new Uint8Array(rows * rowLen);
    for (let r = 0; r < rows; r++) {
      const f = data[r * (rowLen + 1)], src = r * (rowLen + 1) + 1, dst = r * rowLen, prev = dst - rowLen;
      for (let i = 0; i < rowLen; i++) {
        const x = data[src + i], a = i >= bpp ? out[dst + i - bpp] : 0, b = r ? out[prev + i] : 0, c = (r && i >= bpp) ? out[prev + i - bpp] : 0;
        let v;
        switch (f) {
          case 1: v = x + a; break; case 2: v = x + b; break; case 3: v = x + ((a + b) >> 1); break;
          case 4: { const p = a + b - c, pa = Math.abs(p - a), pb = Math.abs(p - b), pc = Math.abs(p - c); v = x + (pa <= pb && pa <= pc ? a : pb <= pc ? b : c); break; }
          default: v = x;
        }
        out[dst + i] = v & 255;
      }
    }
    return out;
  }
  const nameOf = (v) => (v instanceof Name ? v.n : null);
  async function decodeStream(st) { // supports Flate (+predictors); used for xref streams and object streams
    let f = st.dict.get('Filter'), parms = st.dict.get('DecodeParms');
    const fl = Array.isArray(f) ? f : f ? [f] : [];
    const pl = Array.isArray(parms) ? parms : parms ? [parms] : [];
    let data = st.data || st.raw;
    for (let i = 0; i < fl.length; i++) {
      const nm = nameOf(fl[i]);
      if (nm === 'FlateDecode' || nm === 'Fl') { data = unpredict(await inflate(data), pl[i] instanceof Dict ? pl[i] : null); }
      else if (nm === 'Crypt') continue;
      else throw new Error('Unsupported filter ' + nm);
    }
    return data;
  }

  /* ======================= Reader ======================= */
  const PAD = Uint8Array.from([0x28, 0xbf, 0x4e, 0x5e, 0x4e, 0x75, 0x8a, 0x41, 0x64, 0x00, 0x4e, 0x56, 0xff, 0xfa, 0x01, 0x08, 0x2e, 0x2e, 0x00, 0xb6, 0xd0, 0x68, 0x3e, 0x80, 0x2f, 0x0c, 0xa9, 0xfe, 0x64, 0x53, 0x69, 0x7a]);

  class Reader {
    constructor(bytes) { this.b = bytes; this.xref = new Map(); this.trailer = new Dict(); this.cache = new Map(); this.objstm = new Map(); this.crypt = null; this.encRef = -1; this.reconstructed = false; }

    async open(password, opts = {}) {
      let ok = false;
      if (!opts.forceRebuild) { try { await this.loadXref(); ok = this.trailer.has('Root') && (await this.testRoot()); } catch (e) { ok = false; } }
      if (!ok) { this.xref.clear(); this.cache.clear(); this.objstm.clear(); this.trailer = new Dict(); await this.reconstruct(); }
      await this.setupEncryption(password);
      if (this.reconstructed) await this.registerObjStreams();
      if (!this.trailer.has('Root') || !(await this.testRoot())) {
        this.trailer.delete('Root'); await this.findRoot();
        if (!this.trailer.has('Root')) throw new Error('No document catalog found');
      }
    }
    async testRoot() { try { const r = await this.get(this.trailer.get('Root').n); return r instanceof Dict && r.has('Pages'); } catch (e) { return false; } }

    async loadXref() {
      const b = this.b; const sx = lastIndexOfBytes(b, A('startxref'), b.length);
      if (sx < 0) throw new Error('no startxref');
      const lx = new Lexer(b, sx + 9); let off = lx.parse();
      if (typeof off !== 'number') throw new Error('bad startxref');
      const seen = new Set(); let first = true; const queue = [off];
      while (queue.length) {
        off = queue.shift(); if (seen.has(off) || off < 0 || off >= b.length) continue; seen.add(off);
        const l = new Lexer(b, off); l.ws();
        let trailer;
        if (b[l.p] === 120) { // 'xref'
          l.p += 4;
          for (; ;) {
            l.ws();
            if (b[l.p] === 116) break; // trailer
            const start = l.parse(), count = l.parse();
            if (typeof start !== 'number' || typeof count !== 'number') throw new Error('bad xref');
            for (let i = 0; i < count; i++) {
              const o = l.parse(), gen = l.parse(), t = l.parse();
              if (typeof o !== 'number' || !(t instanceof Kw)) throw new Error('bad xref entry');
              const n = start + i; if (this.xref.has(n)) continue;
              this.xref.set(n, t.k === 'n' ? { t: 1, off: o, gen } : { t: 0 });
            }
          }
          l.token(); trailer = l.parse();
          if (!(trailer instanceof Dict)) throw new Error('bad trailer');
          const xs = trailer.get('XRefStm'); if (typeof xs === 'number') queue.unshift(xs);
        } else {
          const ind = await this.parseIndirectAt(off, true);
          if (!ind || !(ind.value instanceof Stream)) throw new Error('bad xref stream');
          const st = ind.value; trailer = st.dict;
          const data = await decodeStream(st), W = trailer.get('W'), size = trailer.get('Size');
          const index = trailer.get('Index') || [0, size];
          const rl = W[0] + W[1] + W[2]; let p = 0;
          for (let s = 0; s < index.length; s += 2) {
            for (let i = 0; i < index[s + 1]; i++, p += rl) {
              if (p + rl > data.length) break;
              const rd = (o, w) => { let v = 0; for (let k = 0; k < w; k++) v = v * 256 + data[p + o + k]; return v; };
              const t = W[0] ? rd(0, W[0]) : 1, f2 = rd(W[0], W[1]), f3 = rd(W[0] + W[1], W[2]);
              const n = index[s] + i; if (this.xref.has(n)) continue;
              this.xref.set(n, t === 1 ? { t: 1, off: f2, gen: f3 } : t === 2 ? { t: 2, stm: f2, idx: f3 } : { t: 0 });
            }
          }
        }
        if (first) { for (const k of ['Root', 'Encrypt', 'ID', 'Info']) if (trailer.has(k)) this.trailer.set(k, trailer.get(k)); first = false; }
        else for (const k of ['Root', 'Encrypt', 'ID', 'Info']) if (!this.trailer.has(k) && trailer.has(k)) this.trailer.set(k, trailer.get(k));
        const prev = trailer.get('Prev'); if (typeof prev === 'number') queue.push(prev);
      }
    }

    /* scan the whole file for "n g obj" markers (used for damaged files) */
    async reconstruct() {
      this.reconstructed = true; const b = this.b; const txt = dec.decode(b);
      let m;
      // recompute offsets precisely
      const re2 = /(\d{1,10})\s+(\d{1,5})\s+obj\b/g; this.xref.clear();
      while ((m = re2.exec(txt))) this.xref.set(+m[1], { t: 1, off: m.index, gen: +m[2] });
      // trailers
      const tre = /trailer/g; const trailers = [];
      while ((m = tre.exec(txt))) { try { const d = new Lexer(b, m.index + 7).parse(); if (d instanceof Dict) trailers.push(d); } catch (e) { /* skip */ } }
      for (let i = trailers.length - 1; i >= 0; i--) for (const k of ['Root', 'Encrypt', 'ID', 'Info']) if (!this.trailer.has(k) && trailers[i].has(k)) this.trailer.set(k, trailers[i].get(k));
      if (!this.trailer.has('Root') || !this.trailer.has('Encrypt')) { // xref-stream documents keep the trailer keys in the XRef stream dictionary
        for (const [n, e] of [...this.xref].reverse()) {
          try {
            const ind = await this.parseIndirectAt(e.off, true);
            if (ind && ind.value instanceof Stream && nameOf(ind.value.dict.get('Type')) === 'XRef') for (const k of ['Root', 'Encrypt', 'ID', 'Info']) if (!this.trailer.has(k) && ind.value.dict.has(k)) this.trailer.set(k, ind.value.dict.get(k));
          } catch (e2) { /* skip */ }
        }
      }
    }
    async registerObjStreams() {
      for (const [n, e] of [...this.xref]) {
        if (e.t !== 1) continue;
        let o; try { o = await this.get(n); } catch (er) { continue; }
        if (o instanceof Stream && nameOf(o.dict.get('Type')) === 'ObjStm') {
          try {
            const info = await this.loadObjStm(n);
            info.nums.forEach((num, idx) => { const cur = this.xref.get(num); if (!cur || cur.t !== 1) this.xref.set(num, { t: 2, stm: n, idx }); });
          } catch (er) { /* skip */ }
        }
      }
    }
    async findRoot() {
      for (const [n, e] of [...this.xref].reverse()) {
        try { const o = await this.get(n); if (o instanceof Dict && nameOf(o.get('Type')) === 'Catalog' && o.has('Pages')) { this.trailer.set('Root', new Ref(n, e.gen || 0)); return; } } catch (er) { /* skip */ }
      }
    }

    async parseIndirectAt(off, rawOnly) {
      const b = this.b; const lx = new Lexer(b, off);
      const num = lx.parse(), gen = lx.parse(), kw = lx.parse();
      if (typeof num !== 'number' || !(kw instanceof Kw) || kw.k !== 'obj') throw new Error('bad object header at ' + off);
      let val = lx.parse();
      if (val instanceof Kw) { val = (val.k === 'endobj') ? null : null; return { num, gen, value: val }; }
      if (val instanceof Dict) {
        const save = lx.p; lx.ws();
        if (b[lx.p] === 115 && dec.decode(b.subarray(lx.p, lx.p + 6)) === 'stream') {
          let p = lx.p + 6; if (b[p] === 13 && b[p + 1] === 10) p += 2; else if (b[p] === 10 || b[p] === 13) p++;
          let len = val.get('Length');
          if (len instanceof Ref && !rawOnly) { try { len = await this.get(len.n); } catch (e) { len = null; } } else if (len instanceof Ref) len = null;
          let end = -1;
          if (typeof len === 'number' && len >= 0 && p + len <= b.length) {
            const l2 = new Lexer(b, p + len); l2.ws();
            if (dec.decode(b.subarray(l2.p, l2.p + 9)) === 'endstream') end = p + len;
          }
          if (end < 0) {
            const e2 = indexOfBytes(b, A('endstream'), p); end = e2 < 0 ? b.length : e2;
            if (b[end - 1] === 10) end--; if (b[end - 1] === 13) end--;
          }
          return { num, gen, value: new Stream(val, b.subarray(p, end)) };
        }
        lx.p = save;
      }
      return { num, gen, value: val };
    }

    async loadObjStm(n) {
      if (this.objstm.has(n)) return this.objstm.get(n);
      const st = await this.get(n);
      if (!(st instanceof Stream)) throw new Error('not an object stream');
      const data = await decodeStream(st);
      const N = st.dict.get('N'), First = st.dict.get('First'); const lx = new Lexer(data, 0);
      const nums = [], offs = [];
      for (let i = 0; i < N; i++) { nums.push(lx.parse()); offs.push(lx.parse()); }
      const info = { data, nums, offs, First }; this.objstm.set(n, info); return info;
    }

    async get(n) {
      if (this.cache.has(n)) return this.cache.get(n);
      const e = this.xref.get(n); let val = null;
      if (e && e.t === 1) {
        const ind = await this.parseIndirectAt(e.off);
        if (ind.num !== n) throw new Error('xref mismatch for ' + n);
        val = ind.value;
        if (this.crypt && n !== this.encRef) val = await this.decryptObj(val, ind.num, ind.gen);
      } else if (e && e.t === 2) {
        const info = await this.loadObjStm(e.stm);
        const idx = info.nums[e.idx] === n ? e.idx : info.nums.indexOf(n);
        if (idx < 0) throw new Error('object not in stream');
        val = new Lexer(info.data, info.First + info.offs[idx]).parse();
      }
      this.cache.set(n, val); return val;
    }
    async resolve(v) { let d = 0; while (v instanceof Ref && d++ < 20) v = await this.get(v.n); return v; }

    /* ---------- encryption ---------- */
    async setupEncryption(password) {
      let encObj = this.trailer.get('Encrypt'); if (!encObj) return;
      if (encObj instanceof Ref) { this.encRef = encObj.n; encObj = await this.get(encObj.n); }
      if (!(encObj instanceof Dict)) return;
      if (nameOf(encObj.get('Filter')) !== 'Standard') throw new Error('This PDF uses a security handler that is not supported (' + nameOf(encObj.get('Filter')) + ').');
      const gi = (k, d) => { const v = encObj.get(k); return typeof v === 'number' ? v : d; };
      const V = gi('V', 0), R = gi('R', 2); const Pm = gi('P', 0) | 0;
      const O = (encObj.get('O') || {}).s, U = (encObj.get('U') || {}).s;
      if (!O || !U) throw new Error('Damaged encryption information.');
      const encMeta = encObj.get('EncryptMetadata') !== false;
      const idArr = this.trailer.get('ID'); const id0 = (Array.isArray(idArr) && idArr[0] instanceof Str) ? idArr[0].s : new Uint8Array(0);
      let n, stmM = 'RC4', strM = 'RC4';
      if (V === 1) n = 5; else if (V === 2 || V === 3) n = gi('Length', 40) / 8;
      else if (V === 4 || V === 5) {
        n = V === 4 ? 16 : 32;
        const cf = encObj.get('CF'); const method = (nm) => {
          if (!nm || nm === 'Identity') return 'None';
          const d = cf instanceof Dict ? cf.get(nm) : null; const m = d instanceof Dict ? nameOf(d.get('CFM')) : null;
          return m === 'AESV2' ? 'AES' : m === 'AESV3' ? 'AES3' : m === 'V2' ? 'RC4' : 'None';
        };
        stmM = method(nameOf(encObj.get('StmF'))); strM = method(nameOf(encObj.get('StrF')));
      } else throw new Error('Unsupported PDF encryption version (V=' + V + ').');
      const pwBytes = (s) => { s = String(s || ''); if (R >= 5) return enc.encode(s).subarray(0, 127); return /^[\u0000-\u00ff]*$/.test(s) ? Uint8Array.from(s, (c) => c.charCodeAt(0)) : enc.encode(s); };
      const pad = (pw) => { const o = new Uint8Array(32); o.set(pw.subarray(0, 32)); if (pw.length < 32) o.set(PAD.subarray(0, 32 - pw.length), pw.length); return o; };
      const pBytes = Uint8Array.of(Pm & 255, (Pm >> 8) & 255, (Pm >> 16) & 255, (Pm >>> 24) & 255);
      let fileKey = null;
      const pwb = pwBytes(password);

      if (R <= 4) {
        const fromUserPad = (padded) => {
          let h = md5(concat(padded, O.subarray(0, 32), pBytes, id0, (R >= 4 && !encMeta) ? Uint8Array.of(255, 255, 255, 255) : new Uint8Array(0)));
          if (R >= 3) for (let i = 0; i < 50; i++) h = md5(h.subarray(0, n));
          return h.subarray(0, n);
        };
        const checkUser = (key) => {
          if (R === 2) return eq(rc4(key, PAD), U, 32);
          let x = rc4(key, md5(concat(PAD, id0)));
          for (let i = 1; i <= 19; i++) x = rc4(key.map((v) => v ^ i), x);
          return eq(x, U, 16);
        };
        let key = fromUserPad(pad(pwb));
        if (checkUser(key)) fileKey = key;
        else { // maybe the owner password
          let h = md5(pad(pwb)); if (R >= 3) for (let i = 0; i < 50; i++) h = md5(h);
          const ok = h.subarray(0, n); let userPad;
          if (R === 2) userPad = rc4(ok, O.subarray(0, 32));
          else { userPad = O.subarray(0, 32); for (let i = 19; i >= 0; i--) userPad = rc4(ok.map((v) => v ^ i), userPad); }
          key = fromUserPad(userPad); if (checkUser(key)) fileKey = key;
        }
      } else {
        const hash = R === 5 ? (pw, salt, ud) => sha(256, concat(pw, salt, ud)) : hashR6;
        const UE = (encObj.get('UE') || {}).s, OE = (encObj.get('OE') || {}).s;
        if (!UE || !OE) throw new Error('Damaged encryption information.');
        const zero = new Uint8Array(16);
        if (eq(await hash(pwb, U.subarray(32, 40), new Uint8Array(0)), U, 32)) {
          fileKey = await aesDecNoPad(await hash(pwb, U.subarray(40, 48), new Uint8Array(0)), zero, UE.subarray(0, 32));
        } else if (eq(await hash(pwb, O.subarray(32, 40), U.subarray(0, 48)), O, 32)) {
          fileKey = await aesDecNoPad(await hash(pwb, O.subarray(40, 48), U.subarray(0, 48)), zero, OE.subarray(0, 32));
        }
      }
      if (!fileKey) { const e = new Error(password ? 'The password is incorrect.' : 'This PDF needs a password to open.'); e.code = password ? 'WRONG_PASSWORD' : 'PASSWORD_REQUIRED'; throw e; }
      this.crypt = { V, R, n, fileKey, stmM, strM, encMeta, aesKey: null };
      if (R >= 5) this.crypt.aesKey = await aesKey(fileKey);
    }
    async dataKey(num, gen, aes) {
      const c = this.crypt;
      if (c.R >= 5) return c.aesKey;
      const k = md5(concat(c.fileKey, Uint8Array.of(num & 255, (num >> 8) & 255, (num >> 16) & 255, gen & 255, (gen >> 8) & 255), aes ? A('sAlT') : new Uint8Array(0))).subarray(0, Math.min(c.n + 5, 16));
      return aes ? aesKey(k) : k;
    }
    async decBytes(method, data, num, gen) {
      if (method === 'None') return data;
      if (method === 'RC4') return rc4(await this.dataKey(num, gen, false), data);
      return aesDecPdf(await this.dataKey(num, gen, true), data);
    }
    async decryptObj(v, num, gen) {
      if (v instanceof Str) return new Str(await this.decBytes(this.crypt.strM, v.s, num, gen));
      if (Array.isArray(v)) { const o = []; for (const x of v) o.push(await this.decryptObj(x, num, gen)); return o; }
      if (v instanceof Dict) { const d = new Dict(); for (const [k, x] of v) d.set(k, await this.decryptObj(x, num, gen)); return d; }
      if (v instanceof Stream) {
        const d = await this.decryptObj(v.dict, num, gen); const type = nameOf(d.get('Type'));
        let raw = v.raw;
        let skip = type === 'XRef' || (type === 'Metadata' && !this.crypt.encMeta);
        const f = d.get('Filter'); const fl = Array.isArray(f) ? f : f ? [f] : [];
        if (fl.length && nameOf(fl[0]) === 'Crypt') {
          const dp = d.get('DecodeParms'); const p0 = Array.isArray(dp) ? dp[0] : dp;
          const nm = p0 instanceof Dict ? nameOf(p0.get('Name')) : 'Identity'; if (!nm || nm === 'Identity') skip = true;
        }
        if (!skip) raw = await this.decBytes(this.crypt.stmM, raw, num, gen);
        const s = new Stream(d, raw); s.data = raw; return s;
      }
      return v;
    }

    /* ---------- write out a clean, unencrypted PDF ---------- */
    async write(progress) {
      const chunks = []; let pos = 0;
      const push = (u8) => { chunks.push(u8); pos += u8.length; };
      const head = concat(A('%PDF-1.7\n%'), Uint8Array.of(0xe2, 0xe3, 0xcf, 0xd3), A('\n')); push(head);
      const offs = new Map(); let maxN = 0; const nums = [...this.xref.keys()].filter((k) => k > 0 && this.xref.get(k).t !== 0).sort((a, b) => a - b);
      let done = 0;
      for (const n of nums) {
        let obj; try { obj = await this.get(n); } catch (e) { continue; }
        if (obj instanceof Stream) { const t = nameOf(obj.dict.get('Type')); if (t === 'XRef' || t === 'ObjStm') continue; }
        if (n === this.encRef) continue;
        const e = this.xref.get(n);
        offs.set(n, { off: pos, gen: e.t === 1 ? e.gen || 0 : 0 }); maxN = Math.max(maxN, n);
        push(A(n + ' ' + (e.t === 1 ? e.gen || 0 : 0) + ' obj\n'));
        const out = []; this.ser(obj, out, true); for (const c of out) push(c);
        push(A('\nendobj\n'));
        if (progress && (++done % 200 === 0)) { progress(done / nums.length); await P.tick(); }
      }
      const xrefPos = pos; let x = 'xref\n0 ' + (maxN + 1) + '\n0000000000 65535 f \n';
      for (let n = 1; n <= maxN; n++) { const o = offs.get(n); x += o ? String(o.off).padStart(10, '0') + ' ' + String(o.gen).padStart(5, '0') + ' n \n' : '0000000000 00000 f \n'; }
      push(A(x));
      const tr = new Dict(); tr.set('Size', maxN + 1); tr.set('Root', this.trailer.get('Root'));
      if (this.trailer.has('Info') && offs.has(this.trailer.get('Info').n)) tr.set('Info', this.trailer.get('Info'));
      const id = this.trailer.get('ID'); if (Array.isArray(id)) tr.set('ID', id);
      const t = []; this.ser(tr, t, false);
      push(A('trailer\n')); for (const c of t) push(c); push(A('\nstartxref\n' + xrefPos + '\n%%EOF\n'));
      return concat(...chunks);
    }
    ser(v, out, top) {
      if (v === null || v === undefined) out.push(A('null'));
      else if (v === true) out.push(A('true')); else if (v === false) out.push(A('false'));
      else if (typeof v === 'number') out.push(A(Number.isInteger(v) ? String(v) : String(+v.toFixed(6))));
      else if (v instanceof Name) out.push(A('/' + v.n.replace(/[^\x21-\x7e]|[#()<>[\]{}/%]/g, (c) => '#' + c.charCodeAt(0).toString(16).padStart(2, '0'))));
      else if (v instanceof Str) out.push(A('<' + Array.from(v.s, (x) => x.toString(16).padStart(2, '0')).join('') + '>'));
      else if (v instanceof Ref) out.push(A(v.n + ' ' + (this.xref.get(v.n) && this.xref.get(v.n).t === 1 ? this.xref.get(v.n).gen || 0 : 0) + ' R'));
      else if (Array.isArray(v)) { out.push(A('[')); v.forEach((x, i) => { if (i) out.push(A(' ')); this.ser(x, out); }); out.push(A(']')); }
      else if (v instanceof Dict) { out.push(A('<<')); for (const [k, x] of v) { this.ser(new Name(k), out); out.push(A(' ')); this.ser(x, out); out.push(A(' ')); } out.push(A('>>')); }
      else if (v instanceof Stream) {
        const d = new Dict(v.dict); d.set('Length', v.raw.length);
        const f = d.get('Filter'); const fl = Array.isArray(f) ? f : f ? [f] : [];
        if (fl.length && nameOf(fl[0]) === 'Crypt') {
          const rest = fl.slice(1); if (rest.length) d.set('Filter', rest.length === 1 ? rest[0] : rest); else d.delete('Filter');
          const dp = d.get('DecodeParms'); if (Array.isArray(dp)) { const r2 = dp.slice(1); if (r2.length) d.set('DecodeParms', r2); else d.delete('DecodeParms'); } else d.delete('DecodeParms');
        }
        this.ser(d, out); out.push(A('\nstream\n')); out.push(v.raw); out.push(A('\nendstream'));
      } else out.push(A('null'));
    }
  }

  /* ======================= public API ======================= */
  const Sec = P.Sec = {};
  Sec.inflate = inflate; Sec.unpredict = unpredict;

  Sec.isEncrypted = function (bytes) {
    // cheap check: an /Encrypt key in a trailer or xref stream dictionary
    const tail = bytes.subarray(Math.max(0, bytes.length - 4096));
    if (indexOfBytes(tail, A('/Encrypt'), 0) >= 0) return true;
    const t = dec.decode(bytes.subarray(0, Math.min(bytes.length, 2000000)));
    return /\/Encrypt\s+\d+\s+\d+\s+R/.test(t) || /\/Filter\s*\/Standard/.test(t) && /\/O\s*[(<]/.test(t);
  };

  /* Removes encryption. Throws .code PASSWORD_REQUIRED / WRONG_PASSWORD when a password is needed. */
  Sec.unlock = async function (bytes, password, progress) {
    if (!subtle) throw new Error('Your browser does not support secure cryptography here. Use https:// or http://localhost, or a current browser.');
    const rd = new Reader(bytes); await rd.open(password);
    const wasEncrypted = !!rd.crypt;
    const out = await rd.write(progress);
    return { bytes: out, wasEncrypted };
  };

  /* Rebuilds a damaged PDF; returns clean bytes. */
  Sec.rebuild = async function (bytes, progress) {
    const rd = new Reader(bytes); await rd.open('', { forceRebuild: true });
    return rd.write(progress);
  };

  /* AES-256 (revision 6) encryption of a PDF using pdf-lib. */
  Sec.protect = async function (bytes, o) {
    if (!subtle) throw new Error('Your browser does not support secure cryptography here. Use https:// or http://localhost, or a current browser.');
    const L = P.need(); const rnd = (n) => crypto.getRandomValues(new Uint8Array(n));
    let doc = await L.PDFDocument.load(bytes, { updateMetadata: false });
    const plain = await doc.save({ useObjectStreams: false });
    doc = await L.PDFDocument.load(plain, { updateMetadata: false });
    try { doc.setProducer('PDFora'); } catch (e) { /* ignore */ }
    const ctx = doc.context;
    const fileKey = rnd(32);
    const userPw = enc.encode(o.userPassword).subarray(0, 127), ownerPw = enc.encode(o.ownerPassword || o.userPassword).subarray(0, 127);
    const zero = new Uint8Array(16), none = new Uint8Array(0);
    const uVS = rnd(8), uKS = rnd(8);
    const U = concat(await hashR6(userPw, uVS, none), uVS, uKS);
    const UE = await aesEncNoPad(await hashR6(userPw, uKS, none), zero, fileKey);
    const oVS = rnd(8), oKS = rnd(8);
    const O = concat(await hashR6(ownerPw, oVS, U), oVS, oKS);
    const OE = await aesEncNoPad(await hashR6(ownerPw, oKS, U), zero, fileKey);
    let perm = 0xfffff0c0 >>> 0; // reserved bits set; restrictions below are added as allowed bits
    const allow = o.allow || {};
    if (allow.print !== false) perm |= 4 | 2048; if (allow.modify !== false) perm |= 8 | 256 | 1024; if (allow.copy !== false) perm |= 16 | 512; if (allow.annotate !== false) perm |= 32;
    const pInt = perm | 0;
    const pb = new Uint8Array(16); new DataView(pb.buffer).setInt32(0, pInt, true); pb.set([255, 255, 255, 255], 4); pb[8] = 84; pb[9] = 97; pb[10] = 100; pb[11] = 98; pb.set(rnd(4), 12);
    const Perms = await aesEncNoPad(fileKey, zero, pb);
    const key = await aesKey(fileKey);
    const hex = (u) => L.PDFHexString.of(Array.from(u, (x) => x.toString(16).padStart(2, '0')).join(''));
    const encStr = async (s) => hex(await aesEncPdf(key, s.asBytes()));
    const walk = async (v) => {
      if (v instanceof L.PDFString || v instanceof L.PDFHexString) return encStr(v);
      if (v instanceof L.PDFArray) { for (let i = 0; i < v.size(); i++) { const x = v.get(i); const r = await walk(x); if (r !== x) v.set(i, r); } return v; }
      if (v instanceof L.PDFDict) { for (const [k, x] of v.entries()) { const r = await walk(x); if (r !== x) v.set(k, r); } return v; }
      return v;
    };
    let count = 0;
    for (const [, obj] of ctx.enumerateIndirectObjects()) {
      if (obj instanceof L.PDFRawStream) {
        await walk(obj.dict); obj.contents = await aesEncPdf(key, obj.contents);
      } else if (obj instanceof L.PDFStream) {
        throw new Error('Unexpected stream type while encrypting.');
      } else await walk(obj);
      if (++count % 100 === 0) await P.tick();
    }
    const stdcf = ctx.obj({ Type: 'CryptFilter', CFM: 'AESV3', AuthEvent: 'DocOpen', Length: 32 });
    const encDict = ctx.obj({ Filter: 'Standard', V: 5, R: 6, Length: 256, P: pInt, O: hex(O), U: hex(U), OE: hex(OE), UE: hex(UE), Perms: hex(Perms), CF: ctx.obj({ StdCF: stdcf }), StmF: 'StdCF', StrF: 'StdCF' });
    const encRef = ctx.register(encDict);
    ctx.trailerInfo.Encrypt = encRef;
    ctx.trailerInfo.ID = ctx.obj([hex(rnd(16)), hex(rnd(16))]);
    return doc.save({ useObjectStreams: false });
  };
})(typeof window !== 'undefined' ? window : globalThis);
