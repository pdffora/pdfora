/* PDFora Office engine: reads .docx/.xlsx/.csv, writes .docx/.xlsx, and lays documents out as real PDFs. */
(function (g) {
  'use strict';
  const P = (g.PDFora = g.PDFora || {});
  const O = (P.Office = {});

  const esc = (s) => String(s).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\ufffe\uffff]/g, '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const parseXml = (s) => new DOMParser().parseFromString(s, 'application/xml');
  const kids = (el, name) => el ? Array.from(el.children).filter((c) => c.localName === name) : [];
  const kid = (el, name) => kids(el, name)[0] || null;
  const wattr = (el, name) => el ? (el.getAttribute('w:' + name) ?? el.getAttribute(name)) : null;
  const needZip = () => { if (!g.JSZip) throw new Error('ZIP library did not load. Reload the page.'); return g.JSZip; };

  async function openZip(file, kind, mainPart) {
    let zip;
    try { zip = await needZip().loadAsync(await file.arrayBuffer()); } catch (e) { throw new Error('"' + file.name + '" is not a valid ' + kind + ' file (it could not be opened as an Office document).'); }
    if (!zip.file(mainPart)) throw new Error('"' + file.name + '" is not a valid ' + kind + ' file.');
    return zip;
  }

  /* ============================================================
     DOCX reader
     ============================================================ */
  const onoff = (el) => { if (!el) return undefined; const v = wattr(el, 'val'); return !(v === '0' || v === 'false' || v === 'off'); };
  function parseRpr(rpr) {
    const r = {}; if (!rpr) return r;
    let v;
    if ((v = onoff(kid(rpr, 'b'))) !== undefined) r.bold = v;
    if ((v = onoff(kid(rpr, 'i'))) !== undefined) r.italic = v;
    if ((v = onoff(kid(rpr, 'strike'))) !== undefined) r.strike = v;
    if ((v = onoff(kid(rpr, 'caps'))) !== undefined) r.caps = v;
    const u = kid(rpr, 'u'); if (u) r.underline = wattr(u, 'val') !== 'none';
    const sz = kid(rpr, 'sz'); if (sz) r.size = parseInt(wattr(sz, 'val'), 10) / 2;
    const col = kid(rpr, 'color'); if (col && wattr(col, 'val') && wattr(col, 'val') !== 'auto') r.color = wattr(col, 'val');
    const va = kid(rpr, 'vertAlign'); if (va) r.vert = wattr(va, 'val');
    const rf = kid(rpr, 'rFonts');
    if (rf) {
      const name = wattr(rf, 'ascii') || wattr(rf, 'hAnsi') || '';
      if (name) r.family = /times|georgia|cambria|garamond|palatino|book|serif|minion|constantia/i.test(name) && !/sans/i.test(name) ? 'serif' : /courier|consolas|mono|menlo|lucida console/i.test(name) ? 'mono' : 'sans';
    }
    return r;
  }
  function parsePpr(ppr) {
    const p = {}; if (!ppr) return p;
    const jc = kid(ppr, 'jc'); if (jc) p.align = wattr(jc, 'val');
    const sp = kid(ppr, 'spacing');
    if (sp) {
      if (wattr(sp, 'before') != null) p.before = +wattr(sp, 'before') / 20;
      if (wattr(sp, 'after') != null) p.after = +wattr(sp, 'after') / 20;
      if (wattr(sp, 'line') != null) { p.line = +wattr(sp, 'line'); p.lineRule = wattr(sp, 'lineRule') || 'auto'; }
    }
    const ind = kid(ppr, 'ind');
    if (ind) {
      const l = wattr(ind, 'left') ?? wattr(ind, 'start'); if (l != null) p.left = +l / 20;
      const fl = wattr(ind, 'firstLine'); if (fl != null) p.first = +fl / 20;
      const h = wattr(ind, 'hanging'); if (h != null) p.first = -h / 20;
    }
    const ps = kid(ppr, 'pStyle'); if (ps) p.style = wattr(ps, 'val');
    const np = kid(ppr, 'numPr'); if (np) { const id = kid(np, 'numId'), lv = kid(np, 'ilvl'); p.numId = id ? wattr(id, 'val') : null; p.ilvl = lv ? +wattr(lv, 'val') : 0; }
    if (kid(ppr, 'pageBreakBefore')) p.pageBreakBefore = true;
    return p;
  }

  async function readDocx(file) {
    const zip = await openZip(file, '.docx', 'word/document.xml');
    const doc = parseXml(await zip.file('word/document.xml').async('string'));
    if (doc.getElementsByTagName('parsererror').length) throw new Error('"' + file.name + '" contains damaged document XML.');
    // styles
    const styles = {}; let defR = {}, defP = {};
    if (zip.file('word/styles.xml')) {
      const sx = parseXml(await zip.file('word/styles.xml').async('string'));
      const dd = sx.getElementsByTagName('w:docDefaults')[0];
      if (dd) { defR = parseRpr(kid(kid(dd, 'rPrDefault'), 'rPr')); defP = parsePpr(kid(kid(dd, 'pPrDefault'), 'pPr')); }
      for (const s of Array.from(sx.getElementsByTagName('w:style'))) {
        const id = wattr(s, 'styleId'); const bo = kid(s, 'basedOn'); const tp = kid(s, 'tblPr');
        styles[id] = { type: wattr(s, 'type'), based: bo ? wattr(bo, 'val') : null, r: parseRpr(kid(s, 'rPr')), p: parsePpr(kid(s, 'pPr')), grid: !!(tp && kid(tp, 'tblBorders') && Array.from(kid(tp, 'tblBorders').children).some((b) => !/^(nil|none)$/.test(wattr(b, 'val') || 'nil'))) };
      }
    }
    const resolve = (id, key) => { const chain = []; let s = styles[id], n = 0; while (s && n++ < 20) { chain.unshift(s); s = styles[s.based]; } return Object.assign({}, ...chain.map((c) => c[key])); };
    // numbering
    const nums = {}, abs = {};
    if (zip.file('word/numbering.xml')) {
      const nx = parseXml(await zip.file('word/numbering.xml').async('string'));
      for (const a of Array.from(nx.getElementsByTagName('w:abstractNum'))) {
        const lv = {}; for (const l of kids(a, 'lvl')) { const f = kid(l, 'numFmt'), t = kid(l, 'lvlText'), st = kid(l, 'start'); lv[wattr(l, 'ilvl')] = { fmt: f ? wattr(f, 'val') : 'decimal', text: t ? wattr(t, 'val') : '', start: st ? +wattr(st, 'val') : 1, ppr: parsePpr(kid(l, 'pPr')) }; }
        abs[wattr(a, 'abstractNumId')] = lv;
      }
      for (const n of Array.from(nx.getElementsByTagName('w:num'))) { const a = kid(n, 'abstractNumId'); if (a) nums[wattr(n, 'numId')] = wattr(a, 'val'); }
    }
    const counters = {};
    const roman = (n) => { const m = [[1000, 'M'], [900, 'CM'], [500, 'D'], [400, 'CD'], [100, 'C'], [90, 'XC'], [50, 'L'], [40, 'XL'], [10, 'X'], [9, 'IX'], [5, 'V'], [4, 'IV'], [1, 'I']]; let s = ''; for (const [v, r] of m) while (n >= v) { s += r; n -= v; } return s; };
    const alpha = (n) => { let s = ''; while (n > 0) { n--; s = String.fromCharCode(97 + (n % 26)) + s; n = Math.floor(n / 26); } return s; };
    const fmtNum = (n, f) => f === 'lowerLetter' ? alpha(n) : f === 'upperLetter' ? alpha(n).toUpperCase() : f === 'lowerRoman' ? roman(n).toLowerCase() : f === 'upperRoman' ? roman(n) : String(n);
    const numLabel = (numId, ilvl) => {
      const a = abs[nums[numId]]; if (!a || !a[ilvl]) return null;
      const c = counters[numId] || (counters[numId] = []);
      const lv = a[ilvl];
      c[ilvl] = (c[ilvl] == null ? lv.start : c[ilvl] + 1); for (let k = ilvl + 1; k < 10; k++) c[k] = undefined;
      if (lv.fmt === 'bullet') return { text: ilvl ? '\u2013' : '\u2022', ppr: lv.ppr };
      if (lv.fmt === 'none') return { text: '', ppr: lv.ppr };
      let t = lv.text.replace(/%(\d)/g, (_, d) => { const i = +d - 1; const l2 = a[i]; const val = c[i] == null ? (l2 ? l2.start : 1) : c[i]; return fmtNum(val, l2 ? l2.fmt : 'decimal'); });
      return { text: t, ppr: lv.ppr };
    };
    // relationships / images
    const rels = {};
    if (zip.file('word/_rels/document.xml.rels')) {
      const rx = parseXml(await zip.file('word/_rels/document.xml.rels').async('string'));
      for (const r of Array.from(rx.getElementsByTagName('Relationship'))) rels[r.getAttribute('Id')] = r.getAttribute('Target');
    }
    const imgCache = {}; const warnings = [];
    const getImage = async (rid) => {
      if (imgCache[rid] !== undefined) return imgCache[rid];
      let t = rels[rid]; let out = null;
      if (t) {
        t = t.replace(/^\//, '').replace(/^(\.\.\/)+/, ''); const path = t.startsWith('word/') ? t : 'word/' + t;
        const f = zip.file(path);
        if (f) {
          const bytes = await f.async('uint8array');
          const kind = (bytes[0] === 0x89 && bytes[1] === 0x50) ? 'png' : (bytes[0] === 0xff && bytes[1] === 0xd8) ? 'jpg' : null;
          if (kind) out = { kind, bytes };
          else { // gif/webp/bmp: re-encode through the browser
            try { const blob = new Blob([bytes]); const im = await P.loadImage(Object.assign(blob, { name: path })); const c = P.drawToCanvas(im, im.w, im.h); const b = await P.canvasBlob(c, 'image/png'); out = { kind: 'png', bytes: new Uint8Array(await b.arrayBuffer()) }; im.close(); } catch (e) { warnings.push('An image in the document (' + path.split('/').pop() + ') uses a format that could not be converted and was skipped.'); }
          }
        }
      }
      return (imgCache[rid] = out);
    };

    const pre = (el, n) => { // find first descendant by local name
      const all = el.getElementsByTagName('*'); for (let i = 0; i < all.length; i++) if (all[i].localName === n) return all[i]; return null;
    };

    async function parseParagraph(p, out) {
      const ppr0 = parsePpr(kid(p, 'pPr'));
      const sId = ppr0.style; const sP = sId ? resolve(sId, 'p') : {}; const sR = sId ? resolve(sId, 'r') : {};
      const ppr = Object.assign({}, defP, sP, ppr0);
      const items = []; const extra = [];
      let pending = null;
      const run = async (r, inherit) => {
        const rpr = Object.assign({}, defR, sR, inherit, parseRpr(kid(r, 'rPr')));
        const rs = kid(kid(r, 'rPr'), 'rStyle'); if (rs) Object.assign(rpr, resolve(wattr(rs, 'val'), 'r'), parseRpr(kid(r, 'rPr')));
        for (const c of Array.from(r.children)) {
          const n = c.localName;
          if (n === 't') items.push({ t: 'text', text: c.textContent, rpr });
          else if (n === 'tab') items.push({ t: 'tab', rpr });
          else if (n === 'br' || n === 'cr') items.push(wattr(c, 'type') === 'page' ? { t: 'pagebreak' } : { t: 'br', rpr });
          else if (n === 'noBreakHyphen') items.push({ t: 'text', text: '-', rpr });
          else if (n === 'drawing' || n === 'pict' || n === 'object') {
            const tb = pre(c, 'txbxContent');
            if (tb) { for (const tp of kids(tb, 'p')) await parseParagraph(tp, extra); }
            const blip = pre(c, 'blip'); const vml = pre(c, 'imagedata');
            const rid = blip ? (blip.getAttribute('r:embed') || blip.getAttribute('embed')) : vml ? (vml.getAttribute('r:id') || vml.getAttribute('id')) : null;
            if (rid) {
              const img = await getImage(rid);
              if (img) { const ext = pre(c, 'extent'); items.push({ t: 'img', img, w: ext ? +ext.getAttribute('cx') / 12700 : 0, h: ext ? +ext.getAttribute('cy') / 12700 : 0 }); }
            }
          }
        }
      };
      const walk = async (el, inherit) => {
        for (const c of Array.from(el.children)) {
          const n = c.localName;
          if (n === 'r') await run(c, inherit);
          else if (n === 'hyperlink' || n === 'fldSimple' || n === 'ins' || n === 'smartTag' || n === 'sdtContent' || n === 'sdt') await walk(c, inherit);
          else if (n === 'AlternateContent') { const ch = kid(c, 'Choice') || kid(c, 'Fallback'); if (ch) await walk(ch, inherit); }
        }
      };
      await walk(p, {});
      let label = null;
      if (ppr.numId && ppr.numId !== '0') { label = numLabel(ppr.numId, ppr.ilvl || 0); if (label && label.ppr) { if (ppr0.left == null && label.ppr.left != null) ppr.left = label.ppr.left; if (ppr0.first == null && label.ppr.first != null) ppr.first = label.ppr.first; } }
      out.push({ t: 'p', ppr, items, label, styleR: Object.assign({}, defR, sR) });
      for (const e of extra) out.push(e);
    }
    async function parseTable(tbl, out) {
      const tp = kid(tbl, 'tblPr'); const st = tp && kid(tp, 'tblStyle');
      let border = !!(st && styles[wattr(st, 'val')] && styles[wattr(st, 'val')].grid) || !!(st && /grid/i.test(wattr(st, 'val')));
      const tb = tp && kid(tp, 'tblBorders'); if (tb && Array.from(tb.children).some((b) => !/^(nil|none)$/.test(wattr(b, 'val') || 'nil'))) border = true;
      const grid = kids(kid(tbl, 'tblGrid'), 'gridCol').map((c) => +wattr(c, 'w') / 20);
      const rows = [];
      for (const tr of kids(tbl, 'tr')) {
        const cells = [];
        for (const tc of kids(tr, 'tc')) {
          const pr = kid(tc, 'tcPr'); const gs = pr && kid(pr, 'gridSpan'); const shd = pr && kid(pr, 'shd'); const vm = pr && kid(pr, 'vMerge');
          const blocks = []; await parseBlocks(tc, blocks);
          cells.push({ span: gs ? +wattr(gs, 'val') : 1, fill: shd && wattr(shd, 'fill') && wattr(shd, 'fill') !== 'auto' ? wattr(shd, 'fill') : null, vcont: !!(vm && wattr(vm, 'val') !== 'restart'), blocks });
        }
        rows.push(cells);
      }
      out.push({ t: 'tbl', grid, rows, border });
    }
    async function parseBlocks(parent, out) {
      for (const c of Array.from(parent.children)) {
        const n = c.localName;
        if (n === 'p') await parseParagraph(c, out);
        else if (n === 'tbl') await parseTable(c, out);
        else if (n === 'sdt') { const sc = kid(c, 'sdtContent'); if (sc) await parseBlocks(sc, out); }
        else if (n === 'AlternateContent') { const ch = kid(c, 'Choice'); if (ch) await parseBlocks(ch, out); }
      }
    }
    const body = doc.getElementsByTagName('w:body')[0];
    if (!body) throw new Error('"' + file.name + '" has no document body.');
    const blocks = []; await parseBlocks(body, blocks);
    const sect = Array.from(body.children).filter((c) => c.localName === 'sectPr').pop() || doc.getElementsByTagName('w:sectPr')[0];
    let page = { w: 595.28, h: 841.89, t: 72, b: 72, l: 72, r: 72 };
    if (sect) {
      const sz = kid(sect, 'pgSz'), mar = kid(sect, 'pgMar');
      if (sz) { page.w = +wattr(sz, 'w') / 20 || page.w; page.h = +wattr(sz, 'h') / 20 || page.h; if (wattr(sz, 'orient') === 'landscape' && page.w < page.h) [page.w, page.h] = [page.h, page.w]; }
      if (mar) { page.t = +wattr(mar, 'top') / 20 || 72; page.b = +wattr(mar, 'bottom') / 20 || 72; page.l = +wattr(mar, 'left') / 20 || 72; page.r = +wattr(mar, 'right') / 20 || 72; }
    }
    return { blocks, page, warnings, defR, defP };
  }
  O.readDocx = readDocx;

  /* ============================================================
     Text layout helpers (shared by Word->PDF and Excel->PDF)
     ============================================================ */
  const colorCache = new Map();
  const hexRgb = (hex, def) => { const k = String(hex); if (colorCache.has(k)) return colorCache.get(k); const v = hexRgb0(hex, def); colorCache.set(k, v); return v; };
  const hexRgb0 = (hex, def) => { const L = P.need(); if (!hex || !/^[0-9a-fA-F]{6}$/.test(hex)) return def || L.rgb(0, 0, 0); return L.rgb(parseInt(hex.slice(0, 2), 16) / 255, parseInt(hex.slice(2, 4), 16) / 255, parseInt(hex.slice(4, 6), 16) / 255); };

  /* greedy word wrap of a single style string */
  function wrapText(font, size, text, width) {
    const lines = []; const paras = String(text).split(/\r?\n/);
    for (const para of paras) {
      const words = para.split(/(\s+)/); let line = '';
      for (const w of words) {
        if (!w) continue;
        const test = line + w;
        if (font.widthOfTextAtSize(test, size) <= width || !line.trim()) {
          if (font.widthOfTextAtSize(w, size) > width && !/^\s+$/.test(w)) { // break very long word
            let cur = line; for (const ch of w) { if (font.widthOfTextAtSize(cur + ch, size) > width && cur) { lines.push(cur); cur = ''; } cur += ch; } line = cur;
          } else line = test;
        } else { lines.push(line.trimEnd()); line = /^\s+$/.test(w) ? '' : w; }
      }
      lines.push(line.trimEnd());
    }
    return lines;
  }
  O.wrapText = wrapText;

  /* ============================================================
     Word -> PDF
     ============================================================ */
  O.docxToPdf = async function (file, ctx) {
    const L = P.need();
    const model = await readDocx(file);
    model.warnings.forEach((w) => ctx.warn(w));
    const pdf = await L.PDFDocument.create(); const fs = new P.FontSet(pdf);
    const pg = model.page; const contentW = pg.w - pg.l - pg.r; const bottom = pg.b; const topY = pg.h - pg.t;
    let page = null, y = 0; let lostFlag = false;
    const newPage = () => { page = pdf.addPage([pg.w, pg.h]); y = topY; };
    newPage();
    const imgCache = new Map();
    const embedImg = async (im) => { if (!imgCache.has(im.bytes)) imgCache.set(im.bytes, im.kind === 'png' ? await pdf.embedPng(im.bytes) : await pdf.embedJpg(im.bytes)); return imgCache.get(im.bytes); };

    /* turns a paragraph block into measured lines */
    async function layoutPara(b, width) {
      const ppr = b.ppr; const atoms = [];
      const baseSize = b.styleR.size || 11;
      const push = async (text, rpr, kind) => {
        const style = { bold: rpr.bold, italic: rpr.italic, family: rpr.family || (b.styleR.family) || 'sans' };
        let size = rpr.size || baseSize; if (rpr.vert === 'superscript' || rpr.vert === 'subscript') size *= 0.7;
        if (rpr.caps) text = text.toUpperCase();
        const pk = await fs.pick(style, text); if (pk.lost) lostFlag = true;
        const parts = pk.text.split(/(\s+)/).filter((s) => s.length);
        for (const part of parts) atoms.push({ text: part, font: pk.font, size, color: hexRgb(rpr.color), under: rpr.underline, strike: rpr.strike, space: /^\s+$/.test(part), w: pk.font.widthOfTextAtSize(part, size), rise: rpr.vert === 'superscript' ? size * 0.5 : rpr.vert === 'subscript' ? -size * 0.2 : 0 });
      };
      if (b.label && b.label.text) {
        const firstRun = b.items.find((i) => i.t === 'text');
        await push(b.label.text, Object.assign({}, b.styleR, firstRun ? firstRun.rpr : {}, { underline: false, strike: false }));
        const la = atoms[atoms.length - 1];
        const hang = ppr.first < 0 ? -ppr.first : 0; la.w = Math.max(la.w + 4, hang || 0); la.fixed = true;
      }
      for (const it of b.items) {
        if (it.t === 'text') await push(it.text, it.rpr);
        else if (it.t === 'tab') atoms.push({ tab: true, w: 0, size: baseSize });
        else if (it.t === 'br') atoms.push({ br: true, w: 0, size: baseSize });
        else if (it.t === 'pagebreak') atoms.push({ pagebreak: true, w: 0, size: baseSize });
        else if (it.t === 'img') atoms.push({ img: it, w: 0, size: baseSize });
      }
      const left = (ppr.left || 0) + (b.label ? 0 : 0); const first = ppr.first || 0;
      const lines = []; let cur = { atoms: [], w: 0, size: 0, x0: left + first }; let avail = width - cur.x0;
      const flush = (hard) => { lines.push(Object.assign(cur, { hard })); cur = { atoms: [], w: 0, size: 0, x0: left }; avail = width - left; };
      for (const a of atoms) {
        if (a.pagebreak) { flush(true); lines.push({ pagebreak: true, atoms: [], w: 0, size: baseSize }); continue; }
        if (a.br) { cur.size = Math.max(cur.size, a.size); flush(true); continue; }
        if (a.img) {
          if (cur.atoms.length) flush(true);
          let w = a.img.w, h = a.img.h; const emb = await embedImg(a.img.img);
          if (!w || !h) { w = emb.width * 0.75; h = emb.height * 0.75; }
          const maxW = width - left; if (w > maxW) { h *= maxW / w; w = maxW; } const maxH = pg.h - pg.t - pg.b - 10; if (h > maxH) { w *= maxH / h; h = maxH; }
          lines.push({ image: emb, w, h, atoms: [], size: 0, x0: left, h }); continue;
        }
        if (a.tab) { const x = cur.x0 + cur.w; const next = (Math.floor((x - left) / 36) + 1) * 36 + left; a.w = Math.max(6, next - x); a.space = true; a.text = ''; }
        if (a.space && !cur.atoms.length && lines.length && !a.tab) continue; // trim leading spaces on wrapped lines
        if (cur.w + a.w > avail && cur.atoms.length && !a.space) {
          while (cur.atoms.length && cur.atoms[cur.atoms.length - 1].space) { cur.w -= cur.atoms.pop().w; }
          flush(false);
        }
        if (!a.space && a.w > avail) { // single word wider than the line: hard split
          let chunk = ''; for (const ch of a.text) { const cw = a.font.widthOfTextAtSize(chunk + ch, a.size); if (cw > avail && chunk) { cur.atoms.push(Object.assign({}, a, { text: chunk, w: a.font.widthOfTextAtSize(chunk, a.size) })); cur.w += a.font.widthOfTextAtSize(chunk, a.size); cur.size = Math.max(cur.size, a.size); flush(false); chunk = ''; } chunk += ch; }
          a.text = chunk; a.w = a.font.widthOfTextAtSize(chunk, a.size);
        }
        cur.atoms.push(a); cur.w += a.w; cur.size = Math.max(cur.size, a.size || 0);
      }
      if (cur.atoms.length || !lines.length) lines.push(cur);
      if (lines.length) lines[lines.length - 1].last = true;
      let mult = 1; let fixed = null;
      if (ppr.line) { if (ppr.lineRule === 'auto') mult = ppr.line / 240; else fixed = ppr.line / 20; }
      for (const ln of lines) {
        if (ln.pagebreak || ln.image) continue;
        const sz = ln.size || baseSize; ln.sz = sz;
        ln.h = fixed ? (ppr.lineRule === 'atLeast' ? Math.max(fixed, sz * 1.2) : fixed) : sz * 1.2 * mult;
      }
      return { lines, ppr, label: b.label, width };
    }

    function drawLine(pageObj, ln, x, baseY, width, ppr, label, firstLine) {
      if (ln.image) { pageObj.drawImage(ln.image, { x: x + ln.x0 + (ppr.align === 'center' ? (width - ln.x0 - ln.w) / 2 : ppr.align === 'right' ? width - ln.x0 - ln.w : 0), y: baseY - ln.h, width: ln.w, height: ln.h }); return; }
      let cx = x + ln.x0; const avail = width - ln.x0;
      let extra = 0;
      if (ppr.align === 'center') cx += (avail - ln.w) / 2; else if (ppr.align === 'right' || ppr.align === 'end') cx += avail - ln.w;
      else if (ppr.align === 'both' && !ln.last && !ln.hard) { const spaces = ln.atoms.filter((a) => a.space && !a.tab).length; if (spaces) extra = (avail - ln.w) / spaces; }
      if (label && label.text && firstLine) { /* label is the first atoms of the line already */ }
      // merge neighbouring atoms with the same style into one text object (keeps text selectable/searchable)
      const segs = []; let curSeg = null;
      for (const a of ln.atoms) {
        const key = a.font === (curSeg && curSeg.font) && a.size === (curSeg && curSeg.size) && a.color === (curSeg && curSeg.color) && !!a.under === !!(curSeg && curSeg.under) && !!a.strike === !!(curSeg && curSeg.strike) && (a.rise || 0) === (curSeg && curSeg.rise || 0);
        if (curSeg && key && !a.tab && !extra && !a.fixed && !curSeg.fixed) { curSeg.text += a.text; curSeg.w += a.w; }
        else { curSeg = { text: a.tab ? '' : a.text, w: a.w, font: a.font, size: a.size, color: a.color, under: a.under, strike: a.strike, rise: a.rise || 0, space: a.space, tab: a.tab, fixed: a.fixed, extra: a.space && !a.tab ? extra : 0 }; segs.push(curSeg); }
      }
      for (const a of segs) {
        if (a.text && a.text.trim()) {
          pageObj.drawText(a.text, { x: cx, y: baseY - ln.sz * 0.8 + a.rise, size: a.size, font: a.font, color: a.color });
          const ux = cx, uw = a.w - (/\s+$/.test(a.text) ? a.font.widthOfTextAtSize(a.text.match(/\s+$/)[0], a.size) : 0);
          if (a.under) pageObj.drawLine({ start: { x: ux, y: baseY - ln.sz * 0.8 - 1.5 }, end: { x: ux + uw, y: baseY - ln.sz * 0.8 - 1.5 }, thickness: 0.5, color: a.color });
          if (a.strike) pageObj.drawLine({ start: { x: ux, y: baseY - ln.sz * 0.55 }, end: { x: ux + uw, y: baseY - ln.sz * 0.55 }, thickness: 0.5, color: a.color });
        }
        cx += a.w + a.extra;
      }
    }

    /* flow blocks onto pages */
    const placeParagraph = async (b) => {
      const lay = await layoutPara(b, contentW); const ppr = lay.ppr;
      if (ppr.pageBreakBefore && y < topY) newPage();
      y -= (ppr.before || 0);
      for (const ln of lay.lines) {
        if (ln.pagebreak) { newPage(); continue; }
        const h = ln.image ? ln.h : ln.h;
        if (y - h < bottom) { newPage(); }
        drawLine(page, ln, pg.l, y, contentW, ppr, lay.label, false);
        y -= h;
      }
      y -= (ppr.after || 0);
      if (y < bottom) newPage();
    };

    const placeTable = async (t) => {
      const ncols = Math.max(t.grid.length, ...t.rows.map((r) => r.reduce((a, c) => a + c.span, 0)), 1);
      let grid = t.grid.length === ncols ? t.grid.slice() : Array.from({ length: ncols }, () => contentW / ncols);
      const total = grid.reduce((a, c) => a + c, 0); if (total > contentW || total < 1) grid = grid.map((w) => w * contentW / (total || 1));
      const pad = 4;
      for (const row of t.rows) {
        // measure
        const cellLay = []; let rowH = 0; let col = 0;
        for (const cell of row) {
          const w = grid.slice(col, col + cell.span).reduce((a, c) => a + c, 0); const x = grid.slice(0, col).reduce((a, c) => a + c, 0);
          const paras = []; let hh = pad * 2;
          const collect = async (blocks) => { for (const bl of blocks) { if (bl.t === 'p') { const l = await layoutPara(bl, Math.max(10, w - pad * 2)); paras.push(l); hh += l.lines.reduce((a, ln) => a + (ln.pagebreak ? 0 : ln.h), 0) + (l.ppr.before || 0) * 0.5 + (l.ppr.after || 0) * 0.5; } else if (bl.t === 'tbl') for (const r of bl.rows) for (const c of r) await collect(c.blocks); } };
          if (!cell.vcont) await collect(cell.blocks);
          cellLay.push({ cell, w, x, paras }); rowH = Math.max(rowH, hh); col += cell.span;
        }
        rowH = Math.max(rowH, 14); const maxH = topY - bottom;
        if (rowH > maxH) rowH = maxH;
        if (y - rowH < bottom) newPage();
        for (const cl of cellLay) {
          if (cl.cell.fill || t.border) page.drawRectangle({ x: pg.l + cl.x, y: y - rowH, width: cl.w, height: rowH, color: cl.cell.fill ? hexRgb(cl.cell.fill) : undefined, borderColor: t.border ? L.rgb(0.35, 0.35, 0.35) : undefined, borderWidth: t.border ? 0.5 : 0 });
          let cy = y - pad;
          for (const l of cl.paras) { cy -= (l.ppr.before || 0) * 0.5; for (const ln of l.lines) { if (ln.pagebreak) continue; if (cy - ln.h < y - rowH) break; drawLine(page, ln, pg.l + cl.x + pad, cy, cl.w - pad * 2, l.ppr, l.label, false); cy -= ln.h; } cy -= (l.ppr.after || 0) * 0.5; }
        }
        y -= rowH;
      }
      y -= 8;
    };

    let count = 0;
    for (const b of model.blocks) {
      if (b.t === 'p') await placeParagraph(b); else if (b.t === 'tbl') await placeTable(b);
      if (++count % 50 === 0) { ctx.progress(count / model.blocks.length, 'Laying out page ' + pdf.getPageCount()); await P.tick(); }
    }
    if (lostFlag) P.warnLost(ctx);
    ctx.warn('Word to PDF re-creates the document layout. Headers, footers, text boxes and advanced Word features may look different from Word.');
    return P.savePdf(pdf, P.baseName(file.name) + '.pdf');
  };

  /* ============================================================
     XLSX / CSV reader
     ============================================================ */
  const colIdx = (ref) => { const m = /^([A-Z]+)(\d+)$/i.exec(ref); if (!m) return null; let c = 0; for (const ch of m[1].toUpperCase()) c = c * 26 + ch.charCodeAt(0) - 64; return { c: c - 1, r: +m[2] - 1 }; };
  const colName = (i) => { let s = ''; i++; while (i > 0) { const m = (i - 1) % 26; s = String.fromCharCode(65 + m) + s; i = Math.floor((i - 1) / 26); } return s; };
  O.colName = colName;
  const BUILTIN_DATE = new Set([14, 15, 16, 17, 18, 19, 20, 21, 22, 45, 46, 47]);
  function isDateFmt(code) { const c = String(code).replace(/"[^"]*"/g, '').replace(/\[[^\]]*\]/g, '').replace(/\\./g, ''); return /[dmyhs]/i.test(c) && !/^general/i.test(c) && !/[#0]/.test(c); }
  function fmtDate(serial, code) {
    if (serial >= 60) serial -= 0; const ms = Math.round((serial - 25569) * 86400000); const d = new Date(ms); if (isNaN(d)) return String(serial);
    const pad = (n) => String(n).padStart(2, '0'); const hasDate = /[dy]/i.test(code), hasTime = /[hs]/i.test(code) || /m/.test(code.replace(/[dy]/gi, '')) && /:/.test(code);
    const ds = d.getUTCFullYear() + '-' + pad(d.getUTCMonth() + 1) + '-' + pad(d.getUTCDate()); const ts = pad(d.getUTCHours()) + ':' + pad(d.getUTCMinutes()) + (/s/i.test(code) ? ':' + pad(d.getUTCSeconds()) : '');
    return hasDate && hasTime ? ds + ' ' + ts : hasTime && !hasDate ? ts : ds;
  }
  function fmtNumber(v, code) {
    if (!code || /^general$/i.test(code)) return String(parseFloat(v.toPrecision(15)));
    const sec = String(code).split(';')[0].replace(/\[[^\]]*\]/g, '').replace(/_./g, '').replace(/\*./g, '').replace(/"/g, '').replace(/\\/g, '');
    const m = /([^#0?.,%]*)([#0?.,]+)(%?)([^#0?.,%]*)/.exec(sec); if (!m) return String(parseFloat(v.toPrecision(15)));
    const [, pre, num, pct, post] = m; const dec = (num.split('.')[1] || '').replace(/[^0#?]/g, '').length;
    let val = pct ? v * 100 : v; let s = Math.abs(val).toFixed(dec);
    if (/,/.test(num.split('.')[0])) { const parts = s.split('.'); parts[0] = parts[0].replace(/\B(?=(?:\d{3})+$)/g, ','); s = parts.join('.'); }
    return (val < 0 ? '-' : '') + pre + s + pct + post;
  }

  async function readXlsx(file) {
    const zip = await openZip(file, '.xlsx', 'xl/workbook.xml');
    const wb = parseXml(await zip.file('xl/workbook.xml').async('string'));
    const rels = {};
    const rx = parseXml(await zip.file('xl/_rels/workbook.xml.rels').async('string'));
    for (const r of Array.from(rx.getElementsByTagName('Relationship'))) rels[r.getAttribute('Id')] = r.getAttribute('Target');
    const sst = [];
    if (zip.file('xl/sharedStrings.xml')) {
      const sx = parseXml(await zip.file('xl/sharedStrings.xml').async('string'));
      for (const si of Array.from(sx.getElementsByTagName('si'))) sst.push(Array.from(si.getElementsByTagName('t')).filter((t) => !t.parentNode || t.parentNode.localName !== 'rPh').map((t) => t.textContent).join(''));
    }
    const xfDate = []; const xfFmt = [];
    if (zip.file('xl/styles.xml')) {
      const st = parseXml(await zip.file('xl/styles.xml').async('string'));
      const custom = {}; for (const nf of Array.from(st.getElementsByTagName('numFmt'))) custom[nf.getAttribute('numFmtId')] = nf.getAttribute('formatCode');
      const cx = st.getElementsByTagName('cellXfs')[0];
      if (cx) Array.from(cx.children).forEach((xf, i) => { const id = +xf.getAttribute('numFmtId'); const code = custom[id] || ''; xfFmt[i] = code || (id === 9 ? '0%' : id === 10 ? '0.00%' : id === 2 ? '0.00' : id === 4 ? '#,##0.00' : id === 3 ? '#,##0' : ''); xfDate[i] = BUILTIN_DATE.has(id) || (code && isDateFmt(code)); xfFmt[i] = xfDate[i] ? (code || 'yyyy-mm-dd') : xfFmt[i]; });
    }
    const sheets = [];
    for (const s of Array.from(wb.getElementsByTagName('sheet'))) {
      const rid = s.getAttribute('r:id') || s.getAttribute('id'); let target = rels[rid]; if (!target) continue;
      target = target.replace(/^\//, ''); const path = target.startsWith('xl/') ? target : 'xl/' + target;
      const f = zip.file(path); if (!f) continue;
      const sx = parseXml(await f.async('string')); const rows = []; let maxC = 0;
      for (const row of Array.from(sx.getElementsByTagName('row'))) {
        const rIdx = +row.getAttribute('r') - 1;
        for (const c of Array.from(row.children)) {
          if (c.localName !== 'c') continue;
          const pos = colIdx(c.getAttribute('r')); if (!pos) continue;
          const t = c.getAttribute('t'); const vEl = kid(c, 'v'); let v = vEl ? vEl.textContent : '';
          let text = '', num = false;
          if (t === 's') text = sst[+v] ?? ''; else if (t === 'inlineStr') text = Array.from(c.getElementsByTagName('t')).map((x) => x.textContent).join('');
          else if (t === 'b') text = v === '1' ? 'TRUE' : 'FALSE'; else if (t === 'str' || t === 'e') text = v;
          else if (v !== '') { const nv = parseFloat(v); const si = +c.getAttribute('s') || 0; if (isNaN(nv)) text = v; else if (xfDate[si]) text = fmtDate(nv, xfFmt[si]); else { text = fmtNumber(nv, xfFmt[si]); num = true; } }
          if (text === '') continue;
          (rows[pos.r] || (rows[pos.r] = []))[pos.c] = { v: text, num }; maxC = Math.max(maxC, pos.c + 1);
        }
        if (rows.length > 200000) break;
      }
      sheets.push({ name: s.getAttribute('name') || 'Sheet', rows, cols: maxC });
    }
    if (!sheets.length) throw new Error('"' + file.name + '" contains no worksheets.');
    return sheets;
  }
  O.readXlsx = readXlsx;

  async function readCsv(file) {
    const buf = new Uint8Array(await file.arrayBuffer()); let text;
    try { text = new TextDecoder('utf-8', { fatal: true }).decode(buf); } catch (e) { text = new TextDecoder('windows-1252').decode(buf); }
    text = text.replace(/^\ufeff/, '');
    const first = text.split(/\r?\n/, 5).join('\n'); const cnt = (ch) => (first.match(new RegExp(ch === '|' ? '\\|' : ch, 'g')) || []).length;
    const delim = [',', ';', '\t', '|'].sort((a, b) => cnt(b) - cnt(a))[0];
    const rows = []; let row = [], cell = '', q = false;
    for (let i = 0; i < text.length; i++) {
      const ch = text[i];
      if (q) { if (ch === '"') { if (text[i + 1] === '"') { cell += '"'; i++; } else q = false; } else cell += ch; }
      else if (ch === '"') q = true; else if (ch === delim) { row.push(cell); cell = ''; }
      else if (ch === '\n' || ch === '\r') { if (ch === '\r' && text[i + 1] === '\n') i++; row.push(cell); cell = ''; rows.push(row); row = []; }
      else cell += ch;
    }
    if (cell !== '' || row.length) { row.push(cell); rows.push(row); }
    let maxC = 0; const out = rows.map((r) => { maxC = Math.max(maxC, r.length); return r.map((v) => (v === '' ? undefined : { v, num: /^-?\d+([.,]\d+)?$/.test(v.trim()) })); });
    return [{ name: P.baseName(file.name), rows: out, cols: maxC }];
  }
  O.readCsv = readCsv;

  /* ============================================================
     Spreadsheet -> PDF
     ============================================================ */
  O.sheetsToPdf = async function (sheets, outName, ctx) {
    const L = P.need(); const pdf = await L.PDFDocument.create(); const fs = new P.FontSet(pdf);
    let lost = false;
    const fontOf = async (text, bold) => { const pk = await fs.pick({ bold }, text); if (pk.lost) lost = true; return pk; };
    const reg = await fs.std({}), bold = await fs.std({ bold: true });
    let totalPages = 0;
    for (const sh of sheets) {
      const nrows = sh.rows.length, ncols = sh.cols;
      if (!nrows || !ncols) { ctx.warn('Sheet "' + sh.name + '" is empty and was skipped.'); continue; }
      // column widths at 9pt
      const size0 = 9, pad = 3; const widths = new Array(ncols).fill(0);
      const sample = Math.min(nrows, 3000);
      for (let r = 0; r < sample; r++) { const row = sh.rows[r]; if (!row) continue; for (let c = 0; c < ncols; c++) { const cell = row[c]; if (!cell) continue; const t = cell.v; const w = Math.min(...[reg.widthOfTextAtSize(t.replace(/[^\u0020-\u00ff\u20ac\u2018-\u201e\u2022\u2026]/g, '?').split(/\r?\n/).reduce((a, b) => (b.length > a.length ? b : a), ''), size0), 1e6]); widths[c] = Math.max(widths[c], w); } }
      let colW = widths.map((w) => Math.min(Math.max(w + pad * 2, 24), 220));
      const total = colW.reduce((a, b) => a + b, 0);
      const landscape = total > 520;
      const PW = landscape ? 841.89 : 595.28, PH = landscape ? 595.28 : 841.89, M = 36;
      const availW = PW - 2 * M; let scale = 1;
      if (total > availW) scale = Math.max(0.7, availW / total);
      const size = size0 * scale; colW = colW.map((w) => w * scale);
      // column chunks
      const chunks = []; let cur = [], cw = 0;
      for (let c = 0; c < ncols; c++) { if (cw + colW[c] > availW && cur.length) { chunks.push(cur); cur = []; cw = 0; } cur.push(c); cw += colW[c]; }
      if (cur.length) chunks.push(cur);
      const rowLines = []; // pre-wrap
      for (let r = 0; r < nrows; r++) {
        const row = sh.rows[r]; let maxL = 1; const cellLines = [];
        if (row) for (let c = 0; c < ncols; c++) { const cell = row[c]; if (!cell) continue; const pk = await fontOf(cell.v, false); const lines = wrapText(pk.font, size, pk.text, colW[c] - pad * 2).slice(0, 8); cellLines[c] = { lines, font: pk.font, num: cell.num }; maxL = Math.max(maxL, lines.length); }
        rowLines.push({ cellLines, h: maxL * size * 1.25 + 4 });
        if (r % 500 === 499) await P.tick();
      }
      let chunkNo = 0;
      for (const chunk of chunks) {
        chunkNo++; let page = null, y = 0, rowsOnPage = 0; const x0 = M;
        const header = () => { page = pdf.addPage([PW, PH]); totalPages++; y = PH - M; page.drawText(sh.name + (chunks.length > 1 ? '  (columns ' + colName(chunk[0]) + '-' + colName(chunk[chunk.length - 1]) + ')' : ''), { x: M, y: y - 8, size: 8, font: bold, color: L.rgb(0.4, 0.4, 0.45) }); y -= 18; rowsOnPage = 0; };
        header();
        for (let r = 0; r < nrows; r++) {
          const rl = rowLines[r]; if (y - rl.h < M) header();
          let x = x0;
          for (const c of chunk) {
            page.drawRectangle({ x, y: y - rl.h, width: colW[c], height: rl.h, borderColor: L.rgb(0.78, 0.8, 0.85), borderWidth: 0.4 });
            const cl = rl.cellLines[c];
            if (cl) cl.lines.forEach((ln, i) => { if (!ln) return; const tw = cl.font.widthOfTextAtSize(ln, size); const tx = cl.num ? x + colW[c] - pad - tw : x + pad; page.drawText(ln, { x: tx, y: y - 2 - size * 0.95 - i * size * 1.25, size, font: cl.font, color: L.rgb(0.1, 0.1, 0.15) }); });
            x += colW[c];
          }
          y -= rl.h; rowsOnPage++;
          if (totalPages > 2000) throw new Error('This spreadsheet is too large to convert in the browser (more than 2000 pages).');
        }
        ctx.progress(0.5, 'Sheet "' + sh.name + '"'); await P.tick();
      }
    }
    if (!pdf.getPageCount()) throw new Error('The spreadsheet has no data to convert.');
    if (lost) P.warnLost(ctx);
    return P.savePdf(pdf, outName);
  };

  /* ============================================================
     Writers: DOCX and XLSX
     ============================================================ */
  const CT_HEAD = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
  O.buildDocx = async function (pages) {
    const Z = needZip(); const zip = new Z();
    let body = ''; const rels = []; const media = []; let imgN = 0;
    const first = pages[0] || { w: 595, h: 842 };
    pages.forEach((pg, pi) => {
      for (const p of pg.paras) {
        const sz = Math.max(8, Math.min(72, Math.round(p.size * 2)));
        const style = p.heading ? '<w:pStyle w:val="Heading' + p.heading + '"/>' : '';
        const jc = p.align ? '<w:jc w:val="' + p.align + '"/>' : '';
        body += '<w:p><w:pPr>' + style + '<w:spacing w:after="' + (p.heading ? 120 : 100) + '"/>' + jc + '</w:pPr>' + '<w:r><w:rPr>' + (p.bold ? '<w:b/>' : '') + (p.italic ? '<w:i/>' : '') + '<w:sz w:val="' + sz + '"/></w:rPr><w:t xml:space="preserve">' + esc(p.text) + '</w:t></w:r></w:p>';
      }
      for (const im of pg.images || []) {
        imgN++; const rid = 'rIdImg' + imgN; media.push({ name: 'image' + imgN + '.jpg', bytes: im.bytes }); rels.push('<Relationship Id="' + rid + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/image' + imgN + '.jpg"/>');
        const maxW = 6.3 * 914400; const cx = Math.round(Math.min(maxW, im.w * 12700)); const cy = Math.round(cx * im.h / im.w);
        body += '<w:p><w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="' + cx + '" cy="' + cy + '"/><wp:docPr id="' + imgN + '" name="Page ' + (pi + 1) + '"/><a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:nvPicPr><pic:cNvPr id="' + imgN + '" name="image' + imgN + '.jpg"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip r:embed="' + rid + '"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="' + cx + '" cy="' + cy + '"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>';
      }
      if (pi < pages.length - 1) body += '<w:p><w:r><w:br w:type="page"/></w:r></w:p>';
    });
    const W = Math.round(first.w * 20), H = Math.round(first.h * 20);
    zip.file('[Content_Types].xml', CT_HEAD + '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Default Extension="jpg" ContentType="image/jpeg"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/></Types>');
    zip.file('_rels/.rels', CT_HEAD + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>');
    zip.file('word/_rels/document.xml.rels', CT_HEAD + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rIdStyles" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>' + rels.join('') + '</Relationships>');
    zip.file('word/styles.xml', CT_HEAD + '<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Calibri" w:hAnsi="Calibri" w:cs="Calibri" w:eastAsia="Calibri"/><w:sz w:val="22"/></w:rPr></w:rPrDefault></w:docDefaults><w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/></w:style><w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="heading 1"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:pPr><w:keepNext/><w:outlineLvl w:val="0"/></w:pPr><w:rPr><w:b/></w:rPr></w:style><w:style w:type="paragraph" w:styleId="Heading2"><w:name w:val="heading 2"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:pPr><w:keepNext/><w:outlineLvl w:val="1"/></w:pPr><w:rPr><w:b/></w:rPr></w:style><w:style w:type="paragraph" w:styleId="Heading3"><w:name w:val="heading 3"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:pPr><w:keepNext/><w:outlineLvl w:val="2"/></w:pPr><w:rPr><w:b/></w:rPr></w:style></w:styles>');
    zip.file('word/document.xml', CT_HEAD + '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"><w:body>' + body + '<w:sectPr><w:pgSz w:w="' + W + '" w:h="' + H + '"/><w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134" w:header="708" w:footer="708" w:gutter="0"/></w:sectPr></w:body></w:document>');
    media.forEach((m) => zip.file('word/media/' + m.name, m.bytes));
    return zip.generateAsync({ type: 'blob', mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', compression: 'DEFLATE' });
  };

  O.buildXlsx = async function (sheets) {
    const Z = needZip(); const zip = new Z(); const used = new Set();
    const cleanName = (n, i) => { let s = String(n).replace(/[\[\]:*?\/\\]/g, ' ').trim().slice(0, 31) || ('Sheet' + (i + 1)); let b = s, k = 2; while (used.has(s.toLowerCase())) { s = b.slice(0, 28) + ' ' + k++; } used.add(s.toLowerCase()); return s; };
    const names = sheets.map((s, i) => cleanName(s.name, i));
    zip.file('[Content_Types].xml', CT_HEAD + '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>' + sheets.map((_, i) => '<Override PartName="/xl/worksheets/sheet' + (i + 1) + '.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>').join('') + '</Types>');
    zip.file('_rels/.rels', CT_HEAD + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>');
    zip.file('xl/workbook.xml', CT_HEAD + '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>' + names.map((n, i) => '<sheet name="' + esc(n) + '" sheetId="' + (i + 1) + '" r:id="rId' + (i + 1) + '"/>').join('') + '</sheets></workbook>');
    zip.file('xl/_rels/workbook.xml.rels', CT_HEAD + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' + sheets.map((_, i) => '<Relationship Id="rId' + (i + 1) + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet' + (i + 1) + '.xml"/>').join('') + '<Relationship Id="rId' + (sheets.length + 1) + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>');
    zip.file('xl/styles.xml', CT_HEAD + '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts><fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/></cellXfs></styleSheet>');
    sheets.forEach((sh, i) => {
      let xml = CT_HEAD + '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">';
      const widths = []; sh.rows.forEach((row) => row && row.forEach((c, ci) => { if (c != null) widths[ci] = Math.max(widths[ci] || 8, Math.min(60, String(c.v).length + 2)); }));
      if (widths.length) xml += '<cols>' + widths.map((w, ci) => w ? '<col min="' + (ci + 1) + '" max="' + (ci + 1) + '" width="' + w + '" customWidth="1"/>' : '').join('') + '</cols>';
      xml += '<sheetData>';
      sh.rows.forEach((row, ri) => {
        if (!row) return; let cells = '';
        row.forEach((c, ci) => {
          if (c == null || c.v === '' || c.v == null) return; const ref = colName(ci) + (ri + 1);
          if (typeof c.v === 'number') cells += '<c r="' + ref + '"><v>' + c.v + '</v></c>';
          else cells += '<c r="' + ref + '" t="inlineStr"' + (c.bold ? ' s="1"' : '') + '><is><t xml:space="preserve">' + esc(c.v) + '</t></is></c>';
        });
        if (cells) xml += '<row r="' + (ri + 1) + '">' + cells + '</row>';
      });
      xml += '</sheetData></worksheet>'; zip.file('xl/worksheets/sheet' + (i + 1) + '.xml', xml);
    });
    return zip.generateAsync({ type: 'blob', mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', compression: 'DEFLATE' });
  };

  /* ============================================================
     PDF text extraction with layout (for PDF -> Word / Excel)
     ============================================================ */
  O.extractLines = async function (pdf, pageNum) {
    const page = await pdf.getPage(pageNum); const vp = page.getViewport({ scale: 1 });
    const tc = await page.getTextContent();
    const items = tc.items.filter((it) => it.str !== undefined && (it.str.trim() !== '' || it.width > 0)).map((it) => {
      const [a, b, , d, e, f] = it.transform; const size = Math.hypot(a, b) || Math.abs(d) || 10;
      return { s: it.str, x: e, y: f, w: it.width, size, h: it.height };
    });
    items.sort((p, q) => (Math.abs(q.y - p.y) > Math.min(p.size, q.size) * 0.5 ? q.y - p.y : p.x - q.x));
    const lines = [];
    for (const it of items) {
      const ln = lines[lines.length - 1];
      if (ln && Math.abs(ln.y - it.y) <= Math.max(2, Math.min(ln.size, it.size) * 0.5)) { ln.items.push(it); ln.size = Math.max(ln.size, it.size); }
      else lines.push({ y: it.y, size: it.size, items: [it] });
    }
    for (const ln of lines) ln.items.sort((p, q) => p.x - q.x);
    return { lines, width: vp.width, height: vp.height };
  };
  /* join the items of a line into text */
  O.lineText = (ln) => { let t = '', last = null; for (const it of ln.items) { if (last) { const gap = it.x - (last.x + last.w); if (gap > ln.size * 0.15 && !/\s$/.test(t) && !/^\s/.test(it.s)) t += ' '; } t += it.s; last = it; } return t.replace(/\s+$/, ''); };
  /* split a line into table cells where there are wide gaps */
  O.lineCells = (ln) => {
    const cells = []; let cur = null, last = null;
    for (const it of ln.items) {
      if (!it.s.trim()) continue; // whitespace items: the gap is measured from the last real text
      if (cur && last && it.x - (last.x + last.w) <= ln.size * 0.9) { const gap = it.x - (last.x + last.w); cur.text += (gap > ln.size * 0.15 && !/\s$/.test(cur.text) ? ' ' : '') + it.s; cur.end = it.x + it.w; }
      else { cur = { x: it.x, end: it.x + it.w, text: it.s }; cells.push(cur); }
      last = it;
    }
    return cells;
  };
})(typeof window !== 'undefined' ? window : globalThis);
