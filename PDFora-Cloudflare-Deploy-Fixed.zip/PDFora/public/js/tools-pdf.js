/* PDFora tool definitions: PDF tools. Each tool = { slug, name, ... run(files, ctx) -> [{name, blob, info}] } */
(function (g) {
  'use strict';
  const P = (g.PDFora = g.PDFora || {});
  const T = (P.T = P.T || {});
  const ACC = { pdf: '.pdf,application/pdf' };
  const row = (label, inner, hint) => '<div class="opt"><label>' + label + '</label>' + inner + (hint ? '<small class="opt-hint">' + hint + '</small>' : '') + '</div>';
  const plural = (n, w) => n + ' ' + w + (n === 1 ? '' : 's');
  const pad = (n, w) => String(n).padStart(w || 3, '0');
  P.row = row; P.plural = plural;

  /* run fn for each file; failures are collected so the rest still process */
  async function perFile(files, ctx, fn) {
    const outs = [];
    for (let i = 0; i < files.length; i++) {
      ctx.progress(i / files.length, files.length > 1 ? 'File ' + (i + 1) + ' of ' + files.length : 'Processing');
      try { const r = await fn(files[i], i); if (r) outs.push(...[].concat(r)); }
      catch (e) { console.warn(e); ctx.fail(files[i].name, e && e.message ? e.message : String(e)); }
      await P.tick();
    }
    ctx.progress(1, 'Finished');
    return outs;
  }
  P.perFile = perFile;
  const pdfTool = (o) => Object.assign({ kinds: ['pdf'], acceptText: 'PDF files', accept: ACC.pdf, multi: true, min: 1 }, o);

  /* ---------------- 1. Merge PDF (original logic preserved) ---------------- */
  T.merge = pdfTool({
    slug: 'merge-pdf', name: 'Merge PDF', icon: '\u25a4', desc: 'Combine multiple PDF files into one document.', kw: 'combine join concatenate pdf',
    min: 2, ordered: true, zipName: 'PDFora-merged', hint: 'Upload unlimited PDF files, max 100MB each. Use the arrows to change the order.',
    btn: (n) => 'Merge ' + n + (n === 1 ? ' File' : ' Files'),
    async run(files, ctx) {
      if (files.length < 2) throw Error('Choose at least two PDF files.');
      const L = P.need();
      let out = await L.PDFDocument.create();
      for (let k = 0; k < files.length; k++) {
        const f = files[k]; ctx.progress(k / files.length, 'Merging ' + (k + 1) + ' of ' + files.length);
        let src = await P.loadPdf(f), pages = await out.copyPages(src, src.getPageIndices());
        pages.forEach((p) => out.addPage(p));
        await P.tick();
      }
      const res = await P.savePdf(out, 'PDFora-merged.pdf');
      res.info = plural(out.getPageCount(), 'page') + ' from ' + files.length + ' PDF files, in the order shown';
      return [res];
    }
  });

  /* ---------------- 2. Split PDF ---------------- */
  T.split = pdfTool({
    slug: 'split-pdf', name: 'Split PDF', icon: '\u2702', desc: 'Extract selected pages into a new PDF, or split every page into its own file.', kw: 'extract pages separate cut',
    zipName: 'PDFora-split', hint: 'Upload PDF files, max 100MB each',
    btn: (n) => 'Split ' + n + (n === 1 ? ' File' : ' Files'),
    options: () => row('What do you want to do?', '<select id="mode"><option value="extract">Extract the pages I choose into one PDF</option><option value="single">Split every page into its own PDF</option></select>') +
      '<div id="pagesRow">' + row('Pages to extract', '<input id="pages" type="text" inputmode="text" autocomplete="off" placeholder="1-3,5">', 'Examples: <b>1-3</b> (3 pages) \u00b7 <b>1-3,5</b> (4 pages) \u00b7 <b>2,4,6</b> (3 pages) \u00b7 <b>5-</b> (page 5 to the end)') + '</div>',
    mount(app) { const m = app.q('#mode'); m.addEventListener('change', () => { app.q('#pagesRow').style.display = m.value === 'extract' ? '' : 'none'; }); },
    async run(files, ctx) {
      const L = P.need(); const mode = ctx.val('mode'); const range = ctx.val('pages');
      if (mode === 'extract' && !range.trim()) throw new Error('Please enter the pages to extract, for example 1-3,5.');
      return perFile(files, ctx, async (f) => {
        const doc = await P.loadPdf(f); const n = doc.getPageCount(); const base = P.baseName(f.name);
        if (mode === 'single') {
          const outs = [];
          for (let i = 0; i < n; i++) { const out = await L.PDFDocument.create(); const [pg] = await out.copyPages(doc, [i]); out.addPage(pg); outs.push(await P.savePdf(out, base + '-page-' + pad(i + 1, String(n).length) + '.pdf')); if (i % 5 === 4) await P.tick(); }
          return outs;
        }
        const idx = P.parseRanges(range, n);
        const out = await L.PDFDocument.create(); const pages = await out.copyPages(doc, idx); pages.forEach((p) => out.addPage(p));
        if (out.getPageCount() !== idx.length) throw new Error('Internal error: expected ' + idx.length + ' pages but produced ' + out.getPageCount() + '.');
        const res = await P.savePdf(out, base + '-split.pdf');
        res.info = plural(idx.length, 'page') + ' extracted';
        return res;
      });
    }
  });

  /* ---------------- 3. Compress PDF ---------------- */
  async function recompressImages(doc, o, ctx) {
    const L = P.need(); const pctx = doc.context; const N = (s) => L.PDFName.of(s); let replaced = 0, seen = 0;
    const entries = [...pctx.enumerateIndirectObjects()];
    for (let k = 0; k < entries.length; k++) {
      const [ref, obj] = entries[k];
      if (!(obj instanceof L.PDFRawStream)) continue; const d = obj.dict;
      if (d.lookup(N('Subtype')) !== N('Image')) continue;
      if (d.lookup(N('ImageMask')) === L.PDFBool.True || d.has(N('Mask')) || d.has(N('Decode'))) continue;
      const num = (key) => { const v = d.lookup(N(key)); return v && v.asNumber ? v.asNumber() : 0; };
      const w = num('Width'), hgt = num('Height'), bpc = num('BitsPerComponent');
      if (bpc !== 8 || w * hgt < 40000) continue;
      seen++;
      const f = d.lookup(N('Filter')); const fnames = !f ? [] : f instanceof L.PDFName ? [f.asString()] : f instanceof L.PDFArray ? f.asArray().map((x) => (x && x.asString ? x.asString() : '')) : [''];
      let names = fnames.slice(), raw = obj.contents, parmIdx = 0;
      if (names[0] === '/ASCII85Decode') { raw = P.a85decode(raw); names.shift(); parmIdx = 1; }
      if (names.length !== 1) continue;
      let cs = d.lookup(N('ColorSpace')), nc = 0;
      if (cs instanceof L.PDFName) nc = { '/DeviceRGB': 3, '/DeviceGray': 1 }[cs.asString()] || 0;
      else if (cs instanceof L.PDFArray) {
        const first = cs.lookup(0); const fn = first && first.asString ? first.asString() : '';
        if (fn === '/ICCBased') { const st = cs.lookup(1); const nn = st && st.dict ? st.dict.lookup(N('N')) : null; nc = nn && nn.asNumber ? nn.asNumber() : 0; if (nc !== 1 && nc !== 3) nc = 0; }
        else if (fn === '/CalRGB') nc = 3; else if (fn === '/CalGray') nc = 1;
      }
      if (!nc) continue;
      let canvas;
      try {
        const maxSide = Math.max(w, hgt); const sc = Math.min(1, o.maxDim / maxSide); const nw = Math.max(1, Math.round(w * sc)), nh = Math.max(1, Math.round(hgt * sc));
        if (names[0] === '/DCTDecode') {
          const im = await P.loadImage(Object.assign(new Blob([raw], { type: 'image/jpeg' }), { name: 'embedded' }));
          canvas = P.drawToCanvas(im, nw, nh, { fill: '#fff' }); im.close();
        } else if (names[0] === '/FlateDecode') {
          let data = await P.Sec.inflate(raw);
          let dp = d.lookup(N('DecodeParms')); if (dp instanceof L.PDFArray) dp = dp.lookup(parmIdx); const parms = dp instanceof L.PDFDict ? { get: (k) => { const v = dp.lookup(N(k)); return v && v.asNumber ? v.asNumber() : undefined; } } : null;
          data = P.Sec.unpredict(data, parms);
          if (data.length < w * hgt * nc) continue;
          const src = P.makeCanvas(w, hgt); const sctx = src.getContext('2d'); const idt = sctx.createImageData(w, hgt); const px = idt.data;
          if (nc === 3) for (let i = 0, j = 0; i < w * hgt; i++, j += 4) { px[j] = data[i * 3]; px[j + 1] = data[i * 3 + 1]; px[j + 2] = data[i * 3 + 2]; px[j + 3] = 255; }
          else for (let i = 0, j = 0; i < w * hgt; i++, j += 4) { px[j] = px[j + 1] = px[j + 2] = data[i]; px[j + 3] = 255; }
          sctx.putImageData(idt, 0, 0);
          if (nw === w) canvas = src; else { canvas = P.makeCanvas(nw, nh); const c2 = canvas.getContext('2d'); c2.imageSmoothingQuality = 'high'; c2.drawImage(src, 0, 0, nw, nh); }
        } else continue;
        const blob = await P.canvasBlob(canvas, 'image/jpeg', o.quality); if (!blob) continue;
        const bytes = new Uint8Array(await blob.arrayBuffer());
        if (bytes.length < obj.contents.length * 0.85) {
          const ns = pctx.stream(bytes, { Type: 'XObject', Subtype: 'Image', Width: canvas.width, Height: canvas.height, ColorSpace: nc === 1 ? 'DeviceGray' : 'DeviceRGB', BitsPerComponent: 8, Filter: 'DCTDecode' });
          if (d.has(N('SMask'))) ns.dict.set(N('SMask'), d.get(N('SMask')));
          pctx.assign(ref, ns); replaced++;
        }
      } catch (e) { console.warn('image skipped', e); }
      if (k % 4 === 0) { ctx.progress(0.1 + 0.8 * k / entries.length, 'Optimizing images'); await P.tick(); }
    }
    return { replaced, seen };
  }
  T.compress = pdfTool({
    slug: 'compress-pdf', name: 'Compress PDF', icon: '\u21e9', desc: 'Reduce PDF file size by optimizing the images inside your PDF.', kw: 'reduce size smaller optimize shrink',
    zipName: 'PDFora-compressed', btn: (n) => 'Compress ' + n + (n === 1 ? ' File' : ' Files'),
    options: () => row('Compression level', '<select id="level"><option value="rec">Recommended \u2013 smaller images, text stays sharp</option><option value="low">Light \u2013 best quality</option><option value="strong">Strong \u2013 smallest file (pages become images, text not selectable)</option></select>', 'Strong is best for scanned documents. Recommended keeps text and links.'),
    async run(files, ctx) {
      const level = ctx.val('level'); const L = P.need();
      return perFile(files, ctx, async (f) => {
        const orig = await P.readBytes(f); const base = P.baseName(f.name); let outBytes, mode;
        if (level === 'strong') {
          const pdf = await P.openPdfjs(f); const out = await L.PDFDocument.create();
          for (let n = 1; n <= pdf.numPages; n++) {
            const c = await P.renderPage(pdf, n, 1.4); const vp1 = (await pdf.getPage(n)).getViewport({ scale: 1 });
            const blob = await P.canvasBlob(c, 'image/jpeg', 0.55); const img = await out.embedJpg(new Uint8Array(await blob.arrayBuffer()));
            out.addPage([vp1.width, vp1.height]).drawImage(img, { x: 0, y: 0, width: vp1.width, height: vp1.height });
            ctx.progress(n / pdf.numPages, 'Page ' + n + ' of ' + pdf.numPages); await P.tick();
          }
          outBytes = await out.save(); mode = 'strong';
        } else {
          const doc = await P.loadPdf(f);
          const r = await recompressImages(doc, level === 'low' ? { quality: 0.82, maxDim: 3200 } : { quality: 0.68, maxDim: 2000 }, ctx);
          doc.setProducer('PDFora'); outBytes = await doc.save({ useObjectStreams: true }); mode = r.seen ? 'images' : 'noimages';
        }
        let info, blob;
        if (outBytes.length < orig.length * 0.98) { blob = new Blob([outBytes], { type: 'application/pdf' }); info = P.fmtSize(orig.length) + ' \u2192 ' + P.fmtSize(outBytes.length) + ' (\u2212' + Math.round(100 - 100 * outBytes.length / orig.length) + '%)'; }
        else {
          blob = new Blob([orig], { type: 'application/pdf' });
          info = 'Could not reduce this file (' + P.fmtSize(orig.length) + ') - it is already well optimized';
          ctx.warn(mode === 'noimages' ? '"' + f.name + '" has no large images to compress (it is mostly text/vector content, which is already compact). The original file is provided unchanged.' : '"' + f.name + '" is already well optimized. The original file is provided unchanged. Try the Strong level for scanned documents.');
        }
        return { name: base + '-compressed.pdf', blob, info };
      });
    }
  });

  /* ---------------- 4. PDF to Word ---------------- */
  T.pdf2word = pdfTool({
    slug: 'pdf-to-word', name: 'PDF to Word', icon: 'W', desc: 'Convert a PDF into an editable Word (.docx) document.', kw: 'docx doc word convert editable',
    zipName: 'PDFora-word', btn: (n) => 'Convert ' + n + (n === 1 ? ' File' : ' Files') + ' to Word',
    hint: 'Works best on PDFs with real text. Scanned pages are inserted as images (no OCR in the browser).',
    async run(files, ctx) {
      return perFile(files, ctx, async (f) => {
        const pdf = await P.openPdfjs(f); const pages = []; let textPages = 0;
        for (let n = 1; n <= pdf.numPages; n++) {
          const ex = await P.Office.extractLines(pdf, n); const lines = ex.lines;
          const sizes = {}; lines.forEach((l) => { const k = Math.round(l.size); sizes[k] = (sizes[k] || 0) + P.Office.lineText(l).length; });
          const body = +(Object.keys(sizes).sort((a, b) => sizes[b] - sizes[a])[0] || 11);
          const paras = []; let prev = null, maxRight = 0;
          lines.forEach((l) => { const last = l.items[l.items.length - 1]; maxRight = Math.max(maxRight, last.x + last.w); });
          for (const l of lines) {
            const text = P.Office.lineText(l); if (!text.trim()) continue;
            const first = l.items[0], last = l.items[l.items.length - 1];
            const ratio = l.size / body; const heading = ratio >= 1.2 && text.length < 140 ? (ratio >= 1.6 ? 1 : ratio >= 1.35 ? 2 : 3) : 0;
            const center = Math.abs((first.x + last.x + last.w) / 2 - ex.width / 2) < 14 && first.x > ex.width * 0.15;
            const gap = prev ? prev.y - l.y : 0;
            const smallGap = prev && !heading && !prev.heading && gap < prev.size * 1.55 && Math.abs(prev.size - l.size) < 1.5;
            const bullet = /^([\u2022\-\u2013*]|\d+[.)])\s/.test(text);
            const sameBlock = smallGap && prev.right > maxRight * 0.88 && !bullet;
            if (sameBlock) { prev.text += ' ' + text; prev.right = last.x + last.w; prev.y = l.y; paras[paras.length - 1].text = prev.text; }
            else { const p = { text, size: heading ? l.size : Math.min(l.size, body * 1.1), heading, align: center ? 'center' : '', bold: !!heading, y: l.y, right: last.x + last.w }; paras.push(p); prev = p; }
          }
          const pg = { w: ex.width, h: ex.height, paras: paras.map((p) => ({ text: p.text, size: p.size, heading: p.heading, align: p.align, bold: p.bold })), images: [] };
          if (paras.length) textPages++;
          else { const c = await P.renderPage(pdf, n, 1.5); const blob = await P.canvasBlob(c, 'image/jpeg', 0.85); pg.images.push({ bytes: new Uint8Array(await blob.arrayBuffer()), w: ex.width, h: ex.height }); }
          pages.push(pg); ctx.progress(n / pdf.numPages, 'Page ' + n + ' of ' + pdf.numPages); await P.tick();
        }
        if (!textPages) ctx.warn('"' + f.name + '" looks like a scanned PDF (no selectable text). Each page was placed in the Word file as an image - the text cannot be edited without OCR.');
        else if (textPages < pdf.numPages) ctx.warn('Some pages of "' + f.name + '" have no selectable text and were inserted as images.');
        ctx.warn('Tables, columns and complex formatting are converted to plain text paragraphs; check the result in Word.');
        const blob = await P.Office.buildDocx(pages);
        return { name: P.baseName(f.name) + '.docx', blob, info: plural(pdf.numPages, 'page') + ' converted' };
      });
    }
  });

  /* ---------------- 5. Word to PDF ---------------- */
  T.word2pdf = {
    slug: 'word-to-pdf', name: 'Word to PDF', icon: '\u25a3', desc: 'Convert a Word (.docx) document into a PDF file.', kw: 'docx doc word convert',
    kinds: ['zip'], exts: ['docx', 'docm'], acceptText: 'Word documents (.docx)', accept: '.docx,.docm,application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    legacyHint: 'Please open it in Word and use Save As \u2192 Word Document (.docx), then try again.',
    multi: true, min: 1, zipName: 'PDFora-pdfs', btn: (n) => 'Convert ' + n + (n === 1 ? ' File' : ' Files') + ' to PDF',
    hint: 'Supports .docx files. Text, headings, lists, tables and images are converted.',
    async run(files, ctx) { return perFile(files, ctx, async (f) => { const res = await P.Office.docxToPdf(f, ctx); res.info = 'PDF created'; return res; }); }
  };

  /* ---------------- 6. PDF to Excel ---------------- */
  T.pdf2excel = pdfTool({
    slug: 'pdf-to-excel', name: 'PDF to Excel', icon: '\u25a6', desc: 'Extract tables and text from a PDF into an Excel (.xlsx) spreadsheet.', kw: 'xlsx xls excel spreadsheet table convert csv',
    zipName: 'PDFora-excel', btn: (n) => 'Convert ' + n + (n === 1 ? ' File' : ' Files') + ' to Excel',
    options: () => row('Sheets', '<select id="sheets"><option value="page">One sheet per PDF page</option><option value="one">All pages on one sheet</option></select>'),
    hint: 'Works on PDFs with real text (tables are detected by column alignment). Scanned PDFs need OCR, which is not available in the browser.',
    async run(files, ctx) {
      const per = ctx.val('sheets') === 'page';
      return perFile(files, ctx, async (f) => {
        const pdf = await P.openPdfjs(f); const sheets = []; let one = { name: P.baseName(f.name).slice(0, 28) || 'Sheet1', rows: [] }; let any = false;
        for (let n = 1; n <= pdf.numPages; n++) {
          const ex = await P.Office.extractLines(pdf, n); const rowsCells = ex.lines.map((l) => P.Office.lineCells(l)).filter((c) => c.length);
          // column detection: merge the horizontal extents of cells found on multi-cell (table-like) rows
          const ivs = rowsCells.filter((c) => c.length >= 2).flatMap((c) => c.map((x) => [x.x, x.end])).sort((p, q) => p[0] - q[0]); const cols = [];
          ivs.forEach((iv) => { const lc = cols[cols.length - 1]; if (lc && iv[0] <= lc.x1 + 3) lc.x1 = Math.max(lc.x1, iv[1]); else cols.push({ x0: iv[0], x1: iv[1] }); });
          const colOf = (c) => { if (!cols.length) return 0; const mid = (c.x + c.end) / 2; let best = 0, bd = 1e9; cols.forEach((k, i) => { const d = mid >= k.x0 - 3 && mid <= k.x1 + 3 ? 0 : Math.min(Math.abs(mid - k.x0), Math.abs(mid - k.x1)); if (d < bd) { bd = d; best = i; } }); return best; };
          const rows = rowsCells.map((cells) => { const r = []; cells.forEach((c) => { const ci = cells.length === 1 ? 0 : colOf(c); const t = c.text.trim(); const m = /^\(?-?\$?\s?[\d,]+(\.\d+)?\)?%?$/.test(t) && !/^0\d/.test(t.replace(/^[($-]+/, '')) ? parseFloat(t.replace(/[^0-9.\-]/g, '')) : null; const neg = /^\(.*\)$/.test(t); r[ci] = (r[ci] ? { v: r[ci].v + ' ' + t } : { v: (m != null && !isNaN(m) && !/%$/.test(t) && t.length < 16) ? (neg ? -Math.abs(m) : m) : t }); }); return r; });
          if (rows.length) any = true;
          if (per) sheets.push({ name: 'Page ' + n, rows: rows.length ? rows : [[{ v: '(no text on this page)' }]] }); else { if (one.rows.length) one.rows.push(null); one.rows.push(...rows); }
          ctx.progress(n / pdf.numPages, 'Page ' + n + ' of ' + pdf.numPages); await P.tick();
        }
        if (!any) throw new Error('No selectable text found. This looks like a scanned PDF; OCR is needed to extract its text.');
        const blob = await P.Office.buildXlsx(per ? sheets : [one]);
        return { name: P.baseName(f.name) + '.xlsx', blob, info: per ? plural(sheets.length, 'sheet') : 'One sheet' };
      });
    }
  });

  /* ---------------- 7. Excel to PDF ---------------- */
  T.excel2pdf = {
    slug: 'excel-to-pdf', name: 'Excel to PDF', icon: '\u25a4', desc: 'Convert an Excel (.xlsx) or CSV spreadsheet into a PDF.', kw: 'xlsx xls csv spreadsheet convert table',
    kinds: ['zip', 'text'], exts: ['xlsx', 'xlsm', 'csv'], acceptText: 'Excel (.xlsx) or CSV files', accept: '.xlsx,.xlsm,.csv,text/csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    legacyHint: 'Please open it in Excel and use Save As \u2192 Excel Workbook (.xlsx), then try again.',
    multi: true, min: 1, zipName: 'PDFora-pdfs', btn: (n) => 'Convert ' + n + (n === 1 ? ' File' : ' Files') + ' to PDF',
    hint: 'Every worksheet is converted. Wide sheets are scaled or split across pages.',
    async run(files, ctx) {
      return perFile(files, ctx, async (f) => {
        const ext = P.extOf(f.name); const sheets = ext === 'csv' ? await P.Office.readCsv(f) : await P.Office.readXlsx(f);
        const res = await P.Office.sheetsToPdf(sheets, P.baseName(f.name) + '.pdf', ctx); res.info = plural(sheets.length, 'sheet'); return res;
      });
    }
  };

  /* ---------------- 8. PDF to JPG ---------------- */
  T.pdf2jpg = pdfTool({
    slug: 'pdf-to-jpg', name: 'PDF to JPG', icon: '\u25a7', desc: 'Convert every page of a PDF into a JPG image.', kw: 'image picture jpeg convert pages',
    zipName: 'PDFora-images', btn: (n) => 'Convert ' + n + (n === 1 ? ' File' : ' Files') + ' to JPG',
    options: () => row('Image quality', '<select id="dpi"><option value="1">Standard (72 DPI)</option><option value="2" selected>High (150 DPI)</option><option value="3">Very high (220 DPI)</option></select>') + row('Pages', '<input id="pages" type="text" value="all" placeholder="all or 1-3,5">', 'Use <b>all</b> or a range such as 1-3,5'),
    async run(files, ctx) {
      const scale = { 1: 1, 2: 150 / 72, 3: 220 / 72 }[ctx.val('dpi')] || 2; const range = ctx.val('pages') || 'all';
      return perFile(files, ctx, async (f, fi) => {
        const pdf = await P.openPdfjs(f); const idx = P.parseRanges(range, pdf.numPages); const base = P.baseName(f.name); const outs = [];
        for (let k = 0; k < idx.length; k++) {
          const c = await P.renderPage(pdf, idx[k] + 1, scale);
          const blob = await P.canvasBlob(c, 'image/jpeg', 0.92); if (!blob) throw new Error('Your browser could not create the JPG image.');
          outs.push({ name: base + '-page-' + pad(idx[k] + 1, String(pdf.numPages).length) + '.jpg', blob, info: c.width + ' \u00d7 ' + c.height + ' px' });
          ctx.progress((fi + (k + 1) / idx.length) / files.length, 'Page ' + (k + 1) + ' of ' + idx.length); await P.tick();
        }
        return outs;
      });
    }
  });

  /* ---------------- 10. Rotate PDF ---------------- */
  T.rotate = pdfTool({
    slug: 'rotate-pdf', name: 'Rotate PDF', icon: '\u21bb', desc: 'Rotate all pages, or only the pages you choose.', kw: 'turn flip landscape portrait orientation',
    zipName: 'PDFora-rotated', btn: (n) => 'Rotate ' + n + (n === 1 ? ' File' : ' Files'),
    options: () => row('Rotation', '<select id="degrees"><option value="90">90\u00b0 clockwise</option><option value="180">180\u00b0</option><option value="270">90\u00b0 counter-clockwise</option></select>') + row('Pages to rotate', '<input id="pages" type="text" value="all" placeholder="all or 1-3,5">', 'Use <b>all</b> or a range such as 1-3,5'),
    async run(files, ctx) {
      const L = P.need(); const deg = +ctx.val('degrees'); const range = ctx.val('pages') || 'all';
      return perFile(files, ctx, async (f) => {
        const doc = await P.loadPdf(f); const pages = doc.getPages(); const idx = P.parseRanges(range, pages.length);
        idx.forEach((i) => { const cur = pages[i].getRotation().angle; pages[i].setRotation(L.degrees((((cur + deg) % 360) + 360) % 360)); });
        const res = await P.savePdf(doc, P.baseName(f.name) + '-rotated.pdf'); res.info = plural(idx.length, 'page') + ' rotated'; return res;
      });
    }
  });

  /* ---------------- 11. Protect PDF ---------------- */
  T.protect = pdfTool({
    slug: 'protect-pdf', name: 'Protect PDF', icon: '\ud83d\udd12', desc: 'Add a password to a PDF using strong AES-256 encryption.', kw: 'password encrypt lock secure security',
    zipName: 'PDFora-protected', btn: (n) => 'Protect ' + n + (n === 1 ? ' File' : ' Files'),
    options: () => row('Password to open the PDF', '<input id="pw" type="password" autocomplete="new-password" placeholder="Enter a password">') + row('Confirm password', '<input id="pw2" type="password" autocomplete="new-password" placeholder="Repeat the password">') +
      '<details class="adv"><summary>Advanced: permissions</summary>' + row('Owner password (optional)', '<input id="ownerpw" type="password" autocomplete="new-password" placeholder="Different from the open password">', 'Needed to enforce the restrictions below. Leave empty to use the same password.') +
      '<label class="chk"><input type="checkbox" id="aPrint" checked> Allow printing</label><label class="chk"><input type="checkbox" id="aCopy" checked> Allow copying text</label><label class="chk"><input type="checkbox" id="aEdit" checked> Allow editing</label></details>',
    hint: 'Your password is never sent anywhere. If you forget it, the file cannot be recovered - keep it safe.',
    validate(app) { const a = app.val('pw'), b = app.val('pw2'); if (!a) throw new Error('Please enter a password.'); if (a !== b) throw new Error('The two passwords do not match.'); },
    async run(files, ctx) {
      const pw = ctx.val('pw'), owner = ctx.val('ownerpw');
      const allow = { print: ctx.checked('aPrint'), copy: ctx.checked('aCopy'), modify: ctx.checked('aEdit'), annotate: ctx.checked('aEdit') };
      const outs = await perFile(files, ctx, async (f) => {
        const bytes = await P.readBytes(f);
        if (P.Sec.isEncrypted(bytes)) throw new Error('This PDF is already password-protected. Unlock it first if you want to change the password.');
        const out = await P.Sec.protect(bytes, { userPassword: pw, ownerPassword: owner, allow });
        return { name: P.baseName(f.name) + '-protected.pdf', blob: new Blob([out], { type: 'application/pdf' }), info: 'AES-256 encrypted' };
      });
      if (outs.length && (!allow.print || !allow.copy || !allow.modify) && !owner) ctx.warn('Tip: to enforce the permission limits, set a different owner password under Advanced. With the same password, anyone who can open the file has full rights.');
      return outs;
    }
  });

  /* ---------------- 12. Unlock PDF ---------------- */
  T.unlock = pdfTool({
    slug: 'unlock-pdf', name: 'Unlock PDF', icon: '\ud83d\udd13', desc: 'Remove the password and restrictions from a PDF you have the password for.', kw: 'remove password decrypt open restrictions',
    allowLocked: true, zipName: 'PDFora-unlocked', btn: (n) => 'Unlock ' + n + (n === 1 ? ' File' : ' Files'),
    options: () => row('Password', '<input id="pw" type="password" autocomplete="off" placeholder="Leave empty if the file only has editing/printing restrictions">', 'You must know the password. PDFora cannot recover or guess forgotten passwords.'),
    async run(files, ctx) {
      const pw = ctx.val('pw');
      return perFile(files, ctx, async (f) => {
        const bytes = await P.readBytes(f); let r;
        try { r = await P.Sec.unlock(bytes, pw, (x) => ctx.progress(x, 'Decrypting')); }
        catch (e) {
          if (e.code === 'PASSWORD_REQUIRED') throw new Error('This PDF needs a password to open. Enter it above and try again.');
          if (e.code === 'WRONG_PASSWORD') throw new Error('The password is incorrect.');
          throw new Error(e.message && /secur|crypt|password/i.test(e.message) ? e.message : 'Could not unlock this file (' + (e.message || 'unknown error') + '). It may be damaged - try Repair PDF first.');
        }
        try { await P.loadPdf(new File([r.bytes], f.name)); } catch (e) { throw new Error('The decrypted file could not be verified. The PDF may be damaged - try Repair PDF first.'); }
        if (!r.wasEncrypted) ctx.warn('"' + f.name + '" was not password-protected. A clean copy is provided.');
        return { name: P.baseName(f.name) + '-unlocked.pdf', blob: new Blob([r.bytes], { type: 'application/pdf' }), info: r.wasEncrypted ? 'Password and restrictions removed' : 'Was not protected' };
      });
    }
  });

  /* ---------------- 14. Add page numbers ---------------- */
  T.pagenum = pdfTool({
    slug: 'add-page-numbers', name: 'Add Page Numbers', icon: '\u2116', desc: 'Add page numbers to every page of your PDF.', kw: 'number pagination footer header',
    zipName: 'PDFora-numbered', btn: (n) => 'Add numbers to ' + n + (n === 1 ? ' File' : ' Files'),
    options: () => row('Position', '<select id="pos"><option value="bc">Bottom center</option><option value="br">Bottom right</option><option value="bl">Bottom left</option><option value="tc">Top center</option><option value="tr">Top right</option><option value="tl">Top left</option></select>') +
      row('Format', '<select id="fmt"><option value="n">1, 2, 3</option><option value="p">Page 1, Page 2</option><option value="pof">Page 1 of 10</option><option value="of">1 / 10</option></select>') +
      '<div class="opt-grid">' + row('Start numbering at', '<input id="start" type="number" min="0" value="1">') + row('First page to number', '<input id="from" type="number" min="1" value="1">') + row('Font size', '<input id="size" type="number" min="6" max="48" value="12">') + '</div>',
    async run(files, ctx) {
      const L = P.need(); const pos = ctx.val('pos'), fmt = ctx.val('fmt'); const start = Math.floor(ctx.num('start', 1)), from = Math.max(1, Math.floor(ctx.num('from', 1))), size = Math.min(48, Math.max(6, ctx.num('size', 12)));
      return perFile(files, ctx, async (f) => {
        const doc = await P.loadPdf(f); const fs = new P.FontSet(doc); const pages = doc.getPages(); const n = pages.length;
        if (from > n) throw new Error('"First page to number" is ' + from + ' but this PDF has only ' + n + ' pages.');
        const last = start + (n - from); let lost = false;
        for (let i = from - 1; i < n; i++) {
          const num = start + (i - (from - 1));
          const label = fmt === 'n' ? String(num) : fmt === 'p' ? 'Page ' + num : fmt === 'pof' ? 'Page ' + num + ' of ' + last : num + ' / ' + last;
          const pk = await fs.pick({}, label); if (pk.lost) lost = true; const tw = pk.font.widthOfTextAtSize(pk.text, size);
          const G = P.pageGeom(pages[i]); const m = 28;
          const vx = pos[1] === 'c' ? (G.vw - tw) / 2 : pos[1] === 'r' ? G.vw - m - tw : m; const vy = pos[0] === 'b' ? m : G.vh - m - size * 0.8;
          P.drawTextVisual(pages[i], pk.text, vx, vy, { size, font: pk.font, color: L.rgb(0.15, 0.15, 0.2) });
          if (i % 25 === 0) await P.tick();
        }
        const res = await P.savePdf(doc, P.baseName(f.name) + '-numbered.pdf'); res.info = plural(n - from + 1, 'page') + ' numbered'; return res;
      });
    }
  });

  /* ---------------- 15. Watermark PDF ---------------- */
  T.watermark = pdfTool({
    slug: 'watermark-pdf', name: 'Watermark PDF', icon: '\u25c8', desc: 'Stamp a text watermark on every page (or the pages you choose).', kw: 'stamp text confidential draft overlay',
    zipName: 'PDFora-watermarked', btn: (n) => 'Watermark ' + n + (n === 1 ? ' File' : ' Files'),
    options: () => row('Watermark text', '<input id="wmText" type="text" value="CONFIDENTIAL" maxlength="80">') +
      '<div class="opt-grid">' + row('Font size', '<input id="wmSize" type="number" min="8" max="300" value="64">') + row('Opacity (%)', '<input id="wmOp" type="number" min="5" max="100" value="25">') + row('Angle (\u00b0)', '<input id="wmRot" type="number" min="-180" max="180" value="45">') + row('Color', '<input id="wmColor" type="color" value="#6b7280">') + '</div>' +
      row('Layout', '<select id="wmLayout"><option value="center">One large watermark in the center</option><option value="tile">Repeat across the page</option></select>') + row('Pages', '<input id="pages" type="text" value="all" placeholder="all or 1-3,5">'),
    async run(files, ctx) {
      const L = P.need(); const text = ctx.val('wmText').trim(); if (!text) throw new Error('Please enter the watermark text.');
      let size = ctx.num('wmSize', 64); const op = Math.min(1, Math.max(0.05, ctx.num('wmOp', 25) / 100)); const ang = ctx.num('wmRot', 45); const hex = ctx.val('wmColor') || '#6b7280'; const layout = ctx.val('wmLayout'); const range = ctx.val('pages') || 'all';
      const color = L.rgb(parseInt(hex.slice(1, 3), 16) / 255, parseInt(hex.slice(3, 5), 16) / 255, parseInt(hex.slice(5, 7), 16) / 255);
      const rad = ang * Math.PI / 180, cos = Math.cos(rad), sin = Math.sin(rad);
      return perFile(files, ctx, async (f) => {
        const doc = await P.loadPdf(f); const fs = new P.FontSet(doc); const pages = doc.getPages(); const idx = P.parseRanges(range, pages.length);
        const pk = await fs.pick({ bold: true }, text); if (pk.lost) P.warnLost(ctx);
        for (const i of idx) {
          const G = P.pageGeom(pages[i]); let sz = size; let tw = pk.font.widthOfTextAtSize(pk.text, sz);
          if (layout === 'center') {
            const maxLen = Math.abs(ang % 180) < 1 ? G.vw * 0.9 : Math.min(Math.hypot(G.vw, G.vh) * 0.8, Math.max(G.vw, G.vh) * 0.95);
            if (tw > maxLen) { sz *= maxLen / tw; tw = pk.font.widthOfTextAtSize(pk.text, sz); }
            const cx = G.vw / 2, cy = G.vh / 2, hh = sz * 0.35;
            P.drawTextVisual(pages[i], pk.text, cx - (tw / 2) * cos + hh * sin, cy - (tw / 2) * sin - hh * cos, { size: sz, font: pk.font, color, opacity: op, angle: ang });
          } else {
            const sx = tw + sz * 2.2, sy = sz * 3.2; let count = 0;
            for (let y = -G.vh * 0.2; y < G.vh * 1.2 && count < 500; y += sy) for (let x = -G.vw * 0.2; x < G.vw * 1.2 && count < 500; x += sx, count++) {
              const cx = x + ((Math.round(y / sy) % 2) ? sx / 2 : 0), cy = y, hh = sz * 0.35;
              P.drawTextVisual(pages[i], pk.text, cx - (tw / 2) * cos + hh * sin, cy - (tw / 2) * sin - hh * cos, { size: sz, font: pk.font, color, opacity: op, angle: ang });
            }
          }
          if (i % 20 === 0) await P.tick();
        }
        const res = await P.savePdf(doc, P.baseName(f.name) + '-watermarked.pdf'); res.info = plural(idx.length, 'page') + ' watermarked'; return res;
      });
    }
  });

  /* ---------------- 17. Repair PDF ---------------- */
  async function verifyPdf(bytes) {
    try {
      const lib = await P.getPdfjs(); const doc = await lib.getDocument({ data: bytes.slice(), isEvalSupported: false }).promise;
      if (!doc.numPages) return null; const c = await P.renderPage(doc, 1, 0.3); if (!c.width) return null;
      let withContent = 0; const lim = Math.min(doc.numPages, 300);
      for (let n = 1; n <= lim; n++) { try { const pg = await doc.getPage(n); const ops = await pg.getOperatorList(); if (ops.fnArray.length > 3) withContent++; } catch (e) { /* blank */ } }
      if (doc.numPages > lim) withContent += doc.numPages - lim;
      return { pages: doc.numPages, withContent };
    } catch (e) { return null; }
  }
  T.repair = pdfTool({
    slug: 'repair-pdf', name: 'Repair PDF', icon: '\u2699', desc: 'Try to recover a damaged or corrupted PDF by rebuilding its structure.', kw: 'fix corrupt broken damaged recover',
    zipName: 'PDFora-repaired', btn: (n) => 'Repair ' + n + (n === 1 ? ' File' : ' Files'), allowLocked: true,
    hint: 'Rebuilds the file structure. Pages that are truly missing from the file cannot be recovered.',
    async run(files, ctx) {
      const L = P.need();
      return perFile(files, ctx, async (f) => {
        const bytes = await P.readBytes(f); const base = P.baseName(f.name);
        if (P.Sec.isEncrypted(bytes)) throw new Error('This PDF is password-protected. Use Unlock PDF first, then repair the unlocked copy.');
        let best = null; const consider = (b, v, how) => { if (v && (!best || v.withContent > best.v.withContent)) best = { b, v, how }; };
        // 1) re-save with pdf-lib (rebuilds the cross-reference table)
        try { const d = await L.PDFDocument.load(bytes, { throwOnInvalidObject: false, updateMetadata: false }); if (d.getPageCount()) { const b = await d.save(); consider(b, await verifyPdf(b), 'Rebuilt the file structure'); } } catch (e) { /* next */ }
        // 2) scan the file for objects and rebuild the document from scratch
        if (!best || best.v.withContent < best.v.pages) { try { const rb = await P.Sec.rebuild(bytes); let b = rb; try { const d = await L.PDFDocument.load(rb, { throwOnInvalidObject: false, updateMetadata: false }); b = await d.save(); } catch (e) { /* keep rb */ } consider(b, await verifyPdf(b), 'Recovered the objects found inside the file and rebuilt the document'); } catch (e) { /* next */ } }
        let out = best && best.v.withContent ? best.b : null, how = best ? best.how : '', pages = best ? best.v.pages : 0, withContent = best ? best.v.withContent : 0;
        // 3) last resort: let the PDF viewer engine read it and re-create pages as images
        if (!out) {
          try {
            const pdf = await P.openPdfjs(f); const doc = await L.PDFDocument.create();
            for (let n = 1; n <= pdf.numPages; n++) { const c = await P.renderPage(pdf, n, 2); const vp = (await pdf.getPage(n)).getViewport({ scale: 1 }); const blob = await P.canvasBlob(c, 'image/jpeg', 0.9); const im = await doc.embedJpg(new Uint8Array(await blob.arrayBuffer())); doc.addPage([vp.width, vp.height]).drawImage(im, { x: 0, y: 0, width: vp.width, height: vp.height }); ctx.progress(n / pdf.numPages, 'Rebuilding page ' + n); await P.tick(); }
            out = await doc.save(); pages = pdf.numPages; withContent = pages; how = 'Re-created the pages as images';
            ctx.warn('"' + f.name + '" was too damaged to repair normally, so its pages were re-created as images. The text is no longer selectable.');
          } catch (e) { /* give up */ }
        }
        if (!out) throw new Error('This file could not be repaired. It may not be a PDF, or the page data is missing.');
        if (withContent < pages) ctx.warn('"' + f.name + '": the file contains ' + plural(pages, 'page') + ', but only ' + withContent + ' could be recovered with content. The other pages are blank because their data is missing from the damaged file.');
        return { name: base + '-repaired.pdf', blob: new Blob([out], { type: 'application/pdf' }), info: how + ' \u00b7 ' + (withContent < pages ? withContent + ' of ' + plural(pages, 'page') + ' recovered' : plural(pages, 'page') + ' recovered') };
      });
    }
  });
})(window);
