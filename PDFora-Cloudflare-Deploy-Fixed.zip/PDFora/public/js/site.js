/* PDFora site shell: header navigation, login state, shared helpers. Used on every page. */
(function (g) {
  'use strict';
  const PF = (g.PFSite = {});
  PF.me = null; PF.config = { google: false, payments: false, freeLimit: 3, proLimit: 300 };
  PF.loaded = false; PF.ready = null;
  PF.el = function (tag, props) {
    const e = document.createElement(tag); props = props || {};
    for (const k in props) { if (props[k] == null) continue; if (k === 'class') e.className = props[k]; else if (k === 'text') e.textContent = props[k]; else if (k.startsWith('on')) e.addEventListener(k.slice(2), props[k]); else e.setAttribute(k, props[k]); }
    for (let i = 2; i < arguments.length; i++) { const c = arguments[i]; if (c != null) e.append(c.nodeType ? c : document.createTextNode(c)); }
    return e;
  };
  PF.post = async function (path, body, opts) {
    const r = await fetch(path, Object.assign({ method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-PDFora': '1' }, body: JSON.stringify(body || {}) }, opts || {}));
    let data = {}; try { data = await r.json(); } catch (e) { /* empty body */ }
    return { status: r.status, ok: r.ok, data };
  };
  PF.date = (sec) => new Date(sec * 1000).toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' });
  PF.untilReset = function (iso) {
    const ms = Math.max(0, new Date(iso).getTime() - Date.now()), h = Math.floor(ms / 3600000), m = Math.floor((ms % 3600000) / 60000);
    return h + 'h ' + m + 'm';
  };
  PF.quotaText = function (me) {
    if (!me || !me.user) return '';
    const u = me.usage; return me.plan === 'pro' ? 'Pro \u00b7 ' + u.remaining + ' of ' + u.limit + ' operations left today' : u.remaining + ' of ' + u.limit + ' free operations left today';
  };
  PF.load = async function () {
    try {
      const [c, m] = await Promise.all([fetch('/api/config', { credentials: 'same-origin' }).then((r) => r.json()), fetch('/api/me', { credentials: 'same-origin' }).then((r) => r.json())]);
      PF.config = c; PF.me = m;
    } catch (e) { PF.me = { user: null }; PF.offline = true; }
    PF.loaded = true; render(); g.dispatchEvent(new CustomEvent('pf:me'));
    return PF.me;
  };
  PF.setUsage = function (usage) { if (PF.me && PF.me.user && usage) { PF.me.usage = usage; render(); g.dispatchEvent(new CustomEvent('pf:me')); } };
  PF.loginUrl = (next) => '/login?next=' + encodeURIComponent(next || (location.pathname + location.search));
  PF.logout = async function () { await PF.post('/auth/logout'); PF.me = { user: null }; location.href = '/'; };

  function render() {
    const box = document.getElementById('authArea'); if (!box) return; box.textContent = '';
    const me = PF.me;
    if (!me || !me.user) { box.append(PF.el('a', { class: 'btn', href: PF.loginUrl(), text: 'Log in' })); return; }
    const low = me.usage.remaining === 0;
    box.append(PF.el('span', { class: 'quota-pill' + (low ? ' low' : ''), id: 'quotaPill', text: PF.quotaText(me), title: 'Allowance resets daily at 00:00 UTC' }));
    const name = me.user.name || me.user.email;
    const menu = PF.el('div', { class: 'menu' }, PF.el('a', { href: '/account', text: 'Account' }), PF.el('a', { href: '/subscription', text: 'Subscription' }), PF.el('button', { type: 'button', text: 'Log out', onclick: PF.logout }));
    box.append(PF.el('details', { class: 'usermenu' }, PF.el('summary', {}, PF.el('span', { class: 'avatar', 'aria-hidden': 'true', text: (name[0] || '?').toUpperCase() }), PF.el('span', { class: 'uname', text: name })), menu));
  }
  document.addEventListener('DOMContentLoaded', () => {
    const t = document.getElementById('navToggle'), n = document.getElementById('mainNav');
    if (t && n) t.addEventListener('click', () => { const o = n.classList.toggle('open'); t.setAttribute('aria-expanded', o ? 'true' : 'false'); });
    document.addEventListener('click', (e) => { document.querySelectorAll('.usermenu[open]').forEach((d) => { if (!d.contains(e.target)) d.removeAttribute('open'); }); });
    PF.ready = PF.load();
  });
})(window);
