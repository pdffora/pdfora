/* PDFora interactive tools: Sign PDF, Organize PDF, Image Cropper */
(function (g) {
  'use strict';
  const P = (g.PDFora = g.PDFora || {});
  const T = (P.T = P.T || {});
  const h = P.h, row = P.row, plural = P.plural;
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

  /* =====================================================================
     13. SIGN PDF
     ===================================================================== */
  const sign = { sig: null, place: { nx: 0.55, ny: 0.8, nw: 0.25 }, page: 0, doc: null, docFor: null, hasInk: false, token: 0 };
  T.sign = {
    slug: 'sign-pdf', name: 'Sign PDF', icon: '\u270d', desc: 'Draw, type or upload your signature and place it on your PDF pages.', kw: 'signature sign initials esign draw',
    kinds: ['pdf'], acceptText: 'PDF files', accept: '.pdf,application/pdf', multi: false, min: 1, wide: true, btn: () => 'Sign PDF',
    hint: 'This adds your signature image to the page. It is a visual signature, not a certificate-based digital signature.',
    ready: () => !!sign.sig,
    mount(app) {
      sign.sig = null; sign.page = 0; sign.doc = null; sign.docFor = null; sign.hasInk = false; sign.place = { nx: 0.55, ny: 0.8, nw: 0.25 };
      const ex = app.q('#extra');
      ex.innerHTML = '<div class="sign">' +
        '<div class="sg-title">1. Create your signature</div>' +
        '<div class="tabs" role="tablist"><button type="button" class="on" data-tab="draw">Draw</button><button type="button" data-tab="type">Type</button><button type="button" data-tab="upload">Upload image</button></div>' +
        '<div class="tabbody" data-body="draw"><canvas id="sigPad" width="600" height="200" aria-label="Signature drawing area"></canvas><div class="row-btns"><button type="button" class="secondary sm" id="sigClear">Clear</button><small>Draw with your mouse, finger or stylus</small></div></div>' +
        '<div class="tabbody" data-body="type" hidden><input id="sigText" type="text" placeholder="Type your name" maxlength="40" autocomplete="off"><select id="sigFont"><option value="italic 400 80px \'Brush Script MT\',\'Segoe Script\',\'Snell Roundhand\',\'Apple Chancery\',cursive">Script</option><option value="italic 400 72px Georgia,\'Times New Roman\',serif">Classic serif</option><option value="400 70px \'Comic Sans MS\',\'Bradley Hand\',\'Chalkboard SE\',cursive">Handwritten</option></select><canvas id="sigPrev" width="600" height="200"></canvas></div>' +
        '<div class="tabbody" data-body="upload" hidden><input id="sigFile" type="file" accept="image/png,image/jpeg,image/webp"><label class="chk"><input type="checkbox" id="sigTrans" checked> Make the white background transparent</label></div>' +
        '<div class="row-btns"><button type="button" class="primary sm" id="sigUse">Use this signature</button><span id="sigMsg" class="sg-msg"></span></div>' +
        '<div class="placer" id="placer" hidden><div class="sg-title">2. Place it on the page</div>' +
        '<div class="pg-nav"><button type="button" class="secondary sm" id="pgPrev" aria-label="Previous page">\u25c0</button><span id="pgInfo">Page 1</span><button type="button" class="secondary sm" id="pgNext" aria-label="Next page">\u25b6</button></div>' +
        '<div class="pwrap" id="pwrap"><canvas id="pcanvas"></canvas><img id="sigImg" class="sigimg" alt="Your signature" draggable="false"></div>' +
        '<small class="opt-hint">Drag the signature to where it should go.</small>' +
        '<div class="opt-grid">' + row('Signature size', '<input id="sigSize" type="range" min="6" max="70" value="25">') + row('Sign', '<select id="applyTo"><option value="this">This page only</option><option value="all">All pages</option><option value="first">First page</option><option value="last">Last page</option><option value="range">Specific pages\u2026</option></select>') + '</div>' +
        '<div id="rangeRow" style="display:none">' + row('Pages', '<input id="applyRange" type="text" placeholder="e.g. 1-3,5">') + '</div></div></div>';
      // tabs
      ex.querySelectorAll('.tabs button').forEach((b) => b.addEventListener('click', () => { ex.querySelectorAll('.tabs button').forEach((x) => x.classList.toggle('on', x === b)); ex.querySelectorAll('.tabbody').forEach((x) => { x.hidden = x.dataset.body !== b.dataset.tab; }); }));
      // draw pad
      const pad = ex.querySelector('#sigPad'), pctx = pad.getContext('2d'); let drawing = false, last = null;
      pctx.lineWidth = 4; pctx.lineCap = 'round'; pctx.lineJoin = 'round'; pctx.strokeStyle = '#0b2a6f';
      const pos = (e) => { const r = pad.getBoundingClientRect(); return { x: (e.clientX - r.left) * pad.width / r.width, y: (e.clientY - r.top) * pad.height / r.height }; };
      pad.addEventListener('pointerdown', (e) => { drawing = true; last = pos(e); pad.setPointerCapture(e.pointerId); pctx.beginPath(); pctx.arc(last.x, last.y, 2, 0, 7); pctx.fillStyle = '#0b2a6f'; pctx.fill(); sign.hasInk = true; e.preventDefault(); });
      pad.addEventListener('pointermove', (e) => { if (!drawing) return; const p = pos(e); pctx.beginPath(); pctx.moveTo(last.x, last.y); pctx.lineTo(p.x, p.y); pctx.stroke(); last = p; });
      ['pointerup', 'pointercancel'].forEach((ev) => pad.addEventListener(ev, () => { drawing = false; }));
      ex.querySelector('#sigClear').addEventListener('click', () => { pctx.clearRect(0, 0, pad.width, pad.height); sign.hasInk = false; });
      // typed preview
      const renderTyped = () => { const c = ex.querySelector('#sigPrev'), x = c.getContext('2d'); x.clearRect(0, 0, c.width, c.height); const t = ex.querySelector('#sigText').value; x.fillStyle = '#0b2a6f'; x.font = ex.querySelector('#sigFont').value; x.textBaseline = 'middle'; x.textAlign = 'center'; if (t) x.fillText(t, c.width / 2, c.height / 2, c.width - 30); };
      ex.querySelector('#sigText').addEventListener('input', renderTyped); ex.querySelector('#sigFont').addEventListener('change', renderTyped);
      // use signature
      const msg = (m, bad) => { const s = ex.querySelector('#sigMsg'); s.textContent = m; s.classList.toggle('bad', !!bad); };
      ex.querySelector('#sigUse').addEventListener('click', async () => {
        try {
          const active = ex.querySelector('.tabs .on').dataset.tab; let src;
          if (active === 'draw') { if (!sign.hasInk) throw new Error('Please draw your signature first.'); src = pad; }
          else if (active === 'type') { if (!ex.querySelector('#sigText').value.trim()) throw new Error('Please type your name first.'); renderTyped(); src = ex.querySelector('#sigPrev'); }
          else {
            const f = ex.querySelector('#sigFile').files[0]; if (!f) throw new Error('Please choose an image file first.');
            const kind = await P.sniff(f); if (!['png', 'jpg', 'webp'].includes(kind)) throw new Error('Please choose a PNG, JPG or WebP image.');
            const im = await P.loadImage(f); const sc = Math.min(1, 900 / im.w); const c = P.drawToCanvas(im, im.w * sc, im.h * sc); im.close();
            if (ex.querySelector('#sigTrans').checked) { const cx = c.getContext('2d'), id = cx.getImageData(0, 0, c.width, c.height), d = id.data; for (let i = 0; i < d.length; i += 4) { const m = Math.min(d[i], d[i + 1], d[i + 2]); if (m > 235) d[i + 3] = 0; else if (m > 190) d[i + 3] = Math.round(d[i + 3] * (235 - m) / 45); } cx.putImageData(id, 0, 0); }
            src = c;
          }
          const trimmed = trim(src); if (!trimmed) throw new Error('The signature is empty.');
          sign.sig = trimmed; ex.querySelector('#sigImg').src = trimmed.toDataURL('image/png'); msg('Signature ready \u2713');
          ex.querySelector('#placer').hidden = false; P.updateButton(); await showPage(app);
        } catch (e) { msg(e.message, true); }
      });
      // placement
      const img = ex.querySelector('#sigImg'), wrap = ex.querySelector('#pwrap');
      const layout = () => { const s = sign.place; img.style.left = (s.nx * 100) + '%'; img.style.top = (s.ny * 100) + '%'; img.style.width = (s.nw * 100) + '%'; };
      sign.layout = layout; layout();
      let drag = null;
      img.addEventListener('pointerdown', (e) => { const r = wrap.getBoundingClientRect(), ir = img.getBoundingClientRect(); drag = { dx: e.clientX - ir.left, dy: e.clientY - ir.top, r }; img.setPointerCapture(e.pointerId); e.preventDefault(); });
      img.addEventListener('pointermove', (e) => { if (!drag) return; const r = wrap.getBoundingClientRect(), ir = img.getBoundingClientRect(); sign.place.nx = clamp((e.clientX - drag.dx - r.left) / r.width, 0, 1 - ir.width / r.width); sign.place.ny = clamp((e.clientY - drag.dy - r.top) / r.height, 0, 1 - ir.height / r.height); layout(); });
      ['pointerup', 'pointercancel'].forEach((ev) => img.addEventListener(ev, () => { drag = null; }));
      ex.querySelector('#sigSize').addEventListener('input', (e) => { sign.place.nw = +e.target.value / 100; const r = wrap.getBoundingClientRect(), ir = img.getBoundingClientRect(); layout(); const ir2 = img.getBoundingClientRect(); sign.place.nx = clamp(sign.place.nx, 0, Math.max(0, 1 - ir2.width / r.width)); sign.place.ny = clamp(sign.place.ny, 0, Math.max(0, 1 - ir2.height / r.height)); layout(); void ir; });
      ex.querySelector('#pgPrev').addEventListener('click', () => { if (sign.page > 0) { sign.page--; showPage(app); } });
      ex.querySelector('#pgNext').addEventListener('click', () => { if (sign.doc && sign.page < sign.doc.numPages - 1) { sign.page++; showPage(app); } });
      ex.querySelector('#applyTo').addEventListener('change', (e) => { ex.querySelector('#rangeRow').style.display = e.target.value === 'range' ? '' : 'none'; });
    },
    filesChanged(app) { sign.doc = null; sign.docFor = null; sign.page = 0; showPage(app); },
    unmount() { if (sign.doc && sign.doc.destroy) sign.doc.destroy(); sign.doc = null; },
    async run(files, ctx) {
      if (!sign.sig) throw new Error('Create your signature first (step 1).');
      const L = P.need(); const doc = await P.loadPdf(files[0]); const pages = doc.getPages(); const n = pages.length;
      const at = ctx.val('applyTo'); let idx;
      if (at === 'all') idx = pages.map((_, i) => i); else if (at === 'first') idx = [0]; else if (at === 'last') idx = [n - 1]; else if (at === 'range') idx = P.parseRanges(ctx.val('applyRange'), n); else idx = [Math.min(sign.page, n - 1)];
      const blob = await P.canvasBlob(sign.sig, 'image/png'); const emb = await doc.embedPng(new Uint8Array(await blob.arrayBuffer()));
      for (const i of idx) {
        const G = P.pageGeom(pages[i]); const sw = sign.place.nw * G.vw, sh = sw * sign.sig.height / sign.sig.width;
        P.drawImageVisual(pages[i], emb, sign.place.nx * G.vw, G.vh - sign.place.ny * G.vh - sh, sw, sh);
      }
      const res = await P.savePdf(doc, P.baseName(files[0].name) + '-signed.pdf'); res.info = 'Signature added to ' + plural(idx.length, 'page'); void L; return [res];
    }
  };
  function trim(c) {
    const x = c.getContext('2d'), d = x.getImageData(0, 0, c.width, c.height).data; let x0 = c.width, y0 = c.height, x1 = -1, y1 = -1;
    for (let y = 0; y < c.height; y++) for (let xx = 0; xx < c.width; xx++) if (d[(y * c.width + xx) * 4 + 3] > 12) { if (xx < x0) x0 = xx; if (xx > x1) x1 = xx; if (y < y0) y0 = y; if (y > y1) y1 = y; }
    if (x1 < 0) return null; const p = 6; x0 = Math.max(0, x0 - p); y0 = Math.max(0, y0 - p); x1 = Math.min(c.width - 1, x1 + p); y1 = Math.min(c.height - 1, y1 + p);
    const o = P.makeCanvas(x1 - x0 + 1, y1 - y0 + 1); o.getContext('2d').drawImage(c, x0, y0, o.width, o.height, 0, 0, o.width, o.height); return o;
  }
  async function showPage(app) {
    const ex = app.q('#extra'); if (!ex || !ex.querySelector('#pcanvas')) return;
    const entry = app.entries[0]; const myToken = ++sign.token;
    if (!entry) { ex.querySelector('#pcanvas').width = 1; ex.querySelector('#pcanvas').height = 1; ex.querySelector('#pgInfo').textContent = 'Add a PDF to preview it'; return; }
    try {
      if (!sign.doc || sign.docFor !== entry.id) { if (sign.doc && sign.doc.destroy) sign.doc.destroy(); sign.doc = await P.openPdfjs(entry.file); sign.docFor = entry.id; sign.page = 0; }
      if (myToken !== sign.token) return;
      const c = await P.renderPage(sign.doc, sign.page + 1, 1.3); if (myToken !== sign.token) return;
      const pc = ex.querySelector('#pcanvas'); pc.width = c.width; pc.height = c.height; pc.getContext('2d').drawImage(c, 0, 0);
      ex.querySelector('#pgInfo').textContent = 'Page ' + (sign.page + 1) + ' of ' + sign.doc.numPages;
      ex.querySelector('#pgPrev').disabled = sign.page === 0; ex.querySelector('#pgNext').disabled = sign.page >= sign.doc.numPages - 1;
    } catch (e) { app.say(e.message, 'error'); }
  }

  /* =====================================================================
     16. ORGANIZE PDF
     ===================================================================== */
  const org = { tiles: [], docs: new Map(), queue: [], working: false, gen: 0 };
  function orgRender(app) {
    const grid = app.q('#orgGrid'); if (!grid) return; grid.innerHTML = '';
    const multi = new Set(org.tiles.map((t) => t.fid)).size > 1;
    org.tiles.forEach((t, i) => {
      const el = h('div', { class: 'pgtile', draggable: 'true', 'data-i': i });
      const box = h('div', { class: 'thumb' }); if (t.canvas) { t.canvas.style.transform = 'rotate(' + t.rot + 'deg)' + (t.rot % 180 ? ' scale(' + Math.min(1, t.canvas.width / t.canvas.height) + ')' : ''); box.append(t.canvas); } else box.append(h('span', { class: 'ph', text: '\u2026' }));
      el.append(box, h('div', { class: 'lab', text: (multi ? t.name.slice(0, 14) + ' \u00b7 ' : '') + 'Page ' + (t.pi + 1) }));
      el.append(h('div', { class: 'tb' },
        h('button', { type: 'button', title: 'Move earlier', 'aria-label': 'Move earlier', text: '\u25c0', disabled: i === 0 ? '' : null, onclick: () => { [org.tiles[i - 1], org.tiles[i]] = [org.tiles[i], org.tiles[i - 1]]; orgRender(app); } }),
        h('button', { type: 'button', title: 'Rotate', 'aria-label': 'Rotate page', text: '\u21bb', onclick: () => { t.rot = (t.rot + 90) % 360; orgRender(app); } }),
        h('button', { type: 'button', title: 'Move later', 'aria-label': 'Move later', text: '\u25b6', disabled: i === org.tiles.length - 1 ? '' : null, onclick: () => { [org.tiles[i + 1], org.tiles[i]] = [org.tiles[i], org.tiles[i + 1]]; orgRender(app); } })));
      el.append(h('button', { class: 'merge-remove', type: 'button', title: 'Delete page', 'aria-label': 'Delete page ' + (t.pi + 1), text: '\u00d7', onclick: () => { org.tiles.splice(i, 1); orgRender(app); } }));
      el.addEventListener('dragstart', (e) => { e.dataTransfer.setData('text/plain', String(i)); e.dataTransfer.effectAllowed = 'move'; el.classList.add('drag'); });
      el.addEventListener('dragend', () => el.classList.remove('drag'));
      el.addEventListener('dragover', (e) => { if (e.dataTransfer.types.includes('Files')) return; e.preventDefault(); el.classList.add('over'); });
      el.addEventListener('dragleave', () => el.classList.remove('over'));
      el.addEventListener('drop', (e) => { if (e.dataTransfer.types.includes('Files')) return; e.preventDefault(); e.stopPropagation(); const from = +e.dataTransfer.getData('text/plain'); if (isNaN(from) || from === i) return; const [m] = org.tiles.splice(from, 1); org.tiles.splice(i, 0, m); orgRender(app); });
      grid.append(el);
    });
    const info = app.q('#orgInfo'); if (info) info.textContent = org.tiles.length ? org.tiles.length + (org.tiles.length === 1 ? ' page' : ' pages') + ' will be saved. Drag pages, or use the arrow buttons, to reorder.' : 'No pages left. Add a PDF or press Reset.';
    P.updateButton();
  }
  async function orgPump(app) {
    if (org.working) return; org.working = true; const gen = org.gen;
    while (org.queue.length && gen === org.gen) {
      const t = org.queue.shift(); const rec = org.docs.get(t.fid); if (!rec || !rec.pdf) continue;
      if (t.pi >= 300) continue;
      try { t.canvas = await P.renderPage(rec.pdf, t.pi + 1, 0.3); t.canvas.className = 'thumbcanvas'; } catch (e) { /* ignore */ }
      if (gen === org.gen) { const idx = org.tiles.indexOf(t); if (idx >= 0) orgRender(app); }
      await P.tick();
    }
    org.working = false;
  }
  T.organize = {
    slug: 'organize-pdf', name: 'Organize PDF', icon: '\u2637', desc: 'Reorder, rotate or delete PDF pages. You can also combine pages from several PDFs.', kw: 'reorder rearrange delete remove pages sort arrange',
    kinds: ['pdf'], acceptText: 'PDF files', accept: '.pdf,application/pdf', multi: true, min: 1, ordered: false, wide: true, btn: () => 'Save organized PDF',
    hint: 'Pages from every PDF you add appear below. Delete pages with \u00d7, rotate with \u21bb, drag to reorder.',
    ready: () => org.tiles.length > 0,
    mount(app) {
      org.tiles = []; org.docs = new Map(); org.queue = []; org.working = false; org.gen++;
      app.q('#extra').innerHTML = '<div class="org"><div class="org-bar"><span id="orgInfo" class="org-info">Add a PDF to see its pages</span><span class="org-btns"><button type="button" class="secondary sm" id="orgRev">Reverse order</button><button type="button" class="secondary sm" id="orgReset">Reset</button></span></div><div class="org-grid" id="orgGrid"></div></div>';
      app.q('#orgRev').addEventListener('click', () => { org.tiles.reverse(); orgRender(app); });
      app.q('#orgReset').addEventListener('click', () => { org.tiles = []; org.queue = []; org.docs.forEach((r, fid) => { r.tilesDone = false; }); syncTiles(app, true); });
    },
    filesChanged(app) { syncTiles(app, false); },
    unmount() { org.gen++; org.docs.forEach((r) => r.pdf && r.pdf.destroy && r.pdf.destroy()); org.docs = new Map(); org.tiles = []; },
    async run(files, ctx) {
      const L = P.need(); const out = await L.PDFDocument.create(); const srcs = new Map();
      const byFile = new Map(); org.tiles.forEach((t) => { if (!byFile.has(t.fid)) byFile.set(t.fid, new Set()); byFile.get(t.fid).add(t.pi); });
      let k = 0;
      for (const [fid, set] of byFile) {
        const entry = ctx.entries.find((e) => e.id === fid); if (!entry) continue;
        const doc = await P.loadPdf(entry.file); const idxs = [...set].sort((a, b) => a - b); const copied = await out.copyPages(doc, idxs); const map = new Map(); idxs.forEach((ix, j) => map.set(ix, copied[j])); srcs.set(fid, map); ctx.progress(++k / byFile.size, 'Reading ' + entry.file.name);
      }
      for (const t of org.tiles) {
        const pg = srcs.get(t.fid) && srcs.get(t.fid).get(t.pi); if (!pg) continue;
        if (t.rot) pg.setRotation(L.degrees((pg.getRotation().angle + t.rot) % 360));
        out.addPage(pg);
      }
      if (!out.getPageCount()) throw new Error('There are no pages to save.');
      const one = byFile.size === 1; const e0 = ctx.entries.find((e) => e.id === [...byFile.keys()][0]);
      const res = await P.savePdf(out, one ? P.baseName(e0.file.name) + '-organized.pdf' : 'PDFora-organized.pdf'); res.info = plural(out.getPageCount(), 'page') + ' in the new order'; return [res];
    }
  };
  async function syncTiles(app, reset) {
    const entries = app.entries; const ids = new Set(entries.map((e) => e.id));
    org.tiles = org.tiles.filter((t) => ids.has(t.fid));
    for (const [fid, r] of [...org.docs]) if (!ids.has(fid)) { r.pdf && r.pdf.destroy && r.pdf.destroy(); org.docs.delete(fid); }
    orgRender(app);
    for (const e of entries) {
      let rec = org.docs.get(e.id);
      if (rec && rec.tilesDone && !reset) continue;
      try {
        if (!rec) { rec = { pdf: null, tilesDone: false }; org.docs.set(e.id, rec); rec.pdf = await P.openPdfjs(e.file); }
        if (!org.docs.has(e.id)) continue;
        const nt = []; for (let i = 0; i < rec.pdf.numPages; i++) nt.push({ fid: e.id, name: e.file.name, pi: i, rot: 0, canvas: null });
        rec.tilesDone = true; org.tiles.push(...nt); org.queue.push(...nt); orgRender(app); orgPump(app);
      } catch (err) { org.docs.delete(e.id); app.remove(e.id); app.say(err.message, 'error'); return; }
    }
  }

  /* =====================================================================
     22. IMAGE CROPPER
     ===================================================================== */
  const crop = { drag: null };
  T.imgcrop = {
    slug: 'image-cropper', name: 'Image Cropper', icon: '\u25a3', desc: 'Crop images with a draggable selection or exact coordinates.', kw: 'crop trim cut photo picture square',
    kinds: ['png', 'jpg', 'webp', 'gif', 'bmp', 'avif'], acceptText: 'images (JPG, PNG, WebP, GIF, BMP or AVIF)', accept: 'image/*,.jpg,.jpeg,.png,.webp,.gif,.bmp,.avif',
    multi: true, min: 1, selectable: true, wide: true, zipName: 'PDFora-cropped', btn: (n) => 'Crop ' + n + (n === 1 ? ' Image' : ' Images'),
    hint: 'Click an image card to choose which image you are cropping. Each image keeps its own crop area.',
    mount(app) {
      app.q('#extra').innerHTML = '<div class="crop" id="cropUi" hidden><div class="cwrap" id="cwrap"><img id="cimg" alt="Image to crop" draggable="false"><div class="cbox" id="cbox"><i class="hd tl" data-h="tl"></i><i class="hd tr" data-h="tr"></i><i class="hd bl" data-h="bl"></i><i class="hd br" data-h="br"></i></div></div>' +
        '<div class="opt-grid">' + row('Aspect ratio', '<select id="cAspect"><option value="0">Free</option><option value="1">1:1 (square)</option><option value="1.3333">4:3</option><option value="1.7778">16:9</option><option value="1.5">3:2</option><option value="0.75">3:4</option><option value="0.5625">9:16</option></select>') +
        row('X', '<input id="cx" type="number" min="0">') + row('Y', '<input id="cy" type="number" min="0">') + row('Width', '<input id="cw" type="number" min="1">') + row('Height', '<input id="ch" type="number" min="1">') + '</div><small class="opt-hint" id="cInfo"></small></div>';
      const box = app.q('#cbox'), wrap = app.q('#cwrap'), img = app.q('#cimg');
      const active = () => { const s = P.app.entries; const id = activeId(app); return s.find((e) => e.id === id) || s[0]; };
      const draw = () => { const e = active(); if (!e || !e.crop || !img.clientWidth) return; const k = img.clientWidth / e.nat.w; box.style.left = e.crop.x * k + 'px'; box.style.top = e.crop.y * k + 'px'; box.style.width = e.crop.w * k + 'px'; box.style.height = e.crop.h * k + 'px'; ['cx', 'cy', 'cw', 'ch'].forEach((id, i) => { app.q('#' + id).value = Math.round(e.crop[['x', 'y', 'w', 'h'][i]]); }); app.q('#cInfo').textContent = 'Selected area: ' + Math.round(e.crop.w) + ' \u00d7 ' + Math.round(e.crop.h) + ' px (image is ' + e.nat.w + ' \u00d7 ' + e.nat.h + ' px)'; };
      crop.draw = draw;
      const fit = (e, ratio, anchor) => { // fit the current crop to a ratio
        const c = e.crop; if (!ratio) return; let w = c.w, hh = c.w / ratio; if (hh > e.nat.h) { hh = e.nat.h; w = hh * ratio; } if (w > e.nat.w) { w = e.nat.w; hh = w / ratio; }
        const cx = c.x + c.w / 2, cy = c.y + c.h / 2; c.w = w; c.h = hh; c.x = clamp(cx - w / 2, 0, e.nat.w - w); c.y = clamp(cy - hh / 2, 0, e.nat.h - hh); void anchor;
      };
      app.q('#cAspect').addEventListener('change', () => { const e = active(); if (!e || !e.crop) return; fit(e, +app.q('#cAspect').value); draw(); });
      ['cx', 'cy', 'cw', 'ch'].forEach((id) => app.q('#' + id).addEventListener('change', () => {
        const e = active(); if (!e || !e.crop) return; const c = e.crop; const v = Math.round(+app.q('#' + id).value) || 0;
        if (id === 'cx') c.x = clamp(v, 0, e.nat.w - 1); if (id === 'cy') c.y = clamp(v, 0, e.nat.h - 1);
        if (id === 'cw') c.w = clamp(v, 1, e.nat.w); if (id === 'ch') c.h = clamp(v, 1, e.nat.h);
        c.w = Math.min(c.w, e.nat.w - c.x); c.h = Math.min(c.h, e.nat.h - c.y); app.q('#cAspect').value = '0'; draw();
      }));
      box.addEventListener('pointerdown', (e) => { const en = active(); if (!en || !en.crop) return; const hd = e.target.dataset && e.target.dataset.h; crop.drag = { hd, sx: e.clientX, sy: e.clientY, c: Object.assign({}, en.crop), k: img.clientWidth / en.nat.w, en }; box.setPointerCapture(e.pointerId); e.preventDefault(); });
      box.addEventListener('pointermove', (e) => {
        const d = crop.drag; if (!d) return; const en = d.en, c = en.crop, dx = (e.clientX - d.sx) / d.k, dy = (e.clientY - d.sy) / d.k, W = en.nat.w, H = en.nat.h, ratio = +app.q('#cAspect').value;
        if (!d.hd) { c.x = clamp(d.c.x + dx, 0, W - c.w); c.y = clamp(d.c.y + dy, 0, H - c.h); }
        else {
          let x0 = d.c.x, y0 = d.c.y, x1 = d.c.x + d.c.w, y1 = d.c.y + d.c.h;
          if (d.hd.includes('l')) x0 = clamp(x0 + dx, 0, x1 - 8); if (d.hd.includes('r')) x1 = clamp(x1 + dx, x0 + 8, W);
          if (d.hd.includes('t')) y0 = clamp(y0 + dy, 0, y1 - 8); if (d.hd.includes('b')) y1 = clamp(y1 + dy, y0 + 8, H);
          if (ratio) { let w = x1 - x0, hh = w / ratio; const growY = d.hd.includes('t') ? -1 : 1; if (growY > 0) { if (y0 + hh > H) { hh = H - y0; w = hh * ratio; } y1 = y0 + hh; } else { if (y1 - hh < 0) { hh = y1; w = hh * ratio; } y0 = y1 - hh; } if (d.hd.includes('l')) x0 = x1 - w; else x1 = x0 + w; if (x0 < 0) { x0 = 0; w = x1 - x0; hh = w / ratio; if (growY > 0) y1 = y0 + hh; else y0 = y1 - hh; } if (x1 > W) { x1 = W; w = x1 - x0; hh = w / ratio; if (growY > 0) y1 = y0 + hh; else y0 = y1 - hh; } }
          c.x = x0; c.y = y0; c.w = x1 - x0; c.h = y1 - y0;
        }
        c.edited = true; draw();
      });
      ['pointerup', 'pointercancel'].forEach((ev) => box.addEventListener(ev, () => { crop.drag = null; }));
      img.addEventListener('load', () => { const e = active(); if (!e) return; if (!e.nat) e.nat = { w: img.naturalWidth, h: img.naturalHeight }; if (!e.crop) e.crop = { x: 0, y: 0, w: e.nat.w, h: e.nat.h }; draw(); });
      g.addEventListener('resize', draw); void wrap;
    },
    filesChanged(app) { loadCrop(app); },
    onSelect(app) { loadCrop(app); },
    async run(files, ctx) {
      return P.perFile(files, ctx, async (f, i) => {
        const e = ctx.entries[i]; const im = await P.loadImage(f);
        let c = e.crop && e.crop.w ? e.crop : { x: 0, y: 0, w: im.w, h: im.h };
        const x = clamp(Math.round(c.x), 0, im.w - 1), y = clamp(Math.round(c.y), 0, im.h - 1), w = clamp(Math.round(c.w), 1, im.w - x), hh = clamp(Math.round(c.h), 1, im.h - y);
        if (x === 0 && y === 0 && w === im.w && hh === im.h) ctx.warn('"' + f.name + '" was not cropped because the selection covers the whole image. Select the image card, then drag the crop box.');
        const type = { jpg: 'image/jpeg', png: 'image/png', webp: 'image/webp' }[e.kind] || 'image/png';
        const cv = P.drawToCanvas(im, w, hh, { crop: { x, y, w, h: hh }, fill: type === 'image/jpeg' ? '#fff' : undefined }); im.close();
        const blob = await P.canvasBlob(cv, type, 0.92); if (!blob) throw new Error('Could not create the cropped image.');
        const ext = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp' }[type];
        return { name: P.baseName(f.name) + '-cropped.' + ext, blob, info: w + ' \u00d7 ' + hh + ' px' };
      });
    }
  };
  function activeId(app) { const root = app.q('.merge-file.active'); if (root) return +root.dataset.id; const s = app.entries; return s[0] && s[0].id; }
  function loadCrop(app) {
    const ui = app.q('#cropUi'); if (!ui) return; const es = app.entries; ui.hidden = !es.length; if (!es.length) return;
    const id = activeId(app); const e = es.find((x) => x.id === id) || es[0]; const img = app.q('#cimg');
    if (!e.thumb) e.thumb = URL.createObjectURL(e.file);
    if (img.dataset.for !== String(e.id)) { img.dataset.for = String(e.id); img.src = e.thumb; } else if (crop.draw) crop.draw();
    app.q('#cAspect').value = '0';
  }
})(window);
