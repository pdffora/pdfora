/* PDFora core utilities. Everything runs in the browser; nothing is uploaded. */
(function (g) {
  'use strict';
  const P = (g.PDFora = g.PDFora || {});

  P.MAX_FILE = 100 * 1024 * 1024;
  P.fmtSize = (n) => n < 1024 ? n + ' B' : n < 1048576 ? (n / 1024).toFixed(1) + ' KB' : (n / 1048576).toFixed(2) + ' MB';
  P.baseName = (name) => String(name).replace(/\.[^./\\]+$/, '') || 'file';
  P.extOf = (name) => (String(name).match(/\.([^./\\]+)$/) || [, ''])[1].toLowerCase();
  P.sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  P.tick = () => new Promise((r) => setTimeout(r, 0)); // let the UI repaint

  /* ---------- file type detection by content (not only by extension) ---------- */
  P.sniff = async function (file) {
    const head = new Uint8Array(await file.slice(0, 2048).arrayBuffer());
    const s = (a, b) => String.fromCharCode(...head.slice(a, b));
    if (s(0, 1024).includes('%PDF-')) return 'pdf';
    if (head[0] === 0x89 && s(1, 4) === 'PNG') return 'png';
    if (head[0] === 0xff && head[1] === 0xd8) return 'jpg';
    if (s(0, 4) === 'RIFF' && s(8, 12) === 'WEBP') return 'webp';
    if (s(0, 3) === 'GIF') return 'gif';
    if (s(0, 2) === 'BM') return 'bmp';
    if (s(4, 8) === 'ftyp' && /avif|avis/.test(s(8, 16))) return 'avif';
    if (head[0] === 0x50 && head[1] === 0x4b) return 'zip';
    if (head[0] === 0xd0 && head[1] === 0xcf && head[2] === 0x11) return 'ole'; // legacy .doc/.xls
    if (!head.includes(0)) return 'text';
    return 'unknown';
  };

  /* ---------- page-range parsing: "1-3,5", "2,4,6", "5-", "all" ---------- */
  P.parseRanges = function (str, n, opts = {}) {
    const text = String(str || '').replace(/[\u2013\u2014\u2212]/g, '-').replace(/\s*-\s*/g, '-').replace(/[\uFF0C;\s]+/g, ',').replace(/^,+|,+$/g, '');
    if (!text) throw new Error('Please enter the pages you want, for example 1-3,5.');
    if (/^(all|\*)$/i.test(text)) return Array.from({ length: n }, (_, i) => i);
    const out = [];
    for (const part of text.split(',')) {
      if (!part) continue;
      let m;
      let a, b;
      if ((m = /^(\d+)$/.exec(part))) { a = b = +m[1]; }
      else if ((m = /^(\d+)-(\d+)$/.exec(part))) { a = +m[1]; b = +m[2]; }
      else if ((m = /^(\d+)-$/.exec(part))) { a = +m[1]; b = n; }
      else throw new Error('Could not understand "' + part + '". Use a format like 1-3,5.');
      for (const v of [a, b]) {
        if (v < 1 || v > n) throw new Error('Page ' + v + ' does not exist - this PDF has ' + n + ' page' + (n === 1 ? '' : 's') + '.');
      }
      if (a <= b) for (let x = a; x <= b; x++) out.push(x - 1);
      else for (let x = a; x >= b; x--) out.push(x - 1);
    }
    if (!out.length) throw new Error('No pages selected.');
    if (opts.keepDuplicates) return out;
    const seen = new Set();
    return out.filter((x) => (seen.has(x) ? false : (seen.add(x), true)));
  };

  /* ---------- loading scripts lazily ---------- */
  const scripts = {};
  P.loadScript = (src) => scripts[src] || (scripts[src] = new Promise((res, rej) => {
    const s = document.createElement('script');
    s.src = src; s.onload = () => res(); s.onerror = () => { delete scripts[src]; rej(new Error('Could not load ' + src + '. Check your connection and reload the page.')); };
    document.head.appendChild(s);
  }));

  P.getPdfjs = async function () {
    if (!g.pdfjsLib) await P.loadScript('libs/pdf.min.js');
    if (location.protocol === 'file:' && !g.pdfjsWorker) await P.loadScript('libs/pdf.worker.min.js');
    g.pdfjsLib.GlobalWorkerOptions.workerSrc = new URL('libs/pdf.worker.min.js', document.baseURI).href;
    return g.pdfjsLib;
  };

  /* open a PDF with pdf.js. Returns the document proxy. */
  P.openPdfjs = async function (file, password) {
    const lib = await P.getPdfjs();
    const bytes = new Uint8Array(await file.arrayBuffer());
    const base = new URL('libs/', document.baseURI).href;
    try {
      return await lib.getDocument({
        data: bytes, password: password || undefined,
        cMapUrl: base + 'cmaps/', cMapPacked: true, standardFontDataUrl: base + 'standard_fonts/', isEvalSupported: false
      }).promise;
    } catch (e) {
      if (e && e.name === 'PasswordException') throw new Error('"' + file.name + '" is password-protected. Remove the password with Unlock PDF first.');
      throw new Error('"' + file.name + '" could not be read as a PDF. It may be damaged - try Repair PDF.');
    }
  };

  /* render page (1-based) to a canvas, clamped to safe canvas sizes */
  P.renderPage = async function (pdf, num, scale, opts = {}) {
    const page = await pdf.getPage(num);
    let vp = page.getViewport({ scale });
    const maxPx = 16000000;
    if (vp.width * vp.height > maxPx) { scale *= Math.sqrt(maxPx / (vp.width * vp.height)); vp = page.getViewport({ scale }); }
    const c = document.createElement('canvas');
    c.width = Math.max(1, Math.floor(vp.width)); c.height = Math.max(1, Math.floor(vp.height));
    const ctx = c.getContext('2d');
    if (opts.background !== null) { ctx.fillStyle = opts.background || '#fff'; ctx.fillRect(0, 0, c.width, c.height); }
    await page.render({ canvasContext: ctx, viewport: vp }).promise;
    page.cleanup && page.cleanup();
    return c;
  };

  /* ---------- pdf-lib helpers ---------- */
  P.need = () => { if (!g.PDFLib) throw new Error('PDF library did not load. Reload the page and try again.'); return g.PDFLib; };
  P.readBytes = async (file) => new Uint8Array(await file.arrayBuffer());

  P.loadPdf = async function (file, opts = {}) {
    const L = P.need();
    const bytes = await P.readBytes(file);
    try {
      return await L.PDFDocument.load(bytes, Object.assign({ updateMetadata: false }, opts));
    } catch (e) {
      if (e instanceof L.EncryptedPDFError || /encrypted/i.test(e && e.message)) {
        throw new Error('"' + file.name + '" is password-protected. Remove the password with Unlock PDF first.');
      }
      throw new Error('"' + file.name + '" could not be read as a PDF. It may be damaged - try Repair PDF.');
    }
  };
  P.savePdf = async function (doc, name) {
    try { doc.setProducer('PDFora'); doc.setCreator('PDFora'); } catch (e) { /* ignore */ }
    const bytes = await doc.save();
    return { name, blob: new Blob([bytes], { type: 'application/pdf' }) };
  };

  /* geometry of a page as the viewer shows it (handles /Rotate and CropBox) */
  P.pageGeom = function (page) {
    const b = page.getCropBox ? page.getCropBox() : page.getMediaBox();
    const r = (((page.getRotation().angle % 360) + 360) % 360);
    return { x0: b.x, y0: b.y, W: b.width, H: b.height, r, vw: r % 180 ? b.height : b.width, vh: r % 180 ? b.width : b.height };
  };
  /* visual coords (origin bottom-left of what the user sees) -> page content coords */
  P.toPage = function (G, vx, vy) {
    switch (G.r) {
      case 90: return [G.x0 + G.W - vy, G.y0 + vx];
      case 180: return [G.x0 + G.W - vx, G.y0 + G.H - vy];
      case 270: return [G.x0 + vy, G.y0 + G.H - vx];
      default: return [G.x0 + vx, G.y0 + vy];
    }
  };
  /* draw text at a visual position (baseline start), with optional extra rotation in degrees */
  P.drawTextVisual = function (page, text, vx, vy, o) {
    const L = P.need(); const G = P.pageGeom(page);
    const [x, y] = P.toPage(G, vx, vy);
    page.drawText(text, Object.assign({}, o, { x, y, rotate: L.degrees(G.r + (o.angle || 0)) }));
  };
  P.drawImageVisual = function (page, img, vx, vy, w, h, o = {}) {
    const L = P.need(); const G = P.pageGeom(page);
    const [x, y] = P.toPage(G, vx, vy);
    page.drawImage(img, Object.assign({}, o, { x, y, width: w, height: h, rotate: L.degrees(G.r) }));
  };

  /* ---------- downloads ---------- */
  P.downloadBlob = function (blob, name) {
    const a = document.createElement('a'); const u = URL.createObjectURL(blob);
    a.href = u; a.download = name; a.rel = 'noopener'; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(u), 60000);
  };
  P.uniqueName = function (name, used) {
    if (!used.has(name)) { used.add(name); return name; }
    const b = P.baseName(name), e = name.slice(b.length);
    let i = 2; while (used.has(b + '-' + i + e)) i++;
    const n = b + '-' + i + e; used.add(n); return n;
  };
  P.zip = async function (outputs, zipName) {
    if (!g.JSZip) throw new Error('ZIP library did not load. Reload the page.');
    const z = new g.JSZip(); const used = new Set();
    for (const o of outputs) z.file(P.uniqueName(o.name, used), o.blob, { binary: true });
    const blob = await z.generateAsync({ type: 'blob', compression: 'DEFLATE', compressionOptions: { level: 3 } });
    return { name: zipName, blob };
  };

  /* ---------- image helpers ---------- */
  P.loadImage = async function (file) {
    // honour EXIF orientation where the browser supports it
    if (g.createImageBitmap) {
      try { const bmp = await createImageBitmap(file, { imageOrientation: 'from-image' }); return { w: bmp.width, h: bmp.height, src: bmp, close: () => bmp.close && bmp.close() }; } catch (e) { /* fall back */ }
    }
    return new Promise((res, rej) => {
      const im = new Image(); const u = URL.createObjectURL(file);
      im.onload = () => res({ w: im.naturalWidth, h: im.naturalHeight, src: im, close: () => URL.revokeObjectURL(u) });
      im.onerror = () => { URL.revokeObjectURL(u); rej(new Error('"' + file.name + '" could not be decoded as an image. The file may be damaged or in an unsupported format.')); };
      im.src = u;
    });
  };
  P.canvasBlob = (c, type, q) => new Promise((res) => c.toBlob(res, type, q));
  P.makeCanvas = function (w, h) {
    const c = document.createElement('canvas'); c.width = Math.max(1, Math.round(w)); c.height = Math.max(1, Math.round(h));
    if (c.width * c.height > 268000000 || c.width > 32767 || c.height > 32767) throw new Error('The image is too large for this browser to process (' + c.width + ' x ' + c.height + ' px).');
    return c;
  };
  P.drawToCanvas = function (img, w, h, opts = {}) {
    const c = P.makeCanvas(w, h); const ctx = c.getContext('2d');
    if (opts.fill) { ctx.fillStyle = opts.fill; ctx.fillRect(0, 0, c.width, c.height); }
    ctx.imageSmoothingQuality = 'high';
    if (opts.crop) ctx.drawImage(img.src, opts.crop.x, opts.crop.y, opts.crop.w, opts.crop.h, 0, 0, c.width, c.height);
    else ctx.drawImage(img.src, 0, 0, c.width, c.height);
    return c;
  };
  /* ASCII85 decoder (used by some PDF image streams) */
  P.a85decode = function (b) {
    const out = []; let grp = [], i = 0;
    const flush = (n) => { let v = 0; for (let k = 0; k < 5; k++) v = v * 85 + (k < n ? grp[k] : 84); const bytes = [(v >>> 24) & 255, (v >>> 16) & 255, (v >>> 8) & 255, v & 255]; for (let k = 0; k < n - 1; k++) out.push(bytes[k]); };
    if (b[0] === 60 && b[1] === 126) i = 2;
    for (; i < b.length; i++) {
      const c = b[i];
      if (c === 126) break; if (c <= 32) continue;
      if (c === 122 && !grp.length) { out.push(0, 0, 0, 0); continue; }
      if (c < 33 || c > 117) continue;
      grp.push(c - 33); if (grp.length === 5) { flush(5); grp = []; }
    }
    if (grp.length > 1) flush(grp.length);
    return Uint8Array.from(out);
  };
  P.pdfSafeName = (s) => s.replace(/[\\/:*?"<>|]+/g, '_');
})(typeof window !== 'undefined' ? window : globalThis);
