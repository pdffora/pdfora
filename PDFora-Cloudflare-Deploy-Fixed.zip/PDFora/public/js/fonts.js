/* Font handling: standard PDF fonts for Western text, embedded DejaVu Sans for other scripts. */
(function (g) {
  'use strict';
  const P = (g.PDFora = g.PDFora || {});

  /* ---- minimal TrueType parser, shaped like the subset of fontkit's API pdf-lib uses ---- */
  function parseTTF(buf, psName) {
    const dv = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
    const n = dv.getUint16(4), T = {};
    for (let i = 0; i < n; i++) {
      const o = 12 + 16 * i;
      T[String.fromCharCode(dv.getUint8(o), dv.getUint8(o + 1), dv.getUint8(o + 2), dv.getUint8(o + 3))] = { o: dv.getUint32(o + 8), l: dv.getUint32(o + 12) };
    }
    const head = T.head.o, hhea = T.hhea.o, hmtx = T.hmtx.o;
    const upm = dv.getUint16(head + 18);
    const numH = dv.getUint16(hhea + 34), numGlyphs = dv.getUint16(T.maxp.o + 4);
    const adv = (gid) => dv.getUint16(hmtx + 4 * Math.min(gid, numH - 1));
    const cmap = new Map();
    const c0 = T.cmap.o, nt = dv.getUint16(c0 + 2);
    let best = null;
    for (let i = 0; i < nt; i++) {
      const pl = dv.getUint16(c0 + 4 + 8 * i), en = dv.getUint16(c0 + 6 + 8 * i), off = c0 + dv.getUint32(c0 + 8 + 8 * i);
      const fmt = dv.getUint16(off);
      const score = (pl === 3 && en === 10 && fmt === 12) ? 3 : (pl === 3 && en === 1 && fmt === 4) ? 2 : (pl === 0 && (fmt === 4 || fmt === 12)) ? 1 : 0;
      if (score && (!best || score > best.score)) best = { score, off, fmt };
    }
    if (!best) throw new Error('Unsupported font');
    if (best.fmt === 4) {
      const o = best.off, sc = dv.getUint16(o + 6) / 2, endO = o + 14, startO = endO + sc * 2 + 2, deltaO = startO + sc * 2, rangeO = deltaO + sc * 2;
      for (let s = 0; s < sc; s++) {
        const end = dv.getUint16(endO + 2 * s), start = dv.getUint16(startO + 2 * s), delta = dv.getInt16(deltaO + 2 * s), ro = dv.getUint16(rangeO + 2 * s);
        if (start === 0xffff) continue;
        for (let c = start; c <= end; c++) {
          let gid;
          if (ro === 0) gid = (c + delta) & 0xffff;
          else { const p = rangeO + 2 * s + ro + 2 * (c - start); gid = dv.getUint16(p); if (gid) gid = (gid + delta) & 0xffff; }
          if (gid) cmap.set(c, gid);
        }
      }
    } else {
      const o = best.off, ng = dv.getUint32(o + 12);
      for (let i = 0; i < ng; i++) { const p = o + 16 + 12 * i, s = dv.getUint32(p), e = dv.getUint32(p + 4), gs = dv.getUint32(p + 8); for (let c = s; c <= e; c++) cmap.set(c, gs + c - s); }
    }
    let capH = 0, xH = 0, fam = 0;
    if (T['OS/2']) { const o = T['OS/2'].o; fam = dv.getInt16(o + 30); if (dv.getUint16(o) >= 2) { xH = dv.getInt16(o + 86); capH = dv.getInt16(o + 88); } }
    let ital = 0, fixed = false;
    if (T.post) { ital = dv.getInt32(T.post.o + 4) / 65536; fixed = dv.getUint32(T.post.o + 12) !== 0; }
    const glyphs = new Map();
    const glyph = (id, cp) => { let gl = glyphs.get(id); if (!gl) { gl = { id, advanceWidth: adv(id), codePoints: cp != null ? [cp] : [] }; glyphs.set(id, gl); } return gl; };
    const font = {
      postscriptName: psName, unitsPerEm: upm,
      ascent: dv.getInt16(hhea + 4), descent: dv.getInt16(hhea + 6), lineGap: dv.getInt16(hhea + 8),
      italicAngle: ital, capHeight: capH, xHeight: xH, numGlyphs,
      bbox: { minX: dv.getInt16(head + 36), minY: dv.getInt16(head + 38), maxX: dv.getInt16(head + 40), maxY: dv.getInt16(head + 42) },
      characterSet: [...cmap.keys()].sort((a, b) => a - b), cff: false,
      'OS/2': { sFamilyClass: fam }, head: { macStyle: { italic: !!(dv.getUint16(head + 44) & 2) } }, post: { isFixedPitch: fixed },
      hasGlyphForCodePoint: (cp) => cmap.has(cp),
      glyphForCodePoint: (cp) => glyph(cmap.get(cp) || 0, cp),
      getGlyph: (id, cp) => glyph(id, cp && cp[0]),
      glyphsForString: (s) => [...s].map((ch) => glyph(cmap.get(ch.codePointAt(0)) || 0, ch.codePointAt(0))),
      layout(s) { return { glyphs: this.glyphsForString(s) }; },
      widthOfGlyph: adv, createSubset() { throw new Error('subset unsupported'); }
    };
    return font;
  }
  const shim = { create(bytes) { return bytes.__model; } };

  function b64ToBytes(b64) {
    const bin = atob(b64); const u = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
    return u;
  }

  const STD = {
    sans: ['Helvetica', 'HelveticaBold', 'HelveticaOblique', 'HelveticaBoldOblique'],
    serif: ['TimesRoman', 'TimesRomanBold', 'TimesRomanItalic', 'TimesRomanBoldItalic'],
    mono: ['Courier', 'CourierBold', 'CourierOblique', 'CourierBoldOblique']
  };

  /* A FontSet belongs to one pdf-lib document. */
  P.FontSet = class FontSet {
    constructor(doc) { this.doc = doc; this.cache = new Map(); this.uni = new Map(); this.charOk = new Map(); this.kitReady = false; }
    async std(style) {
      const fam = STD[style.family || 'sans'] || STD.sans;
      const name = fam[(style.bold ? 1 : 0) + (style.italic ? 2 : 0)];
      if (!this.cache.has(name)) this.cache.set(name, await this.doc.embedFont(P.need().StandardFonts[name]));
      return this.cache.get(name);
    }
    async unicode(bold) {
      const key = bold ? 'bold' : 'regular';
      if (this.uni.has(key)) return this.uni.get(key);
      if (!(g.PDFora.fontB64)) await P.loadScript('fonts/dejavu.js');
      if (!this.kitReady) { this.doc.registerFontkit(shim); this.kitReady = true; }
      const bytes = b64ToBytes(P.fontB64[key]);
      const model = parseTTF(bytes, bold ? 'DejaVuSans-Bold' : 'DejaVuSans');
      Object.defineProperty(bytes, '__model', { value: model });
      const font = await this.doc.embedFont(bytes, { subset: false });
      const rec = { font, model };
      this.uni.set(key, rec);
      return rec;
    }
    stdOk(font, ch) {
      const k = font.name + ch;
      if (!this.charOk.has(k)) { let ok = true; try { font.encodeText(ch); } catch (e) { ok = false; } this.charOk.set(k, ok); }
      return this.charOk.get(k);
    }
    /* Returns { font, text } where text is safe to draw with font. */
    async pick(style, text) {
      text = String(text).replace(/[\r\n\t\u00a0]/g, (c) => c === '\u00a0' ? ' ' : ' ');
      const sf = await this.std(style);
      let allOk = true;
      for (const ch of text) if (!this.stdOk(sf, ch)) { allOk = false; break; }
      if (allOk) return { font: sf, text, unicode: false };
      const u = await this.unicode(!!style.bold);
      let lost = false; let out = '';
      for (const ch of text) { if (u.model.hasGlyphForCodePoint(ch.codePointAt(0))) out += ch; else { out += '?'; lost = true; } }
      return { font: u.font, text: out, unicode: true, lost };
    }
  };
  P.warnLost = (ctx) => ctx && ctx.warn && ctx.warn('Some characters (for example Chinese, Japanese, Korean or Indic scripts) are not available in the built-in fonts and were replaced with "?".');
})(typeof window !== 'undefined' ? window : globalThis);
