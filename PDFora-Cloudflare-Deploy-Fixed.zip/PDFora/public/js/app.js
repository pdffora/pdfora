/* PDFora app shell: tool grid, search, routing and the shared upload interface. */
(function (g) {
  'use strict';
  const P = (g.PDFora = g.PDFora || {});
  const $ = (id) => document.getElementById(id);
  const h = (tag, attrs, ...kids) => {
    const e = document.createElement(tag);
    for (const k in attrs || {}) { if (attrs[k] == null || attrs[k] === false) continue; if (k === 'class') e.className = attrs[k]; else if (k === 'text') e.textContent = attrs[k]; else if (k.startsWith('on')) e.addEventListener(k.slice(2), attrs[k]); else if (k === 'html') e.innerHTML = attrs[k]; else e.setAttribute(k, attrs[k]); }
    for (const c of kids) if (c != null) e.append(c.nodeType ? c : document.createTextNode(c));
    return e;
  };
  P.h = h; P.$ = $;

  const KIND_ACCEPT = {
    pdf: '.pdf,application/pdf', png: '.png,image/png', jpg: '.jpg,.jpeg,.jfif,image/jpeg', webp: '.webp,image/webp',
    gif: '.gif,image/gif', bmp: '.bmp,image/bmp', avif: '.avif,image/avif'
  };

  /* ---------------- tool grid + search ---------------- */
  const grid = $('tools');
  function buildGrid() {
    P.tools.forEach((t) => {
      const a = h('a', { class: 'tool', href: '#' + t.slug, 'data-slug': t.slug, 'aria-label': t.name + ' - ' + t.desc });
      a.append(h('div', { class: 'ico', text: t.icon }), h('strong', { text: t.name }), h('small', { text: t.short || ('Open ' + t.name.toLowerCase() + ' tool') }));
      t.card = a; grid.appendChild(a);
    });
  }
  function filterTools() {
    const q = $('search').value.trim().toLowerCase(); const words = q.split(/\s+/).filter(Boolean);
    const match = (t, withDesc) => { const hay = (t.name + ' ' + (t.kw || '') + (withDesc ? ' ' + t.desc : '')).toLowerCase(); return words.every((w) => hay.includes(w)); };
    let hits = P.tools.filter((t) => match(t, false));
    if (words.length && !hits.length) hits = P.tools.filter((t) => match(t, true)); // fall back to descriptions
    const set = new Set(words.length ? hits : P.tools);
    P.tools.forEach((t) => { t.card.style.display = set.has(t) ? '' : 'none'; });
    const visible = set.size;
    $('toolCount').textContent = q ? visible + (visible === 1 ? ' tool found' : ' tools found') : P.tools.length + ' handy tools';
    $('noResults').style.display = visible ? 'none' : 'block';
  }

  /* ---------------- modal / tool runtime ---------------- */
  const modal = $('modal');
  let S = null; // current tool state
  let uid = 0;

  const app = P.app = {
    get files() { return S ? S.files.map((e) => e.file) : []; },
    get entries() { return S ? S.files : []; },
    get tool() { return S && S.tool; },
    q: (sel) => S && S.root.querySelector(sel),
    val: (id) => { const e = S && S.root.querySelector('#' + id); return e ? e.value : ''; },
    num: (id, d) => { const v = parseFloat(app.val(id)); return isNaN(v) ? d : v; },
    checked: (id) => { const e = S && S.root.querySelector('#' + id); return !!(e && e.checked); },
    changed: () => filesChanged(),
    clearResults: () => clearResults(),
    say: (msg, kind) => say(msg, kind),
    busy: () => !!(S && S.busy),
    remove: (id) => removeFile(id)
  };

  function openTool(slug, pushHash) {
    const t = P.tools.find((x) => x.slug === slug); if (!t) return;
    closeTool(true);
    S = { tool: t, files: [], outputs: [], busy: false, root: $('tool'), warnings: [], errors: [] };
    $('panel').classList.toggle('wide', !!t.wide);
    $('modalTitle').textContent = t.name; $('description').textContent = t.desc;
    document.title = t.name + ' - PDFora';
    buildToolUI(t);
    modal.style.display = 'flex'; document.body.classList.add('noscroll');
    if (pushHash && location.hash !== '#' + slug) history.pushState(null, '', '#' + slug);
    setTimeout(() => { const b = S && S.root.querySelector('.merge-add'); if (b) b.focus({ preventScroll: true }); }, 50);
  }
  function closeTool(silent) {
    if (S && S.tool.unmount) { try { S.tool.unmount(app); } catch (e) { /* ignore */ } }
    if (S) S.files.forEach((e) => { if (e.thumb) URL.revokeObjectURL(e.thumb); });
    S = null; $('tool').innerHTML = '';
    modal.style.display = 'none'; document.body.classList.remove('noscroll'); document.title = 'PDFora - All your PDF tools. One place.';
    if (!silent && location.hash) history.pushState(null, '', location.pathname + location.search);
  }

  function buildToolUI(t) {
    const root = S.root; root.innerHTML = '';
    root.append(h('div', { class: 'up-title', text: 'Upload your files' }));
    S.grid = h('div', { class: 'merge-grid', id: 'fileGrid' }); root.append(S.grid);
    S.picker = h('input', { type: 'file', hidden: '', accept: t.accept || '', 'aria-label': 'Choose files' });
    if (t.multi !== false) S.picker.multiple = true;
    S.picker.addEventListener('change', (e) => { addFiles([...e.target.files]); e.target.value = ''; });
    root.append(S.picker);
    S.count = h('div', { class: 'file-count', 'aria-live': 'polite' }); root.append(S.count);
    if (t.options) { S.opts = h('div', { class: 'tool-options', html: typeof t.options === 'function' ? t.options() : t.options }); root.append(S.opts); S.opts.addEventListener('input', clearResults); S.opts.addEventListener('change', clearResults); }
    S.extra = h('div', { class: 'tool-extra', id: 'extra' }); root.append(S.extra);
    S.go = h('button', { type: 'button', class: 'primary merge-action', id: 'goBtn', onclick: run }); root.append(S.go);
    S.prog = h('div', { class: 'progress', hidden: '' }, h('div', { class: 'bar' }, h('i')), h('span', { class: 'plabel' }));
    root.append(S.prog);
    S.status = h('div', { class: 'status', role: 'status', 'aria-live': 'polite' }); root.append(S.status);
    S.results = h('div', { class: 'results' }); root.append(S.results);
    root.append(h('div', { class: 'merge-note', text: t.hint || 'Max 100MB per file. Files never leave your device.' }));
    if (t.mount) t.mount(app);
    renderFiles(); updateButton();
  }

  /* ---------------- file handling ---------------- */
  async function addFiles(list) {
    if (!S || S.busy) return; const t = S.tool; const bad = [];
    if (t.multi === false && list.length) { S.files = []; list = list.slice(0, 1); if (S.root.querySelector('.merge-add')) { /* replaced */ } }
    for (const f of list) {
      if (f.size === 0) { bad.push('"' + f.name + '" is empty.'); continue; }
      if (f.size > P.MAX_FILE) { bad.push('"' + f.name + '" is larger than 100MB.'); continue; }
      if (S.files.length >= 300) { bad.push('You can add up to 300 files at a time.'); break; }
      let kind; try { kind = await P.sniff(f); } catch (e) { bad.push('"' + f.name + '" could not be read.'); continue; }
      const ext = P.extOf(f.name);
      if (kind === 'ole' && t.legacyHint) { bad.push('"' + f.name + '" is an old binary Office file. ' + t.legacyHint); continue; }
      const okKind = t.kinds.includes(kind) && (!t.exts || t.exts.includes(ext));
      if (!okKind) {
        let why = '"' + f.name + '" is not a supported file. ' + t.name + ' accepts ' + t.acceptText + '.';
        if (kind === 'pdf' && !t.kinds.includes('pdf')) why = '"' + f.name + '" is a PDF. ' + t.name + ' accepts ' + t.acceptText + '.';
        else if (['png', 'jpg', 'webp', 'gif', 'bmp', 'avif'].includes(kind) && !t.kinds.includes(kind)) why = '"' + f.name + '" is a ' + kind.toUpperCase().replace('JPG', 'JPEG') + ' image, but ' + t.name + ' accepts ' + t.acceptText + '.';
        bad.push(why); continue;
      }
      const e = { id: ++uid, file: f, kind, meta: null }; S.files.push(e);
      if (kind === 'pdf') probePdf(e);
    }
    clearResults();
    if (bad.length) say(bad.join('\n'), 'error'); else say('');
    filesChanged();
  }
  async function probePdf(e) {
    try {
      if (e.file.size > 60 * 1024 * 1024) return;
      const bytes = await P.readBytes(e.file);
      if (P.Sec && P.Sec.isEncrypted(bytes)) { e.meta = { locked: true }; }
      else { const L = P.need(); const d = await L.PDFDocument.load(bytes, { updateMetadata: false, throwOnInvalidObject: false }); e.meta = { pages: d.getPageCount() }; }
    } catch (err) { e.meta = { broken: true }; }
    if (S) { renderFiles(); if (S.tool.metaReady) S.tool.metaReady(app, e); }
  }
  function removeFile(id) {
    if (!S || S.busy) return; S.files = S.files.filter((e) => e.id !== id); clearResults(); say(''); filesChanged();
  }
  function moveFile(id, dir) {
    if (!S || S.busy) return; const i = S.files.findIndex((e) => e.id === id), j = i + dir; if (i < 0 || j < 0 || j >= S.files.length) return;
    [S.files[i], S.files[j]] = [S.files[j], S.files[i]]; clearResults(); filesChanged();
  }
  function filesChanged() { if (!S) return; renderFiles(); updateButton(); if (S.tool.filesChanged) S.tool.filesChanged(app); }

  function renderFiles() {
    const t = S.tool; const gridEl = S.grid; gridEl.innerHTML = '';
    S.files.forEach((e, idx) => {
      const card = h('div', { class: 'merge-file' + (S.active === e.id ? ' active' : ''), 'data-id': e.id });
      const isImg = e.kind !== 'pdf' && ['png', 'jpg', 'webp', 'gif', 'bmp', 'avif'].includes(e.kind);
      const icon = h('div', { class: 'file-icon' + (isImg ? ' img' : '') });
      if (isImg) { if (!e.thumb) e.thumb = URL.createObjectURL(e.file); icon.append(h('img', { src: e.thumb, alt: '' })); }
      else icon.textContent = e.kind === 'pdf' ? 'PDF' : (['zip'].includes(e.kind) ? P.extOf(e.file.name).toUpperCase() : 'CSV');
      let sub = P.fmtSize(e.file.size);
      if (e.meta && e.meta.pages) sub += ' \u00b7 ' + e.meta.pages + (e.meta.pages === 1 ? ' page' : ' pages');
      const info = h('small', { text: sub });
      card.append(icon, h('strong', { text: e.file.name, title: e.file.name }), info);
      if (e.meta && e.meta.locked && !t.allowLocked) card.append(h('span', { class: 'badge warn', text: '\ud83d\udd12 Password-protected' }));
      if (e.meta && e.meta.locked && t.allowLocked) card.append(h('span', { class: 'badge', text: '\ud83d\udd12 Protected' }));
      card.append(h('button', { class: 'merge-remove', type: 'button', 'aria-label': 'Remove ' + e.file.name, title: 'Remove', text: '\u00d7', onclick: (ev) => { ev.stopPropagation(); removeFile(e.id); } }));
      if (t.ordered && S.files.length > 1) {
        card.append(h('div', { class: 'mv' },
          h('button', { type: 'button', 'aria-label': 'Move earlier', title: 'Move earlier', text: '\u25c0', disabled: idx === 0 ? '' : null, onclick: (ev) => { ev.stopPropagation(); moveFile(e.id, -1); } }),
          h('button', { type: 'button', 'aria-label': 'Move later', title: 'Move later', text: '\u25b6', disabled: idx === S.files.length - 1 ? '' : null, onclick: (ev) => { ev.stopPropagation(); moveFile(e.id, 1); } })));
      }
      if (t.selectable) card.addEventListener('click', () => { S.active = e.id; renderFiles(); if (t.onSelect) t.onSelect(app, e); });
      gridEl.append(card);
    });
    const label = t.multi === false ? (S.files.length ? 'Replace file' : 'Add file') : 'Add more';
    gridEl.append(h('button', { type: 'button', class: 'merge-add', onclick: () => S.picker.click() }, h('b', { text: '\uff0b' }), h('span', { text: label })));
    const n = S.files.length;
    S.count.textContent = n === 0 ? 'No files selected yet' : n + (n === 1 ? ' file selected' : ' files selected');
  }

  function updateButton() {
    if (!S) return; const t = S.tool; const n = S.files.length;
    const min = t.min || 1; let ok = n >= min && !S.busy; if (ok && t.ready) ok = t.ready(app);
    S.go.disabled = !ok;
    S.go.textContent = S.busy ? 'Working\u2026' : (t.btn ? t.btn(n, app) : t.name);
  }
  P.updateButton = () => updateButton();

  function say(msg, kind) {
    if (!S) return; S.status.className = 'status' + (kind ? ' ' + kind : ''); S.status.textContent = msg || ''; S.status.style.display = msg ? 'block' : 'none';
  }
  function clearResults() { if (!S) return; S.outputs = []; S.results.innerHTML = ''; S.results.style.display = 'none'; }

  function setProgress(frac, label) {
    if (!S) return; S.prog.hidden = false; const pct = Math.max(0, Math.min(100, Math.round((frac || 0) * 100)));
    S.prog.querySelector('i').style.width = pct + '%'; S.prog.querySelector('.plabel').textContent = (label ? label + ' \u2013 ' : '') + pct + '%';
  }

  /* ---------------- running a tool ---------------- */
  async function run() {
    if (!S || S.busy) return; const t = S.tool;
    const files = S.files.map((e) => e.file); const entries = S.files.slice();
    if (files.length < (t.min || 1)) { say(t.min > 1 ? 'Please choose at least ' + t.min + ' files.' : 'Please choose a file first.', 'error'); return; }
    clearResults(); say(''); S.busy = true; S.warnings = []; S.errors = []; updateButton(); S.root.classList.add('busy');
    const ctx = {
      app, entries,
      progress: (f, l) => setProgress(f, l),
      warn: (m) => { if (!S.warnings.includes(m)) S.warnings.push(m); },
      fail: (name, m) => { S.errors.push(name ? name + ': ' + m : m); },
      val: app.val, num: app.num, checked: app.checked
    };
    setProgress(0, 'Starting');
    const mine = S;
    try {
      if (t.validate) t.validate(app);
      await P.tick();
      const outs = (await t.run(files, ctx)) || [];
      if (S !== mine) return;
      if (!outs.length) throw new Error(S.errors.length ? S.errors.join('\n') : 'No output was produced.');
      S.outputs = outs; setProgress(1, 'Finished'); showResults(outs, ctx);
    } catch (e) {
      if (S !== mine) return;
      console.warn(e); S.prog.hidden = true;
      say('Could not process: ' + (e && e.message ? e.message : e), 'error');
    } finally {
      if (S === mine) { S.busy = false; S.root.classList.remove('busy'); updateButton(); }
    }
  }

  function showResults(outs, ctx) {
    const box = S.results; box.innerHTML = ''; box.style.display = 'block';
    const total = outs.reduce((a, o) => a + o.blob.size, 0);
    box.append(h('div', { class: 'result-head', html: '<span class="tick">\u2713</span> ' }, ));
    box.firstChild.append(document.createTextNode(outs.length === 1 ? 'Your file is ready' : outs.length + ' files are ready (' + P.fmtSize(total) + ')'));
    if (outs.length === 1) {
      const o = outs[0];
      box.append(h('button', { class: 'primary dl-main', type: 'button', onclick: () => P.downloadBlob(o.blob, o.name) }, '\u2b07 Download ' + o.name + ' (' + P.fmtSize(o.blob.size) + ')'));
      if (o.info) box.append(h('div', { class: 'res-info', text: o.info }));
    } else {
      const list = h('div', { class: 'res-list' });
      outs.forEach((o) => { const row = h('div', { class: 'res-row' }, h('div', { class: 'res-name' }, h('strong', { text: o.name }), h('small', { text: P.fmtSize(o.blob.size) + (o.info ? ' \u00b7 ' + o.info : '') })), h('button', { class: 'secondary sm', type: 'button', onclick: () => P.downloadBlob(o.blob, o.name) }, 'Download')); list.append(row); });
      box.append(list);
      const zipBtn = h('button', { class: 'primary dl-main', type: 'button' }, '\u2b07 Download all as ZIP');
      zipBtn.onclick = async () => { zipBtn.disabled = true; const old = zipBtn.textContent; zipBtn.textContent = 'Preparing ZIP\u2026'; try { const z = await P.zip(outs, (S.tool.zipName || 'PDFora-files') + '.zip'); P.downloadBlob(z.blob, z.name); } catch (e) { say('Could not create ZIP: ' + e.message, 'error'); } zipBtn.disabled = false; zipBtn.textContent = old; };
      box.append(zipBtn);
    }
    const notes = [...ctx.warn ? S.warnings : []]; if (S.errors.length) notes.unshift('Some files could not be processed:\n' + S.errors.join('\n'));
    if (notes.length) box.append(h('div', { class: 'status ' + (S.errors.length ? 'error' : 'warn'), style: 'display:block', text: notes.join('\n') }));
    const again = h('button', { class: 'secondary sm', type: 'button', text: 'Start over', onclick: () => { S.files = []; S.active = null; clearResults(); say(''); S.prog.hidden = true; filesChanged(); } });
    box.append(h('div', { class: 'again' }, again));
    box.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  /* drag & drop files onto the open tool */
  ['dragover', 'drop'].forEach((ev) => modal.addEventListener(ev, (e) => { if (!S) return; if (e.dataTransfer && [...e.dataTransfer.types].includes('Files')) { e.preventDefault(); if (ev === 'drop') addFiles([...e.dataTransfer.files]); } }));

  /* ---------------- boot ---------------- */
  function route() {
    const slug = decodeURIComponent((location.hash || '').replace(/^#/, ''));
    if (slug && P.tools.some((t) => t.slug === slug)) { if (!S || S.tool.slug !== slug) openTool(slug, false); }
    else if (S) closeTool(true);
  }
  function boot() {
    buildGrid();
    $('search').addEventListener('input', filterTools);
    $('search').addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); const first = P.tools.find((t) => t.card.style.display !== 'none'); const q = $('search').value.trim(); if (first && q) { location.hash = '#' + first.slug; } } });
    $('searchBtn').addEventListener('click', () => { filterTools(); const q = $('search').value.trim(); const first = P.tools.find((t) => t.card.style.display !== 'none'); if (q && first) $('tools').scrollIntoView({ behavior: 'smooth', block: 'start' }); });
    $('closeBtn').addEventListener('click', () => closeTool(false));
    $('closeX').addEventListener('click', () => $('closeBtn').click());
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && S) $('closeBtn').click(); });
    modal.addEventListener('mousedown', (e) => { if (e.target === modal && S && !S.busy && !S.files.length) $('closeBtn').click(); });
    grid.addEventListener('click', (e) => { const a = e.target.closest('a.tool'); if (a) { e.preventDefault(); openTool(a.dataset.slug, true); } });
    $('homeLink').addEventListener('click', (e) => { e.preventDefault(); if (S) closeTool(false); window.scrollTo({ top: 0, behavior: 'smooth' }); });
    window.addEventListener('popstate', route); window.addEventListener('hashchange', route);
    $('toolCount').textContent = P.tools.length + ' handy tools';
    route();
  }
  document.addEventListener('DOMContentLoaded', () => { if (P.tools) boot(); });
})(window);
