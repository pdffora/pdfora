# Deploy PDFora on Cloudflare (free plan is enough)

PDFora is now a **Cloudflare Workers project with static assets**:
- `public/` = the whole website and your 25 tools, served by Cloudflare's static-assets layer (free, unlimited, no code runs).
- `src/worker.mjs` = a small Worker that only handles `/api/*` and `/auth/*` (Google login, daily limits, Stripe, contact form).
- **D1** = Cloudflare's free SQLite database for accounts, daily usage counts and subscription status. Your documents are never stored.

> **Important: Do not use Cloudflare’s “upload assets/direct upload” screen.** It does not support this project because it includes a Wrangler Worker configuration and a build step. Use GitHub repository deployment or the Wrangler CLI. If you earlier created a Pages project from the old ZIP, use a Worker project instead.

## What was wrong before
1. No Cloudflare configuration existed (`wrangler.jsonc` was missing), so Cloudflare did not know where the site's files were.
2. The backend was a Node server (`http`, `fs`, `node:sqlite`), which Cloudflare Workers cannot run.
3. Clean URLs such as `/merge-pdf` only worked because that Node server translated them to `merge-pdf.html`; on Cloudflare they need the `html_handling` setting, which is now set.

## Deploy using Wrangler (command-line method)
You need a free Cloudflare account and Node.js 20+ on a computer. The dashboard direct-upload method is not supported for this project.

1. Unzip the project, open a terminal in the `PDFora` folder and run: `npm install`
2. Log in: `npx wrangler login`
3. Create the database: `npx wrangler d1 create pdfora`
   Copy the `database_id` it prints and paste it into `wrangler.jsonc` (replace `PASTE_YOUR_D1_DATABASE_ID_HERE`). Tables are created automatically on first use.
4. Open `wrangler.jsonc` and edit the `vars` block: `SITE_URL` (your final https address, e.g. `https://www.yourdomain.com`; if you do not have a domain yet use the `https://pdfora.<your-subdomain>.workers.dev` address Cloudflare will print on first deploy, then change it later), `SUPPORT_EMAIL`, `COMPANY_NAME`, and later the Google/Stripe IDs from steps B and C below.
5. Deploy: `npm run deploy` (this builds all pages with your `SITE_URL`, then uploads the site and Worker).
6. Open the address it prints. Browse `/merge-pdf`, refresh the page, open a tool link directly — all work.
7. Add the three **secrets** (never put these in a file): 
   `npx wrangler secret put GOOGLE_CLIENT_SECRET`
   `npx wrangler secret put STRIPE_SECRET_KEY`
   `npx wrangler secret put STRIPE_WEBHOOK_SECRET`
   (or in the dashboard: Workers & Pages → pdfora → Settings → Variables and Secrets → type **Secret**).
8. Custom domain (optional): dashboard → Workers & Pages → pdfora → Settings → Domains & Routes → Add → Custom domain. Then set `SITE_URL` to it and run `npm run deploy` again.

### Deploy from GitHub (recommended if using Cloudflare dashboard)
1. Put the complete `PDFora` folder contents in a GitHub repository (the repository root must contain `package.json`, `wrangler.jsonc`, `src/`, `scripts/`, and `public/`; do not upload only the `public` folder).
2. Cloudflare dashboard → **Workers & Pages** → **Create** → **Import a repository**. Select that GitHub repository.
3. In the build/deployment settings, use **Build command:** `npm run build` and **Deploy command:** `npx wrangler deploy`. Leave the root directory blank if the repository root is the PDFora project; if PDFora is inside a subfolder, set the root directory to that folder.
4. Before the first deploy, replace the D1 `database_id` placeholder in `wrangler.jsonc` with the ID of a D1 database named `pdfora`. Create the database in Cloudflare dashboard → Workers & Pages → D1, or with `npx wrangler d1 create pdfora`.
5. Set `SITE_URL` to the Cloudflare `workers.dev` URL you will use. Set `GOOGLE_CLIENT_ID` after you create the Google OAuth client. Store `GOOGLE_CLIENT_SECRET`, `STRIPE_SECRET_KEY`, and `STRIPE_WEBHOOK_SECRET` as **Secrets**, not ordinary variables.
6. Deploy. If the deployment fails, share the exact build/deploy error; do not switch back to Direct Upload.

**GitHub deployment still needs the D1 database ID and OAuth/payment setup.** Direct Upload cannot run this Worker, Google sign-in, account/usage API, or Stripe backend.

## A. Environment variables — where each one goes
| Name | Where | Needed for |
|---|---|---|
| `SITE_URL`, `SUPPORT_EMAIL`, `COMPANY_NAME`, `GOVERNING_LAW` | `wrangler.jsonc` → `vars` | page canonical links, sitemap, legal pages |
| `PRO_DAILY_LIMIT` | `vars` (default 300) | Pro daily allowance |
| `GOOGLE_CLIENT_ID` | `vars` | Continue with Google |
| `GOOGLE_CLIENT_SECRET` | **secret** | Continue with Google |
| `STRIPE_PRICE_MONTHLY`, `STRIPE_PRICE_YEARLY` | `vars` | checkout |
| `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET` | **secret** | checkout + webhooks |

Until these are set the site still works: tools are browsable, and login/pricing say clearly that sign-in/payments are not configured yet.
Changing a `vars` value needs `npm run deploy` again; secrets take effect immediately.

## B. Google sign-in
Google Cloud Console → APIs & Services → Credentials → Create OAuth client ID → *Web application*.
Authorized redirect URI: `https://YOUR-ADDRESS/auth/google/callback` (add both your workers.dev address and custom domain if you use both).
Put the Client ID in `vars` and the Client secret as a secret.

## C. Stripe payments
1. In Stripe create product **PDFora Pro** with two recurring USD prices: $9.99/month and $71.99/year; copy the two `price_…` IDs into `vars`.
2. Developers → Webhooks → Add endpoint: `https://YOUR-ADDRESS/api/stripe/webhook`, events: `checkout.session.completed`, `customer.subscription.created`, `customer.subscription.updated`, `customer.subscription.deleted`, `invoice.paid`, `invoice.payment_failed`. Put the signing secret in `STRIPE_WEBHOOK_SECRET`; the API secret key in `STRIPE_SECRET_KEY`.
3. Stripe → Settings → Billing → Customer portal: enable it (cancellation, payment methods).
4. Test first with Stripe **test mode** keys and card `4242 4242 4242 4242`.
5. In Cloudflare, do not add a WAF/bot rule that blocks `/api/stripe/webhook`.

## D. Everyday tasks
- Read contact-form messages: `npm run messages`
- Run locally: copy `.dev.vars.example` to `.dev.vars`, then `npm run dev` (uses a local test database).
- Update the site: edit, then `npm run deploy`.

## E. Free-plan limits (and when you might pay)
Static pages and tool files cost nothing and are unlimited. The Worker is invoked only for login, usage and billing calls (free plan: 100,000 requests/day), and D1's free tier is far above what these small queries need. Nothing in this setup requires a paid plan; Cloudflare's $5/month Workers Paid plan is only worth considering at very large traffic.

## F. What was and was not tested
Tested here (69 Worker/routing checks, 37 browser checks, 8 tool runs, all passing): the real Worker code and the Cloudflare settings (clean URLs, refresh/direct links for all 25 tools, 404 page, `_headers`, only `/api` `/auth` reaching the Worker) against an emulation of Cloudflare's static assets and a SQLite-backed D1 stand-in with fake Google and Stripe servers.
**Not possible in my environment:** running the real `wrangler`/Cloudflare runtime, a real Google login, or a real Stripe payment. After deploying, do this 5-minute check: open `/merge-pdf` directly and refresh; log in with Google; run one tool; open `/pricing` and complete one Stripe test-mode checkout; confirm the Subscription page shows Pro. If `wrangler deploy` reports an error, send me the exact message.
