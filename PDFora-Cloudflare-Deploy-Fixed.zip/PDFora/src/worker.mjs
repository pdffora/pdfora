/* PDFora Worker: login (Google), daily limits, Stripe billing, contact form and account API.
   Static pages/tools are served by Cloudflare's static-assets layer; only /api/* and /auth/* reach this code.
   Uses only Web-standard APIs + the D1 binding (env.DB). No Node modules, no npm packages. */

const enc = new TextEncoder();
const now = () => Math.floor(Date.now() / 1000);
const today = () => new Date().toISOString().slice(0, 10); // usage days are UTC days
const int = (v, d) => { const n = parseInt(v, 10); return Number.isFinite(n) && n > 0 ? n : d; };
const toHex = (buf) => [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');
const b64url = (bytes) => btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const rand = (n) => b64url(crypto.getRandomValues(new Uint8Array(n)));
const sha256 = async (s) => crypto.subtle.digest('SHA-256', enc.encode(s));
const sha256hex = async (s) => toHex(await sha256(s));
function timingEq(a, b) { if (a.length !== b.length) return false; let d = 0; for (let i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i); return d === 0; }

/* ---------------- config (from wrangler.jsonc vars + secrets) ---------------- */
function configFor(env, url) {
  const c = {
    origin: url.origin,                           // the host the visitor is actually on (workers.dev or your custom domain)
    secure: url.protocol === 'https:',
    freeLimit: 3, proLimit: int(env.PRO_DAILY_LIMIT, 300), maxReleasesPerDay: 25, sessionIdleDays: 14, sessionAbsoluteDays: 60,
    google: { id: env.GOOGLE_CLIENT_ID || '', secret: env.GOOGLE_CLIENT_SECRET || '', authUrl: env.GOOGLE_AUTH_URL || 'https://accounts.google.com/o/oauth2/v2/auth', tokenUrl: env.GOOGLE_TOKEN_URL || 'https://oauth2.googleapis.com/token' },
    stripe: { key: env.STRIPE_SECRET_KEY || '', whsec: env.STRIPE_WEBHOOK_SECRET || '', monthly: env.STRIPE_PRICE_MONTHLY || '', yearly: env.STRIPE_PRICE_YEARLY || '', base: env.STRIPE_API_BASE || 'https://api.stripe.com' }
  };
  c.googleReady = !!(c.google.id && c.google.secret);
  c.stripeReady = !!(c.stripe.key && c.stripe.whsec && c.stripe.monthly && c.stripe.yearly);
  c.sid = c.secure ? '__Host-pdfora_sid' : 'pdfora_sid'; c.oauthCookie = c.secure ? '__Host-pdfora_oauth' : 'pdfora_oauth';
  return c;
}

/* ---------------- responses ---------------- */
const SEC = { 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'strict-origin-when-cross-origin', 'X-Frame-Options': 'DENY', 'Cache-Control': 'no-store', 'Strict-Transport-Security': 'max-age=31536000; includeSubDomains' };
function json(status, obj, cookies) { const h = new Headers(Object.assign({ 'Content-Type': 'application/json; charset=utf-8' }, SEC)); (cookies || []).forEach((c) => h.append('Set-Cookie', c)); return new Response(JSON.stringify(obj), { status, headers: h }); }
function redirect(to, cookies) { const h = new Headers(Object.assign({ Location: to }, SEC)); (cookies || []).forEach((c) => h.append('Set-Cookie', c)); return new Response(null, { status: 302, headers: h }); }

/* ---------------- D1 helpers + schema ---------------- */
const SCHEMA = [
  `CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT, google_sub TEXT UNIQUE NOT NULL, email TEXT NOT NULL, name TEXT, picture TEXT, stripe_customer_id TEXT UNIQUE, created_at INTEGER NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, created_at INTEGER NOT NULL, last_seen INTEGER NOT NULL, expires_at INTEGER NOT NULL)`,
  `CREATE INDEX IF NOT EXISTS sessions_user ON sessions(user_id)`,
  `CREATE TABLE IF NOT EXISTS oauth_states(state TEXT PRIMARY KEY, verifier TEXT NOT NULL, nonce TEXT NOT NULL, next TEXT NOT NULL, expires_at INTEGER NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS usage_ops(id TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, day TEXT NOT NULL, tool TEXT NOT NULL, state TEXT NOT NULL, created_at INTEGER NOT NULL, resolved_at INTEGER)`,
  `CREATE INDEX IF NOT EXISTS usage_user_day ON usage_ops(user_id, day, state)`,
  `CREATE TABLE IF NOT EXISTS subscriptions(user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE, stripe_subscription_id TEXT, price_id TEXT, plan TEXT, status TEXT NOT NULL, current_period_end INTEGER, cancel_at_period_end INTEGER NOT NULL DEFAULT 0, payment_failed INTEGER NOT NULL DEFAULT 0, event_ts INTEGER NOT NULL DEFAULT 0, updated_at INTEGER NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS stripe_events(id TEXT PRIMARY KEY, type TEXT, received_at INTEGER NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS contact_messages(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, email TEXT, message TEXT, created_at INTEGER NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS rate_limits(k TEXT PRIMARY KEY, win INTEGER NOT NULL, n INTEGER NOT NULL)`
];
let schemaReady = null;
const ensureSchema = (env) => (schemaReady = schemaReady || env.DB.batch(SCHEMA.map((s) => env.DB.prepare(s))).catch((e) => { schemaReady = null; throw e; }));
const first = (env, sql, ...a) => env.DB.prepare(sql).bind(...a).first();
const run = (env, sql, ...a) => env.DB.prepare(sql).bind(...a).run();
const stmt = (env, sql, ...a) => env.DB.prepare(sql).bind(...a);

/* A counter that survives across Worker isolates (stored in D1). Returns true when over the limit. */
async function limited(env, key, max, windowSec) {
  const win = Math.floor(now() / windowSec);
  await run(env, `INSERT INTO rate_limits(k,win,n) VALUES(?, ?, 1) ON CONFLICT(k) DO UPDATE SET n=CASE WHEN win=? THEN n+1 ELSE 1 END, win=?`, key, win, win, win);
  const r = await first(env, 'SELECT n FROM rate_limits WHERE k=?', key);
  return r.n > max;
}

/* ---------------- cookies, sessions ---------------- */
function parseCookies(req) { const o = {}; (req.headers.get('Cookie') || '').split(';').forEach((p) => { const i = p.indexOf('='); if (i > 0) { try { o[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim()); } catch (e) { /* ignore */ } } }); return o; }
const cookie = (c, name, value, maxAge) => name + '=' + encodeURIComponent(value) + '; Path=/; HttpOnly; SameSite=Lax; Max-Age=' + maxAge + (c.secure ? '; Secure' : '');
const clearCookies = (c) => [cookie(c, c.sid, '', 0), cookie(c, c.oauthCookie, '', 0)];
function safeNext(n) { if (typeof n !== 'string' || !/^\/[A-Za-z0-9\-_/.?=&%#]*$/.test(n) || n.startsWith('//') || n.includes('..')) return '/'; return n; }

async function currentUser(env, c, req) {
  const token = parseCookies(req)[c.sid]; if (!token) return null; const t = now(), th = await sha256hex(token);
  const s = await first(env, 'SELECT s.*, u.id AS uid, u.email, u.name, u.stripe_customer_id FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=?', th);
  if (!s || s.expires_at <= t || s.created_at + c.sessionAbsoluteDays * 86400 <= t) { if (s) await run(env, 'DELETE FROM sessions WHERE token_hash=?', th); return null; }
  if (t - s.last_seen > 3600) await run(env, 'UPDATE sessions SET last_seen=?, expires_at=? WHERE token_hash=?', t, Math.min(t + c.sessionIdleDays * 86400, s.created_at + c.sessionAbsoluteDays * 86400), th);
  return { id: s.uid, email: s.email, name: s.name, stripeCustomerId: s.stripe_customer_id };
}
async function createSession(env, c, userId) {
  const token = rand(32), t = now();
  await run(env, 'INSERT INTO sessions(token_hash,user_id,created_at,last_seen,expires_at) VALUES(?,?,?,?,?)', await sha256hex(token), userId, t, t, t + c.sessionIdleDays * 86400);
  return cookie(c, c.sid, token, c.sessionIdleDays * 86400);
}

/* ---------------- entitlement + usage (all enforced here, per account, per UTC day) ---------------- */
async function entitlement(env, userId) {
  const s = await first(env, 'SELECT * FROM subscriptions WHERE user_id=?', userId);
  // "past_due" is deliberately NOT entitled: on a failed renewal Stripe already advances the period end, which would give a free period.
  const pro = !!(s && ['active', 'trialing'].includes(s.status) && s.current_period_end && s.current_period_end > now());
  return { pro, plan: pro ? 'pro' : 'free', interval: pro ? s.plan : null, sub: s };
}
const limitFor = (c, ent) => (ent.pro ? c.proLimit : c.freeLimit);
async function usageSummary(env, c, userId, ent) {
  ent = ent || await entitlement(env, userId); const limit = limitFor(c, ent);
  const used = (await first(env, "SELECT COUNT(*) c FROM usage_ops WHERE user_id=? AND day=? AND state IN ('reserved','committed')", userId, today())).c;
  return { limit, used, remaining: Math.max(0, limit - used), resetsAt: new Date(new Date(today() + 'T00:00:00Z').getTime() + 86400000).toISOString() };
}
async function reserveOp(env, c, userId, tool) {
  const ent = await entitlement(env, userId), limit = limitFor(c, ent), day = today(), id = toHex(crypto.getRandomValues(new Uint8Array(16)));
  // One atomic statement: insert only while the account is under its limit (D1 serialises writes, so concurrent requests cannot overshoot).
  const r = await run(env, `INSERT INTO usage_ops(id,user_id,day,tool,state,created_at) SELECT ?,?,?,?,'reserved',? WHERE (SELECT COUNT(*) FROM usage_ops WHERE user_id=? AND day=? AND state IN ('reserved','committed')) < ?`, id, userId, day, String(tool).slice(0, 60), now(), userId, day, limit);
  const usage = await usageSummary(env, c, userId, ent);
  return r.meta.changes === 1 ? { ok: true, id, usage, plan: ent.plan } : { ok: false, usage, plan: ent.plan };
}
async function resolveOp(env, c, userId, id, to) {
  id = String(id || '');
  const r = to === 'committed'
    ? await run(env, "UPDATE usage_ops SET state='committed', resolved_at=? WHERE id=? AND user_id=? AND state='reserved'", now(), id, userId)
    : await run(env, `UPDATE usage_ops SET state='released', resolved_at=? WHERE id=? AND user_id=? AND state='reserved'
        AND (SELECT COUNT(*) FROM usage_ops WHERE user_id=? AND day=(SELECT day FROM usage_ops WHERE id=?) AND state='released') < ?`, now(), id, userId, userId, id, c.maxReleasesPerDay);
  if (r.meta.changes === 1) return { ok: true, usage: await usageSummary(env, c, userId) };
  const op = await first(env, 'SELECT state FROM usage_ops WHERE id=? AND user_id=?', id, userId);
  if (!op) return { ok: false, code: 404 };
  if (op.state !== 'reserved') return { ok: true, already: true, usage: await usageSummary(env, c, userId) };
  return { ok: false, code: 429 }; // refund cap reached: the operation stays counted
}

/* ---------------- Google sign-in (code flow + PKCE + state + nonce) ---------------- */
async function googleStart(env, c, url) {
  if (!c.googleReady) return redirect('/login?error=not_configured');
  if (await limited(env, 'auth:' + (await ipKey(url._req)), 30, 600)) return json(429, { error: 'rate_limited' });
  const state = rand(24), verifier = rand(48), nonce = rand(16), challenge = b64url(await sha256(verifier));
  await run(env, 'INSERT INTO oauth_states(state,verifier,nonce,next,expires_at) VALUES(?,?,?,?,?)', state, verifier, nonce, safeNext(url.searchParams.get('next')), now() + 600);
  const p = new URLSearchParams({ response_type: 'code', client_id: c.google.id, redirect_uri: c.origin + '/auth/google/callback', scope: 'openid email profile', state, nonce, code_challenge: challenge, code_challenge_method: 'S256', prompt: 'select_account' });
  return redirect(c.google.authUrl + '?' + p.toString(), [cookie(c, c.oauthCookie, state, 600)]);
}
async function googleCallback(env, c, req, url) {
  const fail = (code) => redirect('/login?error=' + code, [cookie(c, c.oauthCookie, '', 0)]);
  if (!c.googleReady) return fail('not_configured');
  if (url.searchParams.get('error')) return fail('denied');
  const state = url.searchParams.get('state') || '', code = url.searchParams.get('code') || '', bound = parseCookies(req)[c.oauthCookie];
  if (!state || !code || !bound || !timingEq(bound, state)) return fail('state');
  const row = await first(env, 'SELECT * FROM oauth_states WHERE state=?', state);
  await run(env, 'DELETE FROM oauth_states WHERE state=?', state); // single use
  if (!row || row.expires_at <= now()) return fail('state');
  let tok;
  try {
    const r = await fetch(c.google.tokenUrl, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ code, client_id: c.google.id, client_secret: c.google.secret, redirect_uri: c.origin + '/auth/google/callback', grant_type: 'authorization_code', code_verifier: row.verifier }).toString() });
    tok = await r.json(); if (!r.ok || !tok.id_token) throw new Error('token exchange failed');
  } catch (e) { console.error('[auth] token exchange failed:', e.message); return fail('google'); }
  let claims;
  try { const seg = tok.id_token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/'); claims = JSON.parse(new TextDecoder().decode(Uint8Array.from(atob(seg + '='.repeat((4 - seg.length % 4) % 4)), (ch) => ch.charCodeAt(0)))); } catch (e) { return fail('google'); }
  // The ID token came straight from Google's token endpoint over TLS; every claim that matters is still validated.
  const okIss = claims.iss === 'https://accounts.google.com' || claims.iss === 'accounts.google.com';
  if (!okIss || claims.aud !== c.google.id || !(claims.exp > now()) || claims.nonce !== row.nonce || !claims.sub || !claims.email || claims.email_verified !== true) return fail('google');
  const email = String(claims.email).toLowerCase(), sub = String(claims.sub);
  await run(env, `INSERT INTO users(google_sub,email,name,created_at) VALUES(?,?,?,?) ON CONFLICT(google_sub) DO UPDATE SET email=excluded.email, name=excluded.name`, sub, email, claims.name || null, now());
  const u = await first(env, 'SELECT id FROM users WHERE google_sub=?', sub);
  return redirect(row.next, [await createSession(env, c, u.id), cookie(c, c.oauthCookie, '', 0)]);
}

/* ---------------- Stripe (REST, no SDK). Pro comes ONLY from signature-verified webhooks or subscriptions fetched with our key. ---------------- */
function flatten(obj, prefix, out) { out = out || new URLSearchParams(); for (const k of Object.keys(obj)) { const v = obj[k], key = prefix ? prefix + '[' + k + ']' : k; if (v == null) continue; if (typeof v === 'object') flatten(v, key, out); else out.append(key, String(v)); } return out; }
async function stripe(c, method, path, body) {
  const r = await fetch(c.stripe.base + path, { method, headers: { Authorization: 'Bearer ' + c.stripe.key, 'Content-Type': 'application/x-www-form-urlencoded' }, body: body ? flatten(body).toString() : undefined });
  const j = await r.json().catch(() => ({})); if (!r.ok) { const e = new Error((j.error && j.error.message) || 'Stripe error'); e.status = r.status; throw e; } return j;
}
const planOf = (c, priceId) => (priceId === c.stripe.monthly ? 'monthly' : priceId === c.stripe.yearly ? 'yearly' : null);
async function verifySignature(raw, header, secret, tolerance) {
  if (!header || !secret) return false; const parts = {};
  String(header).split(',').forEach((kv) => { const i = kv.indexOf('='); if (i > 0) { const k = kv.slice(0, i).trim(); (parts[k] = parts[k] || []).push(kv.slice(i + 1).trim()); } });
  const t = parseInt((parts.t || [])[0], 10); if (!t || Math.abs(now() - t) > (tolerance || 300)) return false;
  const key = await crypto.subtle.importKey('raw', enc.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const expected = toHex(await crypto.subtle.sign('HMAC', key, enc.encode(t + '.' + raw)));
  return (parts.v1 || []).some((sig) => timingEq(sig, expected));
}
async function userForSub(env, sub) {
  const uid = sub.metadata && parseInt(sub.metadata.user_id, 10);
  if (uid) { const u = await first(env, 'SELECT id FROM users WHERE id=?', uid); if (u) return u.id; }
  const cust = typeof sub.customer === 'string' ? sub.customer : sub.customer && sub.customer.id;
  const u = cust && await first(env, 'SELECT id FROM users WHERE stripe_customer_id=?', cust);
  return u ? u.id : null;
}
async function applySubscription(env, c, sub, eventTs) {
  if (!sub || !sub.id || !sub.status) return null;
  const userId = await userForSub(env, sub); if (!userId) return null;
  const item = sub.items && sub.items.data && sub.items.data[0], priceId = item && item.price && item.price.id;
  const cpe = sub.current_period_end || (item && item.current_period_end) || null; // newer API versions put it on the item
  const cancelling = (sub.cancel_at_period_end || sub.cancel_at) ? 1 : 0, cust = typeof sub.customer === 'string' ? sub.customer : sub.customer && sub.customer.id, ts = eventTs || 0;
  const prev = await first(env, 'SELECT event_ts FROM subscriptions WHERE user_id=?', userId);
  if (prev && ts && prev.event_ts > ts) return userId; // an older event arrived late
  await env.DB.batch([
    stmt(env, 'UPDATE users SET stripe_customer_id=? WHERE id=? AND (stripe_customer_id IS NULL OR stripe_customer_id=?)', cust || null, userId, cust || null),
    stmt(env, `INSERT INTO subscriptions(user_id,stripe_subscription_id,price_id,plan,status,current_period_end,cancel_at_period_end,payment_failed,event_ts,updated_at) VALUES(?,?,?,?,?,?,?,0,?,?)
      ON CONFLICT(user_id) DO UPDATE SET stripe_subscription_id=excluded.stripe_subscription_id, price_id=excluded.price_id, plan=excluded.plan, status=excluded.status,
        current_period_end=excluded.current_period_end, cancel_at_period_end=excluded.cancel_at_period_end, event_ts=MAX(subscriptions.event_ts, excluded.event_ts), updated_at=excluded.updated_at`,
      userId, sub.id, priceId || null, planOf(c, priceId), sub.status, cpe, cancelling, ts, now())
  ]);
  return userId;
}
const subIdOfInvoice = (inv) => inv.subscription || (inv.parent && inv.parent.subscription_details && inv.parent.subscription_details.subscription) || null;
async function handleEvent(env, c, ev) {
  const o = ev.data && ev.data.object; if (!o) return;
  switch (ev.type) {
    case 'checkout.session.completed': {
      if (o.mode !== 'subscription' || !o.subscription) return;
      const uid = parseInt(o.client_reference_id, 10);
      if (uid && o.customer) await run(env, 'UPDATE users SET stripe_customer_id=? WHERE id=? AND stripe_customer_id IS NULL', o.customer, uid);
      const sub = await stripe(c, 'GET', '/v1/subscriptions/' + encodeURIComponent(typeof o.subscription === 'string' ? o.subscription : o.subscription.id));
      sub.metadata = Object.assign({}, sub.metadata, uid ? { user_id: String(uid) } : {}); await applySubscription(env, c, sub, 0); break;
    }
    case 'customer.subscription.created': case 'customer.subscription.updated': case 'customer.subscription.deleted': await applySubscription(env, c, o, ev.created); break;
    case 'invoice.paid': case 'invoice.payment_succeeded': {
      const sid = subIdOfInvoice(o); if (!sid) return;
      const sub = await stripe(c, 'GET', '/v1/subscriptions/' + encodeURIComponent(sid)), uid = await applySubscription(env, c, sub, 0);
      if (uid) await run(env, 'UPDATE subscriptions SET payment_failed=0 WHERE user_id=?', uid); break;
    }
    case 'invoice.payment_failed': { const sid = subIdOfInvoice(o); if (sid) await run(env, 'UPDATE subscriptions SET payment_failed=1, updated_at=? WHERE stripe_subscription_id=?', now(), sid); break; }
    default: break;
  }
}
async function webhook(env, c, req) {
  if (!c.stripeReady) return json(503, { error: 'payments_not_configured' });
  const raw = await req.text();
  if (!(await verifySignature(raw, req.headers.get('Stripe-Signature'), c.stripe.whsec))) return json(400, { error: 'bad_signature' });
  let ev; try { ev = JSON.parse(raw); } catch (e) { return json(400, { error: 'bad_json' }); }
  if (await first(env, 'SELECT 1 AS x FROM stripe_events WHERE id=?', ev.id)) return json(200, { received: true, duplicate: true });
  try { await handleEvent(env, c, ev); } catch (e) { console.error('[stripe] webhook failed:', ev.type, e.message); return json(500, { error: 'processing_failed' }); } // Stripe retries on 5xx
  await run(env, 'INSERT OR IGNORE INTO stripe_events(id,type,received_at) VALUES(?,?,?)', ev.id, ev.type, now());
  return json(200, { received: true });
}
async function billingAction(env, c, user, path, req) {
  if (path === '/api/billing/checkout') {
    const plan = (await readJson(req)).plan, price = plan === 'yearly' ? c.stripe.yearly : plan === 'monthly' ? c.stripe.monthly : null;
    if (!price) return json(400, { error: 'bad_plan' });
    if ((await entitlement(env, user.id)).pro) return json(409, { error: 'already_subscribed' });
    const body = { mode: 'subscription', line_items: { 0: { price, quantity: 1 } }, client_reference_id: String(user.id), metadata: { user_id: String(user.id) }, subscription_data: { metadata: { user_id: String(user.id) } }, success_url: c.origin + '/subscription?checkout=success', cancel_url: c.origin + '/pricing?checkout=cancelled', allow_promotion_codes: 'true' };
    if (user.stripeCustomerId) body.customer = user.stripeCustomerId; else body.customer_email = user.email;
    return json(200, { url: (await stripe(c, 'POST', '/v1/checkout/sessions', body)).url });
  }
  if (path === '/api/billing/portal') {
    if (!user.stripeCustomerId) return json(404, { error: 'no_customer' });
    return json(200, { url: (await stripe(c, 'POST', '/v1/billing_portal/sessions', { customer: user.stripeCustomerId, return_url: c.origin + '/subscription' })).url });
  }
  if (path === '/api/billing/cancel' || path === '/api/billing/resume') {
    const row = await first(env, 'SELECT stripe_subscription_id FROM subscriptions WHERE user_id=?', user.id);
    if (!row || !row.stripe_subscription_id) return json(404, { error: 'no_subscription' });
    const sub = await stripe(c, 'POST', '/v1/subscriptions/' + encodeURIComponent(row.stripe_subscription_id), { cancel_at_period_end: path.endsWith('cancel') ? 'true' : 'false' });
    sub.metadata = Object.assign({}, sub.metadata, { user_id: String(user.id) }); await applySubscription(env, c, sub, 0);
    return json(200, { ok: true });
  }
  return json(404, { error: 'not_found' });
}

/* ---------------- API router ---------------- */
async function readJson(req) { const t = await req.text(); if (t.length > 20000) throw Object.assign(new Error('too large'), { status: 413 }); if (!t) return {}; try { return JSON.parse(t); } catch (e) { throw Object.assign(new Error('bad json'), { status: 400 }); } }
const ipKey = async (req) => (await sha256hex((req && req.headers.get('CF-Connecting-IP')) || 'unknown')).slice(0, 16);
const sameOrigin = (req, c) => { const o = req.headers.get('Origin'); return o ? o === c.origin : req.headers.get('Sec-Fetch-Site') !== 'cross-site'; };
async function publicUser(env, c, user) {
  const ent = await entitlement(env, user.id), s = ent.sub;
  return { user: { name: user.name, email: user.email }, plan: ent.plan, interval: ent.interval, usage: await usageSummary(env, c, user.id, ent),
    subscription: s ? { status: s.status, plan: s.plan, currentPeriodEnd: s.current_period_end, cancelAtPeriodEnd: !!s.cancel_at_period_end, paymentFailed: !!s.payment_failed, active: ent.pro } : null };
}
async function api(env, c, req, url) {
  const p = url.pathname, m = req.method;
  if (p === '/api/stripe/webhook' && m === 'POST') return webhook(env, c, req);
  if (p === '/api/config' && m === 'GET') return json(200, { google: c.googleReady, payments: c.stripeReady, freeLimit: c.freeLimit, proLimit: c.proLimit });
  if (p === '/api/contact' && m === 'POST') {
    if (!sameOrigin(req, c) || req.headers.get('X-PDFora') !== '1') return json(403, { error: 'forbidden' });
    if (await limited(env, 'contact:' + await ipKey(req), 5, 3600)) return json(429, { error: 'rate_limited' });
    const b = await readJson(req), name = String(b.name || '').trim().slice(0, 120), email = String(b.email || '').trim().slice(0, 200), message = String(b.message || '').trim();
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email) || message.length < 10 || message.length > 5000) return json(400, { error: 'invalid' });
    await run(env, 'INSERT INTO contact_messages(name,email,message,created_at) VALUES(?,?,?,?)', name, email, message, now());
    return json(200, { ok: true });
  }
  const user = await currentUser(env, c, req);
  if (p === '/api/me' && m === 'GET') return json(200, user ? await publicUser(env, c, user) : { user: null });
  if (m !== 'POST') return json(404, { error: 'not_found' });
  if (!sameOrigin(req, c) || req.headers.get('X-PDFora') !== '1') return json(403, { error: 'forbidden' }); // CSRF defence on top of SameSite cookies
  if (!user) return json(401, { error: 'login_required' });
  if (p === '/api/usage/reserve') {
    const r = await reserveOp(env, c, user.id, (await readJson(req)).tool || 'unknown');
    return r.ok ? json(200, { opId: r.id, plan: r.plan, usage: r.usage }) : json(402, { error: 'limit_reached', plan: r.plan, usage: r.usage });
  }
  if (p === '/api/usage/commit' || p === '/api/usage/release') {
    const r = await resolveOp(env, c, user.id, (await readJson(req)).opId, p.endsWith('commit') ? 'committed' : 'released');
    if (!r.ok) return json(r.code || 400, { error: r.code === 429 ? 'release_limit' : 'unknown_operation', usage: await usageSummary(env, c, user.id) });
    return json(200, { ok: true, already: !!r.already, usage: r.usage });
  }
  if (p.startsWith('/api/billing/')) {
    if (!c.stripeReady) return json(503, { error: 'payments_not_configured' });
    if (await limited(env, 'billing:' + user.id, 20, 60)) return json(429, { error: 'rate_limited' });
    try { return await billingAction(env, c, user, p, req); } catch (e) { if (e.status === 400 || e.status === 413) throw e; console.error('[billing]', e.message); return json(502, { error: 'payment_provider_error' }); }
  }
  if (p === '/api/account/delete') {
    const ent = await entitlement(env, user.id);
    if (ent.pro && !(ent.sub && ent.sub.cancel_at_period_end)) return json(409, { error: 'cancel_subscription_first' });
    await run(env, 'DELETE FROM users WHERE id=?', user.id); return json(200, { ok: true }, clearCookies(c));
  }
  return json(404, { error: 'not_found' });
}

/* ---------------- entry points ---------------- */
export default {
  async fetch(req, env) {
    const url = new URL(req.url); url._req = req;
    // Anything that is not an API/auth route belongs to the static-assets layer (pages, tools, libraries).
    const isApi = url.pathname.startsWith('/api/'), isAuth = url.pathname.startsWith('/auth/');
    if (url.pathname === '/healthz') return json(200, { ok: true });
    if (!isApi && !isAuth) return env.ASSETS ? env.ASSETS.fetch(req) : new Response('Not found', { status: 404 });
    if (!env.DB) return json(500, { error: 'database_not_configured' });
    try {
      await ensureSchema(env); const c = configFor(env, url);
      if (url.pathname === '/auth/google' && req.method === 'GET') return await googleStart(env, c, url);
      if (url.pathname === '/auth/google/callback' && req.method === 'GET') return await googleCallback(env, c, req, url);
      if (url.pathname === '/auth/logout' && req.method === 'POST') {
        if (!sameOrigin(req, c) || req.headers.get('X-PDFora') !== '1') return json(403, { error: 'forbidden' });
        const token = parseCookies(req)[c.sid]; if (token) await run(env, 'DELETE FROM sessions WHERE token_hash=?', await sha256hex(token));
        return json(200, { ok: true }, clearCookies(c));
      }
      if (isApi) return await api(env, c, req, url);
      return json(404, { error: 'not_found' });
    } catch (e) {
      console.error('[worker]', e && e.stack || e); // details stay in the Worker logs; the client gets a generic message
      return json(e && e.status ? e.status : 500, { error: e && e.status === 413 ? 'too_large' : 'server_error' });
    }
  },
  /* Daily housekeeping (cron trigger in wrangler.jsonc). */
  async scheduled(event, env) {
    await ensureSchema(env); const t = now();
    await env.DB.batch([
      stmt(env, 'DELETE FROM sessions WHERE expires_at<=?', t), stmt(env, 'DELETE FROM oauth_states WHERE expires_at<=?', t),
      stmt(env, "DELETE FROM usage_ops WHERE day < date('now','-35 days')"), stmt(env, 'DELETE FROM stripe_events WHERE received_at < ?', t - 90 * 86400),
      stmt(env, 'DELETE FROM rate_limits WHERE win < ?', Math.floor(t / 3600) - 48)
    ]);
  }
};
