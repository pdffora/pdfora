PDFora - complete website
=========================

WHAT THIS IS
A static website (HTML + CSS + JavaScript). There is no server code and no database.
All 25 tools run inside the visitor's browser, so files are never uploaded anywhere.
No internet connection or CDN is needed: every library is included in the /libs folder.

HOW TO RUN IT LOCALLY
  Option A: double-click index.html (works in Chrome, Edge, Firefox).
  Option B (recommended while developing): run a tiny local server in this folder, e.g.
      python3 -m http.server 8000      then open  http://localhost:8000

HOW TO PUBLISH IT
Upload the WHOLE folder (keep the folder structure) to any static host:
  - Netlify / Cloudflare Pages / Vercel: drag & drop the folder, or connect a Git repo.
  - GitHub Pages: push the folder, enable Pages.
  - Any web hosting (cPanel, FTP): upload everything into public_html.
Use HTTPS (every host above does by default). Protect/Unlock PDF use the browser's built-in
cryptography, which browsers only provide on https:// or localhost.
Tip: tool pages can be linked directly, e.g. https://yourdomain.com/#merge-pdf

FOLDER STRUCTURE
  index.html          the page
  css/style.css       your original design + styles for the new upload interface
  js/util.js          shared helpers (file validation, page-range parsing, PDF helpers)
  js/fonts.js         font handling (standard fonts + embedded Unicode font)
  js/pdfsec.js        PDF encryption / decryption / repair engine (AES-256, RC4, AES-128)
  js/office.js        Word/Excel readers + writers, Word->PDF and Excel->PDF engines
  js/app.js           page shell: tool grid, search, routing, shared upload UI, downloads
  js/tools-pdf.js     PDF tools        js/tools-img.js  image tools
  js/tools-ui.js      Sign PDF, Organize PDF, Image Cropper (interactive tools)
  js/tools.js         the ordered list of the 25 tools
  libs/               pdf-lib, JSZip, pdf.js (+ worker, cmaps, standard fonts)
  fonts/dejavu.js     DejaVu Sans subset, loaded only when a PDF needs non-Western text
  LICENSES.txt        third-party licences

THE 25 TOOLS - WHAT EACH ONE REALLY DOES
 1 Merge PDF            Combines PDFs in the order shown (use the arrows to reorder).
 2 Split PDF            Extract pages (1-3 / 1-3,5 / 2,4,6 / 5-) into one PDF, in the order typed,
                        or split every page into its own PDF (ZIP). Multiple files supported.
 3 Compress PDF         Re-compresses the images inside the PDF (text stays sharp). "Strong" turns
                        pages into images for the smallest size. If a file can't be made smaller you
                        are told, and the original is returned.
 4 PDF to Word          Real .docx (headings, paragraphs). Scanned pages are inserted as images.
 5 Word to PDF          Reads .docx and builds a real PDF (text, headings, lists, tables, images).
 6 PDF to Excel         Real .xlsx; tables are detected from text alignment; numbers become numbers.
 7 Excel to PDF         .xlsx / .csv -> PDF (all sheets, number/date formats, wide sheets scaled).
 8 PDF to JPG           Every page (or chosen pages) as JPG, 72/150/220 DPI, ZIP for many pages.
 9 JPG to PDF           JPG/PNG -> PDF; page size, margins; EXIF rotation respected.
10 Rotate PDF           90/180/270, all pages or a page range.
11 Protect PDF          Real AES-256 encryption with a password (optional owner password and
                        print/copy/edit permissions). Verified with qpdf, pikepdf and pdfium.
12 Unlock PDF           Removes the password/restrictions when you know the password
                        (RC4 40/128, AES-128, AES-256).
13 Sign PDF             Draw, type or upload a signature, drag it into place, apply to chosen pages.
14 Add Page Numbers     Position, format (1 / Page 1 / Page 1 of N), start number, first page.
15 Watermark PDF        Text watermark: size, opacity, angle, colour, centre or tiled, page range.
16 Organize PDF         Page thumbnails: reorder (drag or arrows), rotate, delete; can combine pages
                        from several PDFs.
17 Repair PDF           Rebuilds damaged PDFs in up to 3 stages and tells you honestly how many
                        pages were recovered.
18-24 Image tools       PNG->JPG, JPG->PNG, Image Compressor, Image Resizer, Image Cropper (drag
                        the crop box), Image to WebP, WebP->JPG.
25 Image to PDF         JPG, PNG, WebP, GIF, BMP, AVIF -> PDF.

HONEST LIMITATIONS (browser-only, no server)
 - No OCR: scanned PDFs can't be turned into editable text (PDF to Word inserts page images;
   PDF to Excel says so). OCR would need a server or a ~15 MB language download.
 - Old binary Office files (.doc, .xls) are not supported - the site tells users to save as
   .docx / .xlsx. (.docx / .xlsx / .csv are fully supported.)
 - Word to PDF / Excel to PDF re-create the layout; headers/footers, text boxes and very advanced
   Word features can differ from Microsoft Word. Chinese/Japanese/Korean/Indic text can't be drawn
   (a clear warning is shown; Latin, Greek, Cyrillic, Hebrew and Arabic letters work).
 - PDF to Word does not rebuild tables/columns; they become plain paragraphs.
 - Sign PDF adds a visual signature image, not a certificate-based digital signature.
 - Unlock PDF cannot recover a forgotten password.
 - Image to WebP needs a browser that can encode WebP (Chrome, Edge, Firefox; not Safari).
 - Very large files (hundreds of MB) depend on the visitor's device memory. Limit is 100 MB per file.

TESTING
Every tool was run in a real Chromium browser with real sample files (including damaged,
encrypted, rotated, scanned, Unicode, EXIF-rotated and 200-page files) and the downloaded
results were verified with independent tools (qpdf, pikepdf, pypdf, pdfium, python-docx,
openpyxl, Pillow). Also tested when opened directly from file:// and on phone/tablet sizes.
