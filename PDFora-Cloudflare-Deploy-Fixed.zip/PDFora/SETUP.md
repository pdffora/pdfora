# PDFora setup guide

## A. What works right now (tested)
Verified by automated tests (69 Worker/routing checks + 37 browser checks + 8 engine runs; all passing) using an emulation of Cloudflare and **fake** Google and Stripe servers:
- All 25 tools, unchanged, each on its own URL (`/merge-pdf`, `/split-pdf`, … ) with unique title, description, canonical, H1–H3, FAQ, related links, structured data
- Homepage, All tools (`/tools`), Pricing, About, Contact, Privacy Policy, Terms of Service, Login, Account, Subscription, custom 404
- `sitemap.xml` (32 URLs), `robots.txt`, Open Graph/Twitter tags, `favicon.svg`, `og-image.png`
- Visitors browse everything; using a tool requires login; typing `#tool` in the URL cannot skip the login prompt
- Google OAuth code flow with PKCE + state + nonce, secure HttpOnly sessions, CSRF protection, logout, account deletion
- Free plan: 3 successful operations/day **per account**, enforced on the server; failed operations are not counted; remaining count shown; upgrade prompt at the limit; refresh/clear-storage does not reset it
- Stripe integration code: checkout (monthly/yearly), customer portal, cancel/resume, signature-verified webhooks, idempotency, expiry by paid-through date, payment-failure handling
- Pro is granted **only** from verified Stripe data; a "success" URL alone unlocks nothing (tested)
- Clear individual file (×) and **Clear all files**, security headers + strict CSP, gzip/brotli, caching, mobile layout (no sideways scrolling)

## B. What needs YOUR accounts or decisions (not live until you do this)
| Item | What to do |
|---|---|
| **Cloudflare account + domain** | Free Cloudflare account; follow `CLOUDFLARE.md` (HTTPS is automatic). Set `SITE_URL` in `wrangler.jsonc` and redeploy. |
| **Google sign-in** | Google Cloud Console → create project → OAuth consent screen → Credentials → *OAuth client ID* (Web application). Add redirect URI `https://YOURDOMAIN/auth/google/callback`. Client ID goes in `wrangler.jsonc` vars, Client secret is stored as a Cloudflare secret (`CLOUDFLARE.md`). |
| **Stripe account** | Create/verify a Stripe account (business details, bank payout). In *Products* create **PDFora Pro** with two recurring prices in USD: **$9.99 / month** and **$71.99 / year**. Copy the price IDs (`price_…`) to `STRIPE_PRICE_MONTHLY` / `STRIPE_PRICE_YEARLY`. Put the price IDs in `wrangler.jsonc` vars; the secret key is stored as a Cloudflare secret. |
| **Stripe webhook** | Developers → Webhooks → add endpoint `https://YOURDOMAIN/api/stripe/webhook` with events: `checkout.session.completed`, `customer.subscription.created`, `customer.subscription.updated`, `customer.subscription.deleted`, `invoice.paid`, `invoice.payment_failed`. Copy the signing secret (`whsec_…`) to `STRIPE_WEBHOOK_SECRET`. |
| **Stripe customer portal** | Settings → Billing → Customer portal: enable, allow cancel, payment-method update and (optional) plan switching between your two prices. |
| **Stripe Tax / invoices** | Optional but check what tax rules apply to you when selling worldwide. |
| **Support email** | `SUPPORT_EMAIL`. Contact-form messages are stored in D1: run `npm run messages` to read them (there is no email sending). |
| **Legal text** | Privacy Policy and Terms are sensible drafts matching how the site works, **not legal advice** — have a lawyer review them, confirm `COMPANY_NAME` and `GOVERNING_LAW`, and the refund wording. |
| **Google Search Console** | Verify your domain, submit `https://YOURDOMAIN/sitemap.xml`. Nothing is indexed or verified yet; indexing takes days to weeks. |
| **Backups** | Optional: `npx wrangler d1 export pdfora --remote --output backup.sql`. |

## C. Decisions I made that you may want to change
- **Pro daily limit = 300 operations/day** (`PRO_DAILY_LIMIT`, shown on the pricing page). You gave "higher limits" without a number; nothing says "unlimited".
- Usage days reset at **00:00 UTC** (stated in the UI).
- One "operation" = one successful run of a tool's main button (a merge of many files = 1 operation).
- A Pro subscription with a **failed renewal is not Pro** (Stripe advances the period end on renewal, so trusting it would give a free period).
- Contact form stores messages in the database rather than emailing.

## D. Honest limits you should know about
1. **The tools run in the visitor's browser** (that is how you built them, and you asked me not to change them). Consequence: the daily limit is
   enforced on the server for everyone using the site normally, but a technically skilled person could still run the downloadable
   JavaScript engines offline and skip the check. Truly unbypassable limits need the processing itself on your server — a different
   architecture (and a rewrite of the tools). This design keeps the engines untouched and is the same trade-off other client-side PDF tools make.
2. **Server-side file deletion:** because files are never uploaded, there are no server copies to delete. "Clear" removes files from the browser page and
   the UI says exactly that. No server-side temp-file cleanup is needed, and none is claimed.
3. "Priority processing" and "no advertisements": the site shows no ads at all today, and processing happens on the user's own device, so there is
   no queue to prioritise. Those words are on the pricing page as you specified; reword them if you want to avoid implying something technical.
4. No OCR (scanned PDF → text) — unchanged from your tools; tool pages say so.
5. Tests used fake Google/Stripe servers. **Run one real test-mode checkout** (Stripe test keys + test card 4242 4242 4242 4242) before taking real payments.
