'use strict';
/* Generates all HTML pages, sitemap.xml, robots.txt and favicon into /public.
   Usage:  SITE_URL=https://yourdomain.com SUPPORT_EMAIL=you@yourdomain.com node scripts/build.js
   It never touches the tool engines (public/js/tools-*.js, util.js, pdfsec.js, office.js, fonts.js, app.js, tools.js, libs/, fonts/). */
const fs = require('fs'), path = require('path');
const TOOLS = require('./tools-content.js');
const OUT = path.join(__dirname, '..', 'public');
/* Settings come from environment variables, or else from the "vars" block of wrangler.jsonc (the single place to configure). */
function readWranglerVars() {
  try {
    const src = fs.readFileSync(path.join(__dirname, '..', 'wrangler.jsonc'), 'utf8'); let out = '', inStr = false;
    for (let i = 0; i < src.length; i++) {            // strip // and /* */ comments without touching "https://..." inside strings
      const ch = src[i], nx = src[i + 1];
      if (inStr) { out += ch; if (ch === '\\') { out += nx; i++; } else if (ch === '"') inStr = false; continue; }
      if (ch === '"') { inStr = true; out += ch; } else if (ch === '/' && nx === '/') { while (i < src.length && src[i] !== '\n') i++; out += '\n'; }
      else if (ch === '/' && nx === '*') { i += 2; while (i < src.length && !(src[i] === '*' && src[i + 1] === '/')) i++; i++; } else out += ch;
    }
    return JSON.parse(out.replace(/,(\s*[}\]])/g, '$1')).vars || {};
  } catch (e) { return {}; }
}
const WV = readWranglerVars(), pick = (k, d) => process.env[k] || WV[k] || d;
const SITE = pick('SITE_URL', 'http://localhost:8787').replace(/\/+$/, '');
const EMAIL = pick('SUPPORT_EMAIL', '');
const COMPANY = pick('COMPANY_NAME', 'PDFora');
const LAW = pick('GOVERNING_LAW', 'the laws of Kenya');
const YEAR = new Date().getFullYear(), TODAY = new Date().toISOString().slice(0, 10);
const NICE_DATE = new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' });
if (/yourdomain\.com|localhost/.test(SITE)) console.warn('WARNING: SITE_URL is still "' + SITE + '" - set it in wrangler.jsonc (vars) to your real https:// address so canonical links and the sitemap are correct.');
if (!EMAIL) console.warn('NOTE: SUPPORT_EMAIL is empty - Contact/Privacy/Terms will point to the contact form instead of an email address.');

const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const jsonld = (o) => '<script type="application/ld+json">' + JSON.stringify(o).replace(/</g, '\\u003c') + '</script>';
const write = (name, html) => fs.writeFileSync(path.join(OUT, name), html);
const mail = EMAIL ? '<a href="mailto:' + esc(EMAIL) + '">' + esc(EMAIL) + '</a>' : 'the contact form on our <a href="/contact">Contact page</a>';
const bySlug = Object.fromEntries(TOOLS.map((t) => [t.slug, t]));
const GROUPS = ['PDF organization', 'PDF optimization', 'PDF conversion', 'PDF editing', 'PDF security', 'Image to PDF', 'Image tools'];
const TOOL_SCRIPTS = ['libs/pdf-lib.min.js', 'libs/jszip.min.js', 'js/util.js', 'js/fonts.js', 'js/pdfsec.js', 'js/office.js', 'js/app.js', 'js/tools-pdf.js', 'js/tools-img.js', 'js/tools-ui.js', 'js/tools.js'];
const SHORT = {}; TOOLS.forEach((t) => { SHORT[t.slug] = t.intro.split(/(?<=\.)\s/)[0]; });

/* ---------------- shared chrome ---------------- */
const header = (cur) => `<a class="skip" href="#main">Skip to content</a>
<header><div class="nav"><a class="logo" href="/" aria-label="PDFora home">PDFora</a><span class="tagline">Simple tools. Better productivity.</span>
<button class="nav-toggle" id="navToggle" type="button" aria-label="Menu" aria-expanded="false" aria-controls="mainNav">&#9776;</button>
<nav class="nav-links" id="mainNav" aria-label="Main"><a class="nl" href="/tools"${cur === 'tools' ? ' aria-current="page"' : ''}>All tools</a><a class="nl" href="/pricing"${cur === 'pricing' ? ' aria-current="page"' : ''}>Pricing</a><a class="nl" href="/about"${cur === 'about' ? ' aria-current="page"' : ''}>About</a><div id="authArea"><a class="btn" href="/login">Log in</a></div></nav></div></header>`;
const footer = () => `<footer class="site-footer"><div class="fgrid"><div><h2>PDFora</h2><p style="color:#475569;line-height:1.6;font-size:14px;margin:0">Simple PDF and image tools that run privately in your browser. Free plan: 3 successful operations per day.</p></div>
<div><h2>Company</h2><ul><li><a href="/tools">All tools</a></li><li><a href="/pricing">Pricing</a></li><li><a href="/about">About us</a></li><li><a href="/contact">Contact us</a></li><li><a href="/privacy-policy">Privacy policy</a></li><li><a href="/terms-of-service">Terms of service</a></li></ul></div>
<div><h2>PDF &amp; image tools</h2><ul class="ftools">${TOOLS.map((t) => `<li><a href="/${t.slug}">${esc(t.name)}</a></li>`).join('')}</ul></div></div>
<div class="fbase">&copy; ${YEAR} ${esc(COMPANY)}. Files are processed in your browser and are not uploaded to our servers.</div></footer>`;
const decor = '<div class="decor" aria-hidden="true"><span class="butterfly b1">🦋</span><span class="butterfly b2">🦋</span><span class="butterfly b3">🦋</span><span class="star s1">✦</span><span class="star s2">✧</span><span class="star s3">✦</span><span class="star s4">✧</span></div>';
const modal = `<div class="modal" id="modal" role="dialog" aria-modal="true" aria-labelledby="modalTitle"><div class="panel" id="panel"><button class="x-close" id="closeX" type="button" aria-label="Close">×</button><h3 id="modalTitle"></h3><p id="description"></p><div id="pfQuota" class="quota" hidden></div><div id="tool"></div><div class="actions"><button class="secondary" id="closeBtn" type="button">Close</button></div></div></div><a id="homeLink" href="/" hidden>PDFora</a>`;
const searchBlock = (heading) => `<div class="section-head"><h2>${heading}</h2><span id="toolCount">25 handy tools</span></div>
<div class="search" role="search" style="max-width:560px;margin:0 0 18px"><input id="search" placeholder="Search for a tool..." aria-label="Search tools" autocomplete="off"><button id="searchBtn" type="button">Search</button></div>
<section class="tools" id="tools" aria-label="All tools"></section><div id="noResults">No tools match your search. Try &ldquo;merge&rdquo;, &ldquo;compress&rdquo; or &ldquo;image&rdquo;.</div>`;

function layout(o) {
  const url = SITE + o.path, robots = o.noindex ? '<meta name="robots" content="noindex,follow">' : '<meta name="robots" content="index,follow,max-image-preview:large">';
  const scripts = (o.tools ? TOOL_SCRIPTS : []).concat(['js/site.js'], o.tools ? ['js/gate.js'] : [], o.pageJs ? ['js/pages.js'] : []);
  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<base href="/">
<title>${esc(o.title)}</title>
<meta name="description" content="${esc(o.desc)}">
${robots}
<link rel="canonical" href="${esc(url)}">
<meta name="theme-color" content="#2563eb">
<meta property="og:site_name" content="PDFora"><meta property="og:type" content="${o.ogType || 'website'}"><meta property="og:title" content="${esc(o.title)}"><meta property="og:description" content="${esc(o.desc)}"><meta property="og:url" content="${esc(url)}">
<meta property="og:image" content="${SITE}/og-image.png"><meta property="og:image:width" content="1200"><meta property="og:image:height" content="630"><meta property="og:image:alt" content="PDFora - all your PDF tools in one place">
<meta name="twitter:card" content="summary_large_image"><meta name="twitter:title" content="${esc(o.title)}"><meta name="twitter:description" content="${esc(o.desc)}"><meta name="twitter:image" content="${SITE}/og-image.png">
<link rel="icon" href="/favicon.svg" type="image/svg+xml">
<link rel="stylesheet" href="css/style.css"><link rel="stylesheet" href="css/site.css">
${o.tools ? '<script src="js/early.js"></script>' : ''}
${(o.ld || []).map(jsonld).join('\n')}
</head>
<body${o.tool ? ` data-tool="${o.tool}"` : ''}${o.page ? ` data-page="${o.page}"` : ''}>
${decor}
${header(o.nav)}
<main id="main">${o.body}</main>
${footer()}
${o.tools ? modal : ''}
${scripts.map((s) => `<script src="${s}"></script>`).join('\n')}
</body></html>
`;
}

/* ---------------- pages ---------------- */
const crumbLd = (items) => ({ '@context': 'https://schema.org', '@type': 'BreadcrumbList', itemListElement: items.map((it, i) => ({ '@type': 'ListItem', position: i + 1, name: it[0], item: SITE + it[1] })) });
const sitemap = [];
const add = (p, pri, freq) => sitemap.push({ loc: SITE + p, pri, freq });

/* Home */
write('index.html', layout({
  path: '/', nav: 'home', tools: true,
  title: 'PDFora – Free Online PDF Tools: Merge, Split, Compress & Convert', desc: 'PDFora: 25 free online PDF and image tools. Merge, split, compress, convert, rotate, protect, unlock, sign and watermark PDFs — processed privately in your browser.',
  ld: [{ '@context': 'https://schema.org', '@type': 'Organization', name: 'PDFora', url: SITE, logo: SITE + '/favicon.svg' }, { '@context': 'https://schema.org', '@type': 'WebSite', name: 'PDFora', url: SITE }],
  body: `<section class="hero"><span class="pill">YOUR ALL-IN-ONE PDF TOOLKIT</span><h1>All your PDF tools.<br><span style="color:var(--blue)">One place.</span></h1><p>Fast, simple tools to manage your PDFs and images.</p><div class="search" role="search"><input id="search" placeholder="Search for a tool..." aria-label="Search tools" autocomplete="off"><button id="searchBtn" type="button">Search</button></div></section>
<div class="section-head"><h2>Explore all tools</h2><span id="toolCount">25 handy tools</span></div><section class="tools" id="tools" aria-label="All tools"></section><div id="noResults">No tools match your search. Try &ldquo;merge&rdquo;, &ldquo;compress&rdquo; or &ldquo;image&rdquo;.</div>
<noscript><p style="text-align:center;color:#b91c1c;padding:30px">PDFora needs JavaScript to run its tools in your browser. Please enable JavaScript and reload. You can still browse every tool in the <a href="/tools">tools list</a>.</p></noscript>
<section class="band"><h2 style="text-align:center;font-size:26px">Why people use PDFora</h2><div class="features">
<div class="feature"><h3>Private by design</h3><p>Your documents are processed inside your browser. They are not uploaded to our servers, so there is nothing for us to store or leak.</p></div>
<div class="feature"><h3>25 tools, one account</h3><p>Merge, split, compress, convert, rotate, protect, unlock, sign, watermark, number and repair PDFs — plus handy image tools.</p></div>
<div class="feature"><h3>Free to start</h3><p>Log in with Google and enjoy 3 successful operations every day on the Free plan. Upgrade to Pro when you need more.</p></div></div></section>
<section class="band content" style="max-width:none"><h2>How PDFora works</h2><ol class="steps"><li>Pick a tool from the list above or from the <a href="/tools">all tools page</a>.</li><li>Continue with Google — it takes a few seconds and needs no password.</li><li>Add your files, press the button and download the result. Only successful operations count towards your daily allowance.</li></ol>
<p>Need more than 3 operations a day? See <a href="/pricing">PDFora Pro pricing</a>.</p></section>`
}));
add('/', '1.0', 'weekly');

/* Tools hub */
write('tools.html', layout({
  path: '/tools', nav: 'tools', title: 'All PDF & Image Tools – Merge, Split, Compress, Convert | PDFora', desc: 'Browse all 25 PDFora tools: merge, split, compress, rotate, protect and sign PDFs; convert PDF to Word, Excel and JPG; plus image converters, resizer and cropper.',
  ld: [crumbLd([['Home', '/'], ['All tools', '/tools']]), { '@context': 'https://schema.org', '@type': 'ItemList', itemListElement: TOOLS.map((t, i) => ({ '@type': 'ListItem', position: i + 1, url: SITE + '/' + t.slug, name: t.name })) }],
  body: `<div class="page"><nav class="crumbs" aria-label="Breadcrumb"><a href="/">Home</a> &rsaquo; All tools</nav><h1>All PDF and image tools</h1><p>Every PDFora tool has its own page. Browse freely — you only need to log in with Google when you use a tool.</p>
${GROUPS.map((g) => { const list = TOOLS.filter((t) => t.group === g); return list.length ? `<section class="hub-group"><h2>${esc(g)}</h2><ul class="hub-grid">${list.map((t) => `<li><a href="/${t.slug}"><strong>${esc(t.name)}</strong><small>${esc(SHORT[t.slug])}</small></a></li>`).join('')}</ul></section>` : ''; }).join('')}</div>`
}));
add('/tools', '0.9', 'weekly');

/* 25 tool pages */
for (const t of TOOLS) {
  const url = '/' + t.slug;
  write(t.slug + '.html', layout({
    path: url, nav: 'tools', tools: true, tool: t.slug, title: t.title, desc: t.meta,
    ld: [crumbLd([['Home', '/'], ['All tools', '/tools'], [t.name, url]]),
      { '@context': 'https://schema.org', '@type': 'WebApplication', name: t.name + ' – PDFora', url: SITE + url, description: t.meta, applicationCategory: 'BusinessApplication', operatingSystem: 'Any (web browser)', offers: { '@type': 'Offer', price: '0', priceCurrency: 'USD' } },
      { '@context': 'https://schema.org', '@type': 'FAQPage', mainEntity: t.faq.map((f) => ({ '@type': 'Question', name: f[0], acceptedAnswer: { '@type': 'Answer', text: f[1] } })) }],
    body: `<nav class="crumbs" aria-label="Breadcrumb"><a href="/">Home</a> &rsaquo; <a href="/tools">All tools</a> &rsaquo; ${esc(t.name)}</nav>
<section class="hero" style="padding-top:12px"><span class="pill">${esc(t.group.toUpperCase())}</span><h1>${esc(t.h1)}</h1><p>${esc(t.intro)}</p>
<div class="tool-gate"><div class="gate-box"><button class="btn lg" id="openToolBtn" type="button">Continue with Google to use ${esc(t.name)}</button><p class="gate-note" id="gateNote">Free with a Google account &middot; 3 successful operations per day.</p></div></div></section>
<article class="content"><h2>How to use ${esc(t.name)}</h2><ol class="steps">${t.steps.map((s) => `<li>${esc(s)}</li>`).join('')}</ol>
<h2>Good to know</h2><h3>Your files stay on your device</h3><p>${esc(t.name)} runs inside your web browser. Your documents are not uploaded to PDFora servers. Use the × on a file, or <strong>Clear all files</strong>, to remove them from the page.</p>
<h3>What to expect</h3><p>${esc(t.tip)}</p>
<h3>Free plan and Pro</h3><p>The Free plan includes 3 successful operations per day. Failed attempts are never counted. Need more? <a href="/pricing">Compare Free and Pro</a>.</p>
<h2>Frequently asked questions</h2>${t.faq.map((f) => `<h3>${esc(f[0])}</h3><p>${esc(f[1])}</p>`).join('')}
<h2>Related tools</h2><ul class="related">${t.related.map((r) => `<li><a href="/${r}"><strong>${esc(bySlug[r].name)}</strong><small>${esc(SHORT[r])}</small></a></li>`).join('')}</ul></article>
<section class="band">${searchBlock('Explore more tools')}</section>`
  }));
  add(url, '0.8', 'monthly');
}

/* Pricing */
write('pricing.html', layout({
  path: '/pricing', nav: 'pricing', page: 'pricing', pageJs: true, title: 'PDFora Pricing – Free Plan and Pro Monthly & Yearly', desc: 'Compare PDFora plans: Free ($0, 3 successful operations per day), Pro Monthly ($9.99/month) and Pro Yearly ($71.99/year) with higher limits and no ads.',
  ld: [crumbLd([['Home', '/'], ['Pricing', '/pricing']])],
  body: `<div class="page" style="max-width:1000px"><h1 class="center">Simple pricing for everyone</h1><p class="center">Start free. Upgrade when you need a higher daily limit. Prices in US dollars; cancel any time.</p><div id="pricingMsg"></div>
<div class="pricing">
<div class="plan"><h2>Free</h2><div class="price">$0</div><div class="sub">Free forever</div><ul><li>3 successful PDF operations per day</li><li>Access to the free service</li><li>All tools available to use</li><li class="no">Higher usage limits</li><li class="no">No advertisements</li></ul><button class="btn ghost" id="freeBtn" type="button">Start free</button></div>
<div class="plan best"><span class="tag">Most flexible</span><h2>Pro Monthly</h2><div class="price">$9.99<small> / month</small></div><div class="sub">Billed monthly, cancel any time</div><ul><li>Access to all 25 PDF tools</li><li>Higher usage limits</li><li>No advertisements</li><li>Priority processing where supported</li></ul><button class="btn" data-plan="monthly" type="button">Choose Monthly</button></div>
<div class="plan"><span class="tag">Save about 40%</span><h2>Pro Yearly</h2><div class="price">$71.99<small> / year</small></div><div class="sub">That is about $6.00 per month</div><ul><li>Access to all 25 PDF tools</li><li>Higher usage limits</li><li>No advertisements</li><li>Priority processing where supported</li></ul><button class="btn" data-plan="yearly" type="button">Choose Yearly</button></div></div>
<h2>Compare plans</h2><table class="cmp"><thead><tr><th>Feature</th><th>Free</th><th>Pro Monthly</th><th>Pro Yearly</th></tr></thead><tbody>
<tr><td>Price</td><td>$0</td><td>$9.99 / month</td><td>$71.99 / year</td></tr>
<tr><td>Successful operations per day</td><td>3</td><td id="proLimitA">Higher limit</td><td id="proLimitB">Higher limit</td></tr>
<tr><td>All 25 PDF tools</td><td>Yes</td><td>Yes</td><td>Yes</td></tr><tr><td>No advertisements</td><td>—</td><td>Yes</td><td>Yes</td></tr><tr><td>Priority processing where supported</td><td>—</td><td>Yes</td><td>Yes</td></tr></tbody></table>
<h2>Pricing questions</h2><h3>What counts as an operation?</h3><p>One successful run of a tool (for example one merge, one compression run or one conversion) counts as one operation. Failed attempts are never counted. Your allowance resets every day at 00:00 UTC.</p>
<h3>How does payment work?</h3><p>Payments are handled by our payment provider, Stripe, which accepts international debit and credit cards. Your card details never touch PDFora servers. Subscriptions renew automatically until cancelled.</p>
<h3>What happens when I cancel?</h3><p>You keep Pro until the end of the period you have already paid for. After that your account returns to the Free plan.</p></div>`
}));
add('/pricing', '0.9', 'monthly');

/* About */
write('about.html', layout({
  path: '/about', nav: 'about', title: 'About PDFora – Private, Simple PDF Tools', desc: 'PDFora builds simple, private PDF and image tools that run in your browser. Learn what we offer, how we protect your files and how to reach us.',
  ld: [crumbLd([['Home', '/'], ['About', '/about']])],
  body: `<div class="page"><h1>About PDFora</h1><p>PDFora is an online toolbox of 25 PDF and image tools for students, freelancers, small businesses and anyone who works with documents. Our goal is simple: tools that are easy enough for beginners, fast enough for busy days and respectful of your privacy.</p>
<h2>Private by design</h2><p>Your files are processed inside your own browser. They are not uploaded to our servers, which means we do not store, read or share your documents. We keep only what is needed to run your account: your Google name and email, your daily usage count and your subscription status.</p>
<h2>What you can do</h2><p>Merge, split, compress, rotate, organize, repair, protect, unlock, sign, watermark and number PDFs; convert between PDF, Word, Excel, JPG and other image formats; and resize, crop or compress images. See the full list on the <a href="/tools">all tools page</a>.</p>
<h2>Honest about limits</h2><p>Because everything runs in the browser, there is no text recognition (OCR) for scanned documents, and very large files depend on your device. We tell you about limits on each tool page instead of overpromising.</p>
<h2>Get in touch</h2><p>Questions, feedback or a tool you would like to see? Visit our <a href="/contact">Contact page</a>.</p></div>`
}));
add('/about', '0.5', 'yearly');

/* Contact */
write('contact.html', layout({
  path: '/contact', nav: 'contact', page: 'contact', pageJs: true, title: 'Contact PDFora – Support and Feedback', desc: 'Contact the PDFora team with questions, feedback or billing help. Send a message and we will reply by email.',
  ld: [crumbLd([['Home', '/'], ['Contact', '/contact']])],
  body: `<div class="page"><h1>Contact us</h1><p>Have a question, a bug report or a billing issue? Send us a message${EMAIL ? ' or email ' + mail : ''}. Please never include passwords or confidential document contents.</p>
<div class="card"><form class="form" id="contactForm" novalidate><label for="cn">Your name</label><input id="cn" name="name" autocomplete="name" maxlength="120"><label for="ce">Email address</label><input id="ce" name="email" type="email" autocomplete="email" required maxlength="200"><label for="cm">Message</label><textarea id="cm" name="message" required minlength="10" maxlength="5000"></textarea><div id="contactMsg"></div><div class="row-actions"><button class="btn" type="submit">Send message</button></div></form></div></div>`
}));
add('/contact', '0.5', 'yearly');

/* Legal */
const EM = EMAIL ? mail : 'our <a href="/contact">Contact page</a>';
write('privacy-policy.html', layout({
  path: '/privacy-policy', nav: 'privacy', title: 'Privacy Policy | PDFora', desc: 'How PDFora handles your data: files are processed in your browser and not uploaded; what account, usage and billing information we keep, and your choices.',
  ld: [crumbLd([['Home', '/'], ['Privacy Policy', '/privacy-policy']])],
  body: `<div class="page"><h1>Privacy Policy</h1><p class="updated">Last updated: ${NICE_DATE}</p>
<p>This policy explains what ${esc(COMPANY)} (“PDFora”, “we”) collects when you use ${esc(SITE.replace(/^https?:\/\//, ''))}, and why. Questions? Contact us via ${EM}.</p>
<h2>Your documents</h2><p>PDFora’s tools run inside your web browser. The files you add are read and processed on your device and are <strong>not uploaded to PDFora servers</strong>. We therefore do not store, view, copy or back up your documents. Removing a file from the page (the × button or “Clear all files”) removes it from your browser’s memory for that page; closing or reloading the page does the same.</p>
<h2>Information we collect</h2><ul><li><strong>Account:</strong> when you continue with Google we receive your name, email address and a Google account identifier. We do not receive your Google password.</li><li><strong>Usage:</strong> for each successful or attempted operation we record the account, the tool name, the date and its status, so we can apply the daily allowance. We do not record file names or contents.</li><li><strong>Subscription and billing:</strong> your plan, subscription status, renewal/expiry date and a customer reference from our payment provider, Stripe. Card details are entered on Stripe’s pages and never reach PDFora.</li><li><strong>Messages:</strong> anything you send through the contact form, including your email address.</li><li><strong>Technical data:</strong> our hosting provider and server may process IP addresses and request logs for security and abuse prevention.</li></ul>
<h2>Cookies</h2><p>We use only essential cookies: a secure session cookie that keeps you logged in and a short-lived cookie used during Google sign-in. We do not use advertising or analytics cookies.</p>
<h2>How we use information</h2><p>To provide and secure your account, enforce plan limits, process payments and subscriptions, answer your messages and prevent abuse. We do not sell your personal information and we do not show advertising based on it.</p>
<h2>Who we share it with</h2><p>Google (sign-in), Stripe (payments) and our hosting provider act on our behalf to run the service. We may disclose information if the law requires it.</p>
<h2>How long we keep it</h2><p>Account and subscription records are kept while your account exists. Usage records are removed after about 35 days. Login sessions expire after 14 days of inactivity (60 days at most). Payment records may be retained by Stripe and by us as required for tax and accounting. Contact messages are kept as long as needed to respond.</p>
<h2>Your choices and rights</h2><p>You can delete your account at any time from the <a href="/account">Account page</a> (cancel an active subscription first). Depending on where you live you may also have the right to access, correct or erase your data or object to processing — contact us via ${EM} and we will respond within a reasonable time.</p>
<h2>Security</h2><p>The site is served over HTTPS, sessions use secure HTTP-only cookies and billing events are verified cryptographically. No system is perfectly secure, but we work to protect your information.</p>
<h2>Children</h2><p>PDFora is not directed to children under 16 and we do not knowingly collect their personal information.</p>
<h2>International transfers</h2><p>Our providers may process data in countries other than your own. Where required, appropriate safeguards are used.</p>
<h2>Changes</h2><p>If we change this policy we will update the date above and, for significant changes, notify you on the site.</p></div>`
}));
add('/privacy-policy', '0.3', 'yearly');
write('terms-of-service.html', layout({
  path: '/terms-of-service', nav: 'terms', title: 'Terms of Service | PDFora', desc: 'The rules for using PDFora: accounts, the Free plan limit, Pro subscriptions and billing, acceptable use, liability and how to cancel.',
  ld: [crumbLd([['Home', '/'], ['Terms of Service', '/terms-of-service']])],
  body: `<div class="page"><h1>Terms of Service</h1><p class="updated">Last updated: ${NICE_DATE}</p>
<p>By using PDFora you agree to these terms. If you do not agree, please do not use the service.</p>
<h2>The service</h2><p>PDFora provides online PDF and image tools that run in your browser. Features and limits are described on the site and may change over time.</p>
<h2>Accounts</h2><p>Using a tool requires a PDFora account created with Google sign-in. You are responsible for activity on your account and for keeping your Google account secure.</p>
<h2>Free plan</h2><p>Free accounts receive 3 successful operations per day, counted per account and reset daily at 00:00 UTC. Failed operations are not counted. We may change limits with reasonable notice.</p>
<h2>PDFora Pro</h2><p>Pro Monthly costs $9.99 per month and Pro Yearly costs $71.99 per year, in US dollars, plus any taxes that apply. Pro includes access to all 25 tools, higher usage limits, no advertisements and priority processing where supported. Subscriptions renew automatically at the end of each period until you cancel. Payments are processed by Stripe.</p>
<h2>Cancellation and refunds</h2><p>You can cancel at any time from the <a href="/subscription">Subscription page</a>. Cancellation takes effect at the end of the period you have paid for, and you keep Pro until then. Except where the law gives you a right to a refund, payments already made are not refundable.</p>
<h2>Your files</h2><p>You keep all rights to your files. Because tools run in your browser, files are not sent to us. You confirm that you have the right to process any file you use and that you will not use PDFora for unlawful purposes or to remove protection from documents you are not allowed to open.</p>
<h2>Acceptable use</h2><p>Do not abuse, overload, reverse-engineer for the purpose of bypassing limits or security, or attempt to interfere with the service or other users’ accounts. We may suspend accounts that do.</p>
<h2>Availability and warranty</h2><p>The service is provided “as is” and “as available”. We do not guarantee that it will be uninterrupted or error-free or that output will suit a particular purpose. Always keep a copy of your original files and check results before relying on them.</p>
<h2>Limitation of liability</h2><p>To the extent permitted by law, ${esc(COMPANY)} is not liable for indirect or consequential losses, and our total liability for any claim is limited to the amount you paid us in the 12 months before the claim.</p>
<h2>Termination</h2><p>You may stop using PDFora and delete your account at any time. We may suspend or end access for breach of these terms.</p>
<h2>Governing law</h2><p>These terms are governed by ${esc(LAW)}, without affecting any mandatory consumer rights you have where you live.</p>
<h2>Changes and contact</h2><p>We may update these terms and will change the date above when we do. Questions: ${EM}.</p></div>`
}));
add('/terms-of-service', '0.3', 'yearly');

/* Account pages (noindex) */
write('login.html', layout({
  path: '/login', page: 'login', pageJs: true, noindex: true, title: 'Log in to PDFora', desc: 'Log in to PDFora with your Google account to use the PDF tools.',
  body: `<div class="page" style="max-width:480px"><h1 class="center">Log in to PDFora</h1><p class="center">Continue with Google to use any tool. No password to remember, and the Free plan includes 3 successful operations per day.</p><div class="card" id="loginBox"></div><p class="center" style="font-size:14px">By continuing you agree to our <a href="/terms-of-service">Terms</a> and <a href="/privacy-policy">Privacy Policy</a>.</p></div>`
}));
write('account.html', layout({ path: '/account', page: 'account', pageJs: true, noindex: true, title: 'Your account | PDFora', desc: 'Your PDFora account, daily usage and sign-in details.', body: `<div class="page"><h1>Your account</h1><div id="accountBox"></div></div>` }));
write('subscription.html', layout({ path: '/subscription', page: 'subscription', pageJs: true, noindex: true, title: 'Manage subscription | PDFora', desc: 'Manage your PDFora Pro subscription: plan, renewal date, cancellation and billing.', body: `<div class="page"><h1>Subscription</h1><div id="subMsg"></div><div id="subBox"></div></div>` }));

/* 404 */
write('404.html', layout({
  path: '/404', noindex: true, title: 'Page not found | PDFora', desc: 'The page you are looking for could not be found. Try one of PDFora’s PDF tools.',
  body: `<div class="page center"><h1>404 — page not found</h1><p>Sorry, we could not find that page. It may have moved, or the address may be mistyped.</p><div class="row-actions" style="justify-content:center"><a class="btn" href="/">Go to the homepage</a><a class="btn ghost" href="/tools">Browse all tools</a></div>
<h2 style="margin-top:34px">Popular tools</h2><ul class="related" style="text-align:left">${['merge-pdf', 'compress-pdf', 'pdf-to-word', 'jpg-to-pdf'].map((s) => `<li><a href="/${s}"><strong>${esc(bySlug[s].name)}</strong><small>${esc(SHORT[s])}</small></a></li>`).join('')}</ul></div>`
}));

/* sitemap, robots, favicon */
write('sitemap.xml', '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' + sitemap.map((u) => `  <url><loc>${esc(u.loc)}</loc><lastmod>${TODAY}</lastmod><changefreq>${u.freq}</changefreq><priority>${u.pri}</priority></url>`).join('\n') + '\n</urlset>\n');
write('robots.txt', `User-agent: *\nAllow: /\nDisallow: /api/\nDisallow: /auth/\nDisallow: /account\nDisallow: /subscription\n\nSitemap: ${SITE}/sitemap.xml\n`);
write('favicon.svg', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="14" fill="#2563eb"/><text x="32" y="45" font-family="Arial" font-weight="700" font-size="38" text-anchor="middle" fill="white">P</text></svg>\n');
console.log('Built ' + (sitemap.length + 4) + ' pages; sitemap has ' + sitemap.length + ' URLs; site URL ' + SITE);
